#include "stdafx.h"
#include "Error.h"
#include "Expanded.h"

using namespace std;

/**
 * This constructor initializes the tag, length and value of Access Mode Data Object of the Expanded Access Rule. 
 *
 * Constants defined for tag of Access Mode Data Object:
 *	- AM_AM_BYTE
 *	- AM_CLA_EXISTS
 *	- AM_INS_EXISTS
 *	- AM_P1_EXISTS
 *	- AM_P2_EXISTS
 * 
 * \note If the AM DO contains an Access Mode Byte then pass the am_do_value argument as the Or-ing of conditions contants defined for Access Mode BYTE 
 * in Compact Access Rules and am_do_length as 1.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION	exception indicating that a dynamic memory allocation failed.
 * \throw ERROR_WRONG_INPUT_PARAMETERS	exception indicating that wrong parameters were supplied.
 */
ExpandedAccessRule::ExpandedAccessRule(
	BYTE am_do_tag,		///< Access Mode Data Object(AM DO)'s tag argument. If AM DO is command header description type than argument will be in the format of 
				///< OR-ing of various AM_DO tag constants. 
	WORD am_do_length, 	///< AM DO's length argument.
	const BYTE *am_do_value	///< AM DO's value argument.
)	{
  	this->AM_DO.setTag(am_do_tag);
	this->AM_DO.setValue(am_do_length, am_do_value);
}

/** 
 * This function adds the provided list of security condition data objects inside the provided a security condition template(OR, AND & NOT template).
 * The Security Condition Data Object corresponding to the template is then added to the Secuirty Condition List. 
 *
 * Constants defined for Security Condition Templates:
 * 	- SC_OR_TEMPLATE
 *	- SC_AND_TEMPLATE
 *	- SC_NOT_TEMPLATE
 *
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_WRONG_INPUT_PARAMETERS
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 */
int ExpandedAccessRule::addSCTemplateDO(
	BYTE sc_template,		///< Security Condition Template in which the list of security condition data objects has to be added.
					///< This argument would be one of the constants defined for Security Condition Templates.
	const DOList& scdo_list		///< List of Security Condition Data Objects.
)	{
	if((sc_template == SC_OR_TEMPLATE) || (sc_template == SC_AND_TEMPLATE) || (sc_template == SC_AND_TEMPLATE))	{
		DO sc_do(sc_template);
		int return_code = sc_do.appendConstructedValue(scdo_list);
		if(return_code != NOERROR)	return return_code;

		return SC_DO_list.copyDOtoList(sc_do);
	}
	else	return ERROR_WRONG_INPUT_PARAMETERS;
}

/** Appends the DO passed as the argument to the list of SC_DO. 
 *
 * Constants defined for tags of Security Condition Data Objects:
 *	- SC_ALWAYS
 *	- SC_NEVER
 *	- SC_BYTE
 *	- CRT_AT
 *	- CRT_CCT
 *	- CRT_DST
 *	- CRT_CT
 *	- SC_OR_TEMPLATE
 *	- SC_AND_TEMPLATE
 *	- SC_NOT_TEMPLATE
 *
 * \note That a copy of the Security Condition Data Object is added.
 *
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int ExpandedAccessRule::addSCDO(
	const DO& sc_do		///< DO to be appended whose tag value may be one of the contants defined for SC_DO tag.
)	{
	return SC_DO_list.copyDOtoList(sc_do);
}

/**
 * To get the total length of the Expanded Access Rule.
 *
 * \return Returns the length of the Expanded access rule (i.e lengths of AM_DO + total length of all SC_DO).
 */
int ExpandedAccessRule::getTotalLength(void) const	{
	return (AM_DO.getTotalLength() + SC_DO_list.getConstructedLength()); 
}

/**
 * Stores the Exapanded Access Rule in the provided buffer.
 *
 * \note It is assumed that given buffer is of sufficient size.
 *
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int ExpandedAccessRule::getTotalBytes(
	BYTE *buffer	///< Buffer in which total byte stream would be written.
) const	{
	if(!buffer)	throw ERROR_WRONG_INPUT_PARAMETERS;

	int offset = 0;
	AM_DO.getTotalBytes(buffer);
	offset = AM_DO.getTotalLength();

	SC_DO_list.getConstructedValue(buffer+offset);
	return NOERROR;
}
