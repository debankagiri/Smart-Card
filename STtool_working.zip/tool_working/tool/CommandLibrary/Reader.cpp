#include "stdafx.h"
#include "Error.h"
#include "Reader.h"

int Reader::count=0;
SCARDCONTEXT Reader::hContext=0;
DWORD Reader::dwReaders = 0;
LPTSTR Reader::mszReaders = NULL;
BYTE Reader::numReader=0;
LPTSTR* Reader::readerList = NULL;

/**
 * Default constructor sets all the values to Zero(0) and pointers to NULL 
 * and calls initPCSC() if the context to PC/SC resource manager has not been created.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory allocation failure.
 * \throw PCSC_INVALID_HANDLE exception indicating error in accessing the PCSC resource.
 * \throw PCSC_INVALID_VALUE
 * \throw PCSC_NO_READERS_AVAILABLE
 * \throw PCSC_NO_SERVICE
 * \throw PCSC_NO_MEMORY
 * \throw PCSC_UNKNOWN_ERROR
 */
Reader::Reader(void)	{
	this->hCard = 0;
	this->readerName = NULL;
	this->dwActiveProtocol = 0;
	count++;
	if(hContext == 0)	{
		int return_code = initPCSC();
		if(return_code != NOERROR)	throw return_code;
	}
}

/** 
 * Copy Constructor. Creates a copy of a given Reader object.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory allocation failure.
 */
Reader::Reader(
	const Reader& reader_arg  	///< Reference to the Reader object whose copy is to be made.
)	{
	this->hCard = reader_arg.hCard; 
	this->readerName = strdup(reader_arg.readerName);
	if(this->readerName == NULL)	throw ERROR_DYNAMIC_MEMORY_ALLOCATION;
	this->dwActiveProtocol = reader_arg.getReaderProtocol(); 
	count++;
}

/** 
 * Default destructor frees the memory occupied and calls exitPCSC() when the last Reader object is
 * destructed and there exists a valid context handle to the PC/SC resource manager.
 */
Reader::~Reader(void)	{
	count--;
	SCardDisconnect(hCard, SCARD_UNPOWER_CARD);
	if(readerName != NULL) free(readerName);
	readerName = NULL;
	hCard = 0;
	dwActiveProtocol = 0;

  	if(count == 0)	{
		exitPCSC();
		hContext = 0;
		if(mszReaders != NULL) free(mszReaders);
		mszReaders = NULL;
		if(readerList != NULL) free(readerList);
		readerList = NULL;
	}
}

/**
 * This function establishes the connection to the PC/SC resource manager and sets the list of readers connected to the system.
 *
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- PCSC_INVALID_VALUE
 *	- PCSC_INVALID_HANDLE
 *	- PCSC_NO_READERS_AVAILABLE
 *	- PCSC_NO_SERVICE
 *	- PCSC_NO_MEMORY
 *	- PCSC_UNKNOWN_ERROR
 */
int Reader::initPCSC()	{
	LONG rv = SCardEstablishContext(SCARD_SCOPE_SYSTEM,NULL,NULL,&hContext);
	if (rv != SCARD_S_SUCCESS) {
		hContext = 0;
		return return_PCSC_Error(rv);
	}
	
	mszReaders = NULL;
	rv = SCardListReaders(hContext, NULL, NULL, &dwReaders);
	if (rv != SCARD_S_SUCCESS) {
		SCardReleaseContext(hContext);
    		hContext = 0;
		dwReaders = 0;
		return return_PCSC_Error(rv);
  	}
	if((mszReaders = (LPTSTR) malloc(sizeof(char)*dwReaders)) == NULL)
		return ERROR_DYNAMIC_MEMORY_ALLOCATION;
	rv = SCardListReaders(hContext, NULL, mszReaders, &dwReaders);
	if(rv != SCARD_S_SUCCESS)	{
		SCardReleaseContext(hContext);
		hContext = 0;
		free(mszReaders);
		mszReaders = NULL;
		dwReaders = 0;
		return return_PCSC_Error(rv);
	} 

	// Count the number of readers
	LPTSTR t = mszReaders;
	int i = 0;
	while(*t != '\0') {
		t += strlen(t) + 1;
		i++;
	}

	// Build the array
	if((readerList = (LPTSTR*) malloc(i * sizeof(LPTSTR))) == NULL)	{
		SCardReleaseContext(hContext);
		hContext = 0;
		free(mszReaders);
		mszReaders = NULL;
		dwReaders = 0;
		return ERROR_DYNAMIC_MEMORY_ALLOCATION;
	}
	t = mszReaders;
	while (*t != '\0') {		
		readerList[numReader++] = t;
		t += strlen(t) + 1;
	}	
	return NOERROR;
}

/** 
 * To Release the context from PC/SC resource manager.
 *
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- PCSC_INVALID_HANDLE
 *	- PCSC_NO_SERVICE
 *	- PCSC_UNKNOWN_ERROR
 */
int Reader::exitPCSC(void)	{
	LONG rv = SCardReleaseContext(hContext);
	if (rv != SCARD_S_SUCCESS)	{
		return return_PCSC_Error(rv);
	}
	return NOERROR;
}

/**
 * To get the number of smart card readers connected to the system.
 * \return Number of smart card readers connected to the system.
 */
BYTE Reader::getNumReader(void)	{
  	return numReader;
}

/**
 * This function returns the list of smart card readers connected to the system.
 * \return Returns an array of pointers, each pointer pointing to the reader name in mszReaders.
 */ 
const LPTSTR* Reader::ListReaders(void)	{		
  	return readerList;
}

/**
 * To get the handle of the connected smart card reader.
 * \return Value of hcard handle.
 */
SCARDHANDLE Reader::getHCard(void) const	{
	return hCard;
}

/**
 * To get the value of the hcontext which is reference to the connection to PC/SC resource manager.
 * \return Value of the hContext.
 */
SCARDCONTEXT Reader::getHContext(void)	{
	return hContext;
}

/** 
 * To establish connection to the smart card reader whose reference number is passed as an argument "readerNum" 
 *
 * Constants defined for dwShareMode:
 * 	- SCARD_SHARE_SHARED : This application will allow others to share the reader.
 * 	- SCARD_SHARE_EXCLUSIVE : This application will NOT allow others to share the reader.
 * 
 * Constants defined for dwPreferredProtocols:
 *	- SCARD_PROTOCOL_T0 : Use the T=0 protocol.
 *	- SCARD_PROTOCOL_T1 : Use the T=1 protocol.
 *	- SCARD_PROTOCOL_RAW : Use with memory type cards.
 *
 * \return Returns one of the following constants.
 *	- NOERROR
 *	- PCSC_INVALID_VALUE
 *	- PCSC_INVALID_HANDLE
 *	- PCSC_READER_UNAVAILABLE
 *	- PCSC_NO_SMARTCARD_PRESENT
 *	- PCSC_READER_NOT_READY
 *	- PCSC_PROTOCOL_NOT_SUPPORTED
 *	- PCSC_SHARING_VIOLATION
 *	- PCSC_INVALID_PROTOCOL
 *	- PCSC_NO_SERVICE
 *	- PCSC_UNPOWERED_CARD
 *	- PCSC_UNKNOWN_READER
 *	- PCSC_UNKNOWN_ERROR
 */
int Reader::connectReader(
    	int readerNum,			///< Smart card reader number to which the connection has to be established. It starts from 1.
    	DWORD dwShareMode,		///< Mode of connection type - exclusive or shared. Argument would be one of the constants defined for dwShareMode.
    	DWORD dwPreferredProtocols	///< Desired protocol to use. Argument would be one of the constants defined for dwPreferredProtocols.
)	{
  	return connectReader(readerList[readerNum-1], dwShareMode, dwPreferredProtocols);
}

/** 
 * To establish connection to the smart card reader whose name is passed as an argument "readerName" 
 *
 * Constants defined for dwShareMode:
 * 	- SCARD_SHARE_SHARED : This application will allow others to share the reader.
 * 	- SCARD_SHARE_EXCLUSIVE : This application will NOT allow others to share the reader.
 * 
 * Constants defined for dwPreferredProtocols:
 *	- SCARD_PROTOCOL_T0 : Use the T=0 protocol.
 *	- SCARD_PROTOCOL_T1 : Use the T=1 protocol.
 *	- SCARD_PROTOCOL_RAW : Use with memory type cards.
 *
 * \return Returns one of the following constants.
 *	- NOERROR
 *	- PCSC_INVALID_VALUE
 *	- PCSC_INVALID_HANDLE
 *	- PCSC_READER_UNAVAILABLE
 *	- PCSC_NO_SMARTCARD_PRESENT
 *	- PCSC_READER_NOT_READY
 *	- PCSC_PROTOCOL_NOT_SUPPORTED
 *	- PCSC_SHARING_VIOLATION
 *	- PCSC_INVALID_PROTOCOL
 *	- PCSC_NO_SERVICE
 *	- PCSC_UNPOWERED_CARD
 *	- PCSC_UNKNOWN_READER
 *	- PCSC_UNKNOWN_ERROR
 */
int Reader::connectReader(
    	const LPTSTR ReaderName,	///< Name of the reader to which the connection is to be established.
    	DWORD dwShareMode,		///< Mode of connection type - exclusive or shared. Argument would be one of the constants defined for dwShareMode.
    	DWORD dwPreferredProtocols	///< Desired protocols to use. Argument would be one of the constants defined for dwPreferredProtocols.
)	{
	readerName = strdup(ReaderName);
	LONG rv = SCardConnect(hContext, readerName, dwShareMode, dwPreferredProtocols, &hCard, &dwActiveProtocol);
    	if(rv != SCARD_S_SUCCESS)	return return_PCSC_Error(rv);
	return NOERROR;
}

/** 
 * To reconnect to a the smart card reader it was previously connected to.
 *
 * Constants defined for dwShareMode:
 * 	- SCARD_SHARE_SHARED : This application will allow others to share the reader.
 * 	- SCARD_SHARE_EXCLUSIVE : This application will NOT allow others to share the reader.
 * 
 * Constants defined for dwPreferredProtocols:
 *	- SCARD_PROTOCOL_T0 : Use the T=0 protocol.
 *	- SCARD_PROTOCOL_T1 : Use the T=1 protocol.
 *	- SCARD_PROTOCOL_RAW : Use with memory type cards.
 *
 * Constants defined for dwInitialization:
 *	- SCARD_LEAVE_CARD : Do nothing.
 *	- SCARD_RESET_CARD : Reset the card.
 *	- SCARD_UNPOWER_CARD : Unpower the card.
 *	- SCARD_EJECT_CARD : Eject the card.
 *
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- PCSC_INVALID_HANDLE
 *	- PCSC_INVALID_VALUE
 *	- PCSC_READER_UNAVAILABLE
 *	- PCSC_NO_SMARTCARD_PRESENT
 *	- PCSC_READER_NOT_READY
 *	- PCSC_PROTOCOL_NOT_SUPPORTED
 *	- PCSC_SHARING_VIOLATION
 *	- PCSC_INVALID_PROTOCOL
 *	- PCSC_NO_SERVICE
 *	- PCSC_CARD_REMOVED
 *	- PCSC_UNRESPONSIVE_CARD
 *	- PCSC_UNKNOWN_ERROR
 */
int Reader::reconnectReader(
    	DWORD dwShareMode,		///< Mode of connection type - exclusive or shared. Argument would be one of the constants defined for dwShareMode.
    	DWORD dwPreferredProtocols,	///< Desired protocols to use. Argument would be one of the constants defined for dwPreferredProtocols.
    	DWORD dwInitialization		///< Desired action taken on the card/reader. Argument would be one of the constants defined for dwInitialization.
)	{
	LONG rv = SCardReconnect(hCard, dwShareMode, dwPreferredProtocols, dwInitialization, &dwActiveProtocol);
    	if(rv != SCARD_S_SUCCESS)	{
		return return_PCSC_Error(rv);
	}
  	return NOERROR;
}

/** 
 * Disconnect previously connected smart card reader by unpowering the card (SCARD_UNPOWER_CARD).
 *
 * \return Returns one of the following constants.
 *	- NOERROR
 *	- PCSC_INVALID_HANDLE
 *	- PCSC_INVALID_VALUE
 *	- PCSC_NO_SMARTCARD_PRESENT
 *	- PCSC_NO_SERVICE
 *	- PCSC_UNKNOWN_ERROR
 */
int Reader::disconnectReader(void)	{  
  	return disconnectReader(SCARD_UNPOWER_CARD);
}

/** 
 * To disconnect the previously connected smart card reader with the specified mode for handling the card in the smart card reader.
 *
 * Constants defined for dwInitialization:
 *	- SCARD_LEAVE_CARD : Do nothing to card.
 * 	- SCARD_RESET_CARD : Reset the card.
 *	- SCARD_UNPOWER_CARD : Unpower the card.
 *	- SCARD_EJECT_CARD : Eject the card.
 *
 * \return Returns one of the following constants.
 *	- NOERROR
 *	- PCSC_INVALID_HANDLE
 *	- PCSC_INVALID_VALUE
 *	- PCSC_NO_SMARTCARD_PRESENT
 *	- PCSC_NO_SERVICE
 *	- PCSC_UNKNOWN_ERROR
 */
int Reader::disconnectReader(
	DWORD dwInitialization		///< Desired mode for handling card. Argument wil be one of the constant defined for dwInitialization.
)	{
  	LONG rv = SCardDisconnect(hCard,dwInitialization); 
	if(rv != SCARD_S_SUCCESS)	return return_PCSC_Error(rv);
  	return NOERROR;
}

/**
 * To get the ATR of smart card to which the smart card reader is connected.
 *
 * \return Returns one of the following constants.
 *	- NOERROR
 *	- PCSC_INVALID_HANDLE
 *	- PCSC_INSUFFICIENT_BUFFER
 *	- PCSC_READER_UNAVAILABLE
 *	- PCSC_SMARTCARD_RESET
 *	- PCSC_NO_SERVICE
 *	- PCSC_NO_MEMORY
 *	- PCSC_CARD_REMOVED
 *	- PCSC_UNKNOWN_ERROR
 */
int Reader::getATR(
	BYTE* Atr,		///< Buffer in which ATR will be stored.
	DWORD &AtrLen		///< On input it should contain the length of Atr buffer. On output it contains the length of ATR stored in Atr buffer.
)	{
	DWORD dwState;
	DWORD dwProtocol;
	DWORD dwReaderLen = strlen(readerName);
	LONG rv = SCardStatus(hCard, NULL, &dwReaderLen, &dwState, &dwProtocol, Atr, &AtrLen);
	if(rv != SCARD_S_SUCCESS)	return return_PCSC_Error(rv);
  	return NOERROR;
}

/** 
 * Get current communication protocol used for the smart card in the connected smart card reader.
 * \return Returns the current protocol.
 */
DWORD Reader::getReaderProtocol(void) const	{
	return dwActiveProtocol;
}
