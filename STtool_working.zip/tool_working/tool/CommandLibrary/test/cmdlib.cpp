/*
 * Tests for secure messaging.
 */

#include <cstdio>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <winscard.h>
#include <cstring>
#include <cstdlib>
#include "cmdlib.h"

BYTE data[200];
Reader *reader = NULL;
APDU *apdu = NULL;
SMContext *SM = NULL;
FCP *fcp = NULL;
unsigned char Kenc[]={0x01, 0x81, 0x69, 0x02, 0x71, 0x01, 0x99, 0x01, 0x61, 0x53, 0x01, 0x00, 0x01, 0x01, 0x29, 0x03};	// key for encryption during SM
unsigned char Kmac[]={0x67, 0x92, 0xF4, 0xCC, 0x04, 0x79, 0x1B, 0xC5, 0x9C, 0x11, 0x08, 0x0D, 0xC5, 0x10, 0x16, 0x91};	// key for mac computation during SM
unsigned char SSC[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};	// ssc value to be used by cryptographic algorithms for mac computation during SM.

/*
 * Function to log the command APDU
 */
void printCAPDU(const APDU *apdu)	{
  	int i = 0;
	int Lc, Le;
	const BYTE *inbuf;
  	fprintf(stderr, "CLA=0x%02X INS=0x%02X P1=0x%02X P2=0x%02X ",apdu->getCLA(), apdu->getINS(), apdu->getP1(), apdu->getP2());
	Lc = apdu->getLc();
	if(Lc == 0)	fprintf(stderr, "Lc=(EMPTY) ");
  	else	fprintf(stderr, "Lc=0x%X ", Lc);
	Le = apdu->getLe();
	if(Le == 0)	fprintf(stderr, "Le=(EMPTY)\n");
    	else	fprintf(stderr, "Le=0x%X\n", Le);
  	if(Lc > 0)	{
		inbuf = apdu->getData();
    		fprintf(stderr, "\t\tDATA(hex) = ");
		for(i=0; i<Lc; i++)	{
      			if ((i != 0) && (i %16 == 0)) fprintf(stderr,"\n\t\t\t");
      			fprintf(stderr, "%02X ",inbuf[i]);
    		}
    		fprintf(stderr, "\n");
  	}
}

/*
 * Function to log the response APDU
 */
void printRAPDU(const APDU *apdu)	{
	int i = 0;
	int le_rcv = apdu->getLe_rcv();
	const BYTE* response = apdu->getResponse();
	fprintf(stderr, "SW1=0x%02X SW2=0x%02X\n", apdu->getSW1(), apdu->getSW2());
	if(le_rcv > 0)	{
		fprintf(stderr, "\t\tRESP(hex) = ");
		for(i = 0; i < le_rcv; i++)	{
			if((i != 0) && (i%16 == 0))	fprintf(stderr, "\n\t\t\t");
			fprintf(stderr, "%02X ", response[i]);
		}
		fprintf(stderr, "\n");
	}
}

/*
 * Logging function to be supplied as input to Command Library.
 */
void logCommand(int cmdresp, int logEvent, const APDU* apdu)	{
	if((logEvent == LOG_EVENT_AUTOGETRESPONSE) && (cmdresp == LOG_CMD))	{
		fprintf(stderr, "Issuing Auto Get Response for %d bytes\n", apdu->getLe());
	}
	if(SM != NULL)	{
		if((logEvent == LOG_EVENT_UNPROTECTED) && (cmdresp == LOG_CMD))	{
			fprintf(stderr, "Command APDU: ");
			printCAPDU(apdu);
		}
		
		if((logEvent == LOG_EVENT_TRANSMIT) && (cmdresp == LOG_CMD))	{
			fprintf(stderr, "Creating SM Command APDU\n");
			fprintf(stderr, "Command tAPDU(with SM): ");
			printCAPDU(apdu);
		}

		if((logEvent == LOG_EVENT_TRANSMIT) && (cmdresp == LOG_RESP))	{
			fprintf(stderr, "Response tAPDU(with SM): ");
			printRAPDU(apdu);
		}
		
		if((logEvent == LOG_EVENT_UNPROTECTED) && (cmdresp == LOG_RESP))	{
			fprintf(stderr, "Response (after SM Processing): ");
			printRAPDU(apdu);
			fprintf(stderr, "\n");
		}
	}
	else	{
		if((logEvent == LOG_EVENT_TRANSMIT) && (cmdresp == LOG_CMD))	{
			fprintf(stderr, "Command APDU: ");
			printCAPDU(apdu);
		}

		if((logEvent == LOG_EVENT_TRANSMIT) && (cmdresp == LOG_RESP))	{
			printRAPDU(apdu);
			fprintf(stderr, "\n");
		}
	}
}

/*
 * Function to evaluate the return status from command library
 */
void process_return_code(int return_code)	{
	if(return_code != NOERROR)	{
		fprintf(stderr, "ERROR: %s.\n", cmdlib_stringify_error(return_code));
	}
}

/*
 * function to connect the desired reader
 */
void connectReader()	{
	LPTSTR reader_name = NULL;
	int reader_num;
	int i;

	reader = new Reader();
	int numReaders = reader->getNumReader();
	if(numReaders == 0)	{
    		fprintf(stderr, "Connection Failed: no reader found.");
		delete reader;
		reader = NULL;
	}
	else	{
		const LPTSTR * readerList = reader->ListReaders();
		// choose of the readers to connect
		printf("Choose one of the following readers to use by typing in the corresponding number:\n");
		for(i=0; i<numReaders; i++)	{
			printf("%d %s\n", i, readerList[i]);
		}
		while((scanf("%d", &i) != 1) || i<0 || i>=numReaders) {
			while (getchar() != '\n');
			fprintf(stderr, "Please enter a number between 0 and %d to choose a reader\n", numReaders-1);
		}
		reader_num = i;
		reader_name = readerList[reader_num];
		printf("\n");

		// connect to the desired reader
		if(reader->connectReader(reader_name, SCARD_SHARE_SHARED, SCARD_PROTOCOL_T0) != NOERROR)	{
			fprintf(stderr, "Connection failed with %s\n", reader_name);
			delete reader;
			reader = NULL;
		}
	}
	if(reader == NULL)	{
		exit(1);
	}
}

/*
 * The function creates the file system for the test.
 */
void createFileSystem()	{
	// create MF
	fcp = new FCP(0x3F00);
	process_return_code(fcp->setFD(FDB_DF));
	apdu = new CreateFileAPDU(fcp, logCommand);
	delete fcp;
	fcp = NULL;
	process_return_code(apdu->sendAPDU(*reader, SM));
	if(apdu != NULL)	{
		delete apdu;
		apdu = NULL;
	}
		
	// Create DF(0x0B00) under MF with SE file as 0x0B03
	fcp = new FCP(0xB00);
	process_return_code(fcp->setFD(FDB_DF));
	process_return_code(fcp->setDFname(0x4, (BYTE*)"\x01\x02\x03\x04"));
	process_return_code(fcp->setSE(0xB03));
	apdu = new CreateFileAPDU(fcp, logCommand);
	delete fcp;
	fcp = NULL;
	process_return_code(apdu->sendAPDU(*reader, SM));
	if(apdu != NULL)	{
		delete apdu;
		apdu = NULL;
	}

	// create key repository(0x0B02) under DF(0x0B00)
	// variable length internal file with MNR = 3 and MRL = 30.
	fcp = new FCP(0xB02);
	process_return_code(fcp->setFD(FDB_INTERNAL_EF | FDB_LINEAR_VARIABLE, DCB_WRITE_ONCE, 30, 3));
	apdu = new CreateFileAPDU(fcp, logCommand);
	delete fcp;
	fcp = NULL;
	process_return_code(apdu->sendAPDU(*reader, SM));
	if(apdu != NULL)	{
		delete apdu;
		apdu = NULL;
	}

	// write the keyrecord for crypto checksum key in the key repository.
	apdu = new WriteRecordAPDU(0x1, 0x00, WR_UP_REC_NO_P1, 0x13, (BYTE*)"\x81\x80\x00\x67\x92\xF4\xCC\x04\x79\x1B\xC5\x9C\x11\x08\x0D\xC5\x10\x16\x91", logCommand);
	process_return_code(apdu->sendAPDU(*reader, SM));
	if(apdu != NULL)	{
		delete apdu;
		apdu = NULL;
	}

	// write the keyrecord for encryption key in the key repository.
	apdu = new WriteRecordAPDU(0x2, 0x00, WR_UP_REC_NO_P1, 0x15, (BYTE*)"\x82\x20\xA0\x20\x00\x01\x81\x69\x02\x71\x01\x99\x01\x61\x53\x01\x00\x01\x01\x29\x03", logCommand);
	process_return_code(apdu->sendAPDU(*reader, SM));
	if(apdu != NULL)	{
		delete apdu;
		apdu = NULL;
	}

	// create SE file(0x0B03)
	fcp = new FCP(0xB03);
	process_return_code(fcp->setFD(FDB_INTERNAL_EF | FDB_LINEAR_VARIABLE, DCB_WRITE_ONCE, 50, 3));
	apdu = new CreateFileAPDU(fcp, logCommand);
	delete fcp;
	fcp = NULL;
	process_return_code(apdu->sendAPDU(*reader, SM));
	if(apdu != NULL)	{
		delete apdu;
		apdu = NULL;
	}

	// Write SE#1 in SE file containg CT and CCT template
	apdu = new WriteRecordAPDU(0x1, 0x00, WR_UP_REC_NO_P1, 0x19, (BYTE*)"\x80\x01\x01\xB8\x09\x80\x01\x01\x83\x01\x82\x95\x01\x30\xB4\x09\x80\x01\x02\x83\x01\x81\x95\x01\x30", logCommand);
	process_return_code(apdu->sendAPDU(*reader, SM));
	if(apdu != NULL)	{
		delete apdu;
		apdu = NULL;
	}

	// Ceate the binary file in which data would be written.
	fcp = new FCP(0x123);
	process_return_code(fcp->setFD(FDB_WORKING_EF | FDB_TRANSPARENT));
	process_return_code(fcp->setFileSize(0xA28));
	process_return_code(fcp->setShortfid((BYTE)5));
	apdu = new CreateFileAPDU(fcp, logCommand);
	delete fcp;
	fcp = NULL;
	process_return_code(apdu->sendAPDU(*reader, SM));
	if(apdu != NULL)	{
		delete apdu;
		apdu = NULL;
	}
}

int main(int argc, char *argv[]) {
	// Intialize the data bvuffer
	for(int i=0; i< 200; i++){
		data[i] = i;
	}
	
	try	{
		// Intialize the reader.
		connectReader();
		
		// create file system
		createFileSystem();
	
		// Select MF 
		apdu = new SelectFileAPDU(SEL_ANY, FILEOP_FIRST_OCC | FILEOP_NO_RESPONSE, 0x3f00, 0, logCommand);
		process_return_code(apdu->sendAPDU(*reader, SM));
		if(apdu != NULL)	{
			delete apdu;
			apdu = NULL;
		}

		// Select DF 0x0B00
		apdu = new SelectFileAPDU(SEL_CHILD_DF, FILEOP_FIRST_OCC | FILEOP_NO_RESPONSE, 2816, 0, logCommand);
		process_return_code(apdu->sendAPDU(*reader, SM));
		if(apdu != NULL)	{
			delete apdu;
			apdu = NULL;
		}
	
		// define SM Context
		SM = new SMContext();
		SM->SMCommandList.push_back(SMContextEntry_ENCDATA_AUTH(new cryptospec("tdes-cbc", Kenc, 16, NULL, 0) ));
		SM->SMCommandList.push_back(SMContextEntry_LE_AUTH());
		SM->SMCommandList.push_back(SMContextEntry_CC(new cryptospec("epp-tdes-mac", Kmac, 16, SSC, 8) ));
		SM->SMResponseList.push_back(SMContextEntry_ENCDATA_AUTH(new cryptospec("tdes-cbc", Kenc, 16, NULL, 0) ));
		SM->SMResponseList.push_back(SMContextEntry_STATUS());
		SM->SMResponseList.push_back(SMContextEntry_CC(new cryptospec("epp-tdes-mac", Kmac, 16, SSC, 8) ));
	
		
		// select binary file(0x0123) to which data has to be written
		apdu = new SelectFileAPDU(SEL_CHILD_EF, FILEOP_FIRST_OCC | FILEOP_NO_RESPONSE, 291, 0, logCommand);
		process_return_code(apdu->sendAPDU(*reader, SM));
		if(apdu != NULL)	{
			delete apdu;
			apdu = NULL;
		}


		// write data in the bianry file
		apdu = new UpdateBinaryAPDU((WORD)0, 0xC8, (BYTE*)data, logCommand);
		process_return_code(apdu->sendAPDU(*reader, SM));
		if(apdu != NULL)	{
			delete apdu;
			apdu = NULL;
		}


		// read data from the binary file
		apdu = new ReadBinaryAPDU((WORD)0x0, 200, logCommand);
		process_return_code(apdu->sendAPDU(*reader, SM));
		if(apdu != NULL)	{
			delete apdu;
			apdu = NULL;
		}
	} catch(int exp){
		process_return_code(exp);
	}
	catch(bad_alloc &){
		process_return_code(ERROR_DYNAMIC_MEMORY_ALLOCATION);
	}
}
