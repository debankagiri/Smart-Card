#pragma once

#include "stdafx.h"
#include "CRT.h"

// Contants for AM_DO tag 
#define AM_AM_BYTE	0x80	///< AM_DO tag constant showing the presence of AM byte only. 
#define AM_CLA_EXISTS	0x88	///< AM_DO tag constant for existence of CLA in definition list.
#define AM_INS_EXISTS	0x84	///< AM_DO tag constant for existence of Instruction in definition list.
#define AM_P1_EXISTS	0x82	///< AM_DO tag constant for existence of P1 in definition list.
#define AM_P2_EXISTS	0x81	///< AM_DO tag constant for existence of P2 in definition list.

// Constants for SC_DO tag.
#define SC_ALWAYS	0x90	///< Tag of SC_DO for access condition "always".
#define SC_NEVER	0x97	///< Tag of SC_DO for access condition "never".
#define SC_BYTE		0x9E	///< Tag of SC_DO whose value field consists of Security Condition byte only.
#define SC_OR_TEMPLATE	0xA0	///< Tag of SC_DO whose value field consists of SC_DOs encapsulated in ORed template i.e. only one
				///< of security conditions is to be fulfilled for the  operation.
#define SC_AND_TEMPLATE 0xAF	/// Tag of SC_DO whose value field consists of SC_DOs encapsulated in ANDed template i.e. all of the
				///< security conditions have to be fulfilled for the operation.
#define SC_NOT_TEMPLATE 0xA7	/// Tag of SC_DO whose value field consists of SC_DOs encapsulated in NOT template i.e. security conditions
				///< are true until they are not fulfilled.
using namespace std;

/** \brief Class representing Exapanded Access Rule. 
 *
 * In expanded format an access rule consists of an Access mode DO followed by
 * one or more Security condition DOs. Each bit of access mode DO's value is associated with a 
 * security condition DO. This class represents only one access rule. For multiple access
 * rules multiple objects of this class must be created.
 */
class ExpandedAccessRule	{
	DO AM_DO;			///< Access Mode DO.
	DOList SC_DO_list;		///< Security Condition DOs.

public:
	ExpandedAccessRule(BYTE am_do_tag, WORD am_do_length, const BYTE *am_do_value);

	int addSCTemplateDO(BYTE sc_template, const DOList& scdo_list);
	int addSCDO(const DO& sc_do);

	int getTotalLength(void) const;
	int getTotalBytes(BYTE *buffer) const;
};
