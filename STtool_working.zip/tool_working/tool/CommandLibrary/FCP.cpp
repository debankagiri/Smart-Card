#include "stdafx.h"
#include "Error.h"
#include "FCP.h"

using namespace std;

/**
 * Default Constructor.
 * It creates and initializes the FCP with a DO of 'Tag' - 'FCP_TAG_FILE_ID' and 'Value' as the given file-id.
 *
 * \throw ERROR_WRONG_INPUT_PARAMETERS	exception indicating that wrong parameters were supplied.
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION	exception indicating that a dynamic memory allocation failed.
 */
FCP::FCP(
	WORD file_id			///< File identifier. Must be exactly of two bytes.
)	{
	BYTE value[2];
	value[0] = file_id >> 8;
	value[1] = file_id & 0xFF;

	DO fileid_do(FCP_TAG_FILE_ID);
	int return_code = fileid_do.setValue(2, value);
	if(return_code != NOERROR)	throw return_code;

	return_code = copyDOtoList(fileid_do);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * This function adds the input data object to FCP.
 *
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */

int FCP::addDOtoFCP(const DO& do_arg)	{
	return copyDOtoList(do_arg);
}

/** 
 * Sets the size of the file in bytes (excluding structural information)
 * It adds a DO with "Tag" - 'FCP_TAG_SET_FILE_SIZE' and "Value" field as the number of data bytes present in the file, to the FCP. 
 * It is applicable to transparent EFs only.
 *
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int FCP::setFileSize(
	WORD size		///< Number of data bytes in the file excluding structural information. Can be of maximum two bytes.
)	{
	BYTE value[2];
	value[0] = (BYTE)(size >> 8);
	value[1] = (BYTE)(size & 0xFF);
	
	DO filesize_do(FCP_TAG_SET_FILE_SIZE);
	int return_code = filesize_do.setValue(2, value);
	if(return_code != NOERROR)	return return_code;

	return copyDOtoList(filesize_do);
}

/** 
 * Sets the File Descriptor Byte(FDB) of the file,
 * and adds the DO with "Tag" as 'FCP_TAG_FDB' and "Value" field as the argument given for FDB.
 *
 * Constants defined for FDB :
 *	- FDB_SHAREABLE	: shareable file
 *	- FDB_NOT_SHAREABLE :Not shareable file
 *	- FDB_DF : DF
 *	- FDB_WORKING_EF : working EF
 *	- FDB_INTERNAL_EF : internal EF
 *	- FDB_TRANSPARENT : transparent EF for Data unit handling
 *	- FDB_LINEAR_FIXED : linear, fixed size EF for record handling
 *	- FDB_LINEAR_FIXED_TLV : linear, fixed size, simple-TLV EF for record handling
 *	- FDB_LINEAR_VARIABLE : linear, variable size EF for record handling
 *	- FDB_LINEAR_VARIABLE_TLV: linear, variable size, simple-TLV EF for record handling
 *	- FDB_CYCLIC : Cyclic, fixed size EF for record handling
 *	- FDB_CYCLIC_TLV : Cyclic, fixed size, simple-TLV for record handling
 *
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int FCP::setFD(
	BYTE FDB	///< FDB, Argument must be given in the format of OR-ing  of different constants defined for FDB.
)	{
	DO fd_do(FCP_TAG_FDB);
	int return_code = fd_do.setValue(1, &FDB);
	if(return_code != NOERROR)	return return_code;

	return copyDOtoList(fd_do);
}

/** 
 * Sets the File Descriptor Byte(FDB) and Data Coding Byte(DCB) of the file
 * and adds the DO with "Tag" as 'FCP_TAG_FDB' and "Value" field as arguments given for FDB and DCB.
 *
 * Constants defined for FDB :
 *	- FDB_SHAREABLE	: shareable file
 *	- FDB_NOT_SHAREABLE :Not shareable file
 *	- FDB_DF : DF
 *	- FDB_WORKING_EF : working EF
 *	- FDB_INTERNAL_EF : internal EF
 *	- FDB_TRANSPARENT : transparent EF for Data unit handling
 *	- FDB_LINEAR_FIXED : linear, fixed size EF for record handling
 *	- FDB_LINEAR_FIXED_TLV : linear, fixed size, simple-TLV EF for record handling
 *	- FDB_LINEAR_VARIABLE : linear, variable size EF for record handling
 *	- FDB_LINEAR_VARIABLE_TLV: linear, variable size, simple-TLV EF for record handling
 *	- FDB_CYCLIC : Cyclic, fixed size EF for record handling
 *	- FDB_CYCLIC_TLV : Cyclic, fixed size, simple-TLV for record handling
 *
 * Constants defined for DCB :
 *	- DCB_WRITE_ONCE : One time write 
 *	- DCB_WRITE_OR : write OR
 *	- DCB_WRITE_AND : write AND
 *
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int FCP::setFD(
	BYTE FDB,	///< FDB, Argument must be given in the format of OR-ing of different constants defined for FDB.
	BYTE DCB	///< DCB, Argument must be given in the format of OR-ing of different constants defined for DCB.
)	{
	BYTE t[2] = {FDB, DCB};
	
	DO fd_do(FCP_TAG_FDB);
	int return_code = fd_do.setValue(2, t);
	if(return_code != NOERROR)	return return_code;

	return copyDOtoList(fd_do);
}

/** 
 * Sets the FDB, DCB, Maximum record length(MRL) and number of records of the file
 * and adds the DO with "Tag" as 'FCP_TAG_FDB' and "Value" field as a BYTE array consisting of FDB, DCB and MRL followed by number of records. 
 * It is Applicable only to the EFs supporting records.
 *
 * Constants defined for FDB :
 *	- FDB_SHAREABLE	: shareable file
 *	- FDB_NOT_SHAREABLE :Not shareable file
 *	- FDB_DF : DF
 *	- FDB_WORKING_EF : working EF
 *	- FDB_INTERNAL_EF : internal EF
 *	- FDB_TRANSPARENT : transparent EF for Data unit handling
 *	- FDB_LINEAR_FIXED : linear, fixed size EF for record handling
 *	- FDB_LINEAR_FIXED_TLV : linear, fixed size, simple-TLV EF for record handling
 *	- FDB_LINEAR_VARIABLE : linear, variable size EF for record handling
 *	- FDB_LINEAR_VARIABLE_TLV: linear, variable size, simple-TLV EF for record handling
 *	- FDB_CYCLIC : Cyclic, fixed size EF for record handling
 *	- FDB_CYCLIC_TLV : Cyclic, fixed size, simple-TLV for record handling
 *
 * Constants defined for DCB :
 *	- DCB_WRITE_ONCE : One time write 
 *	- DCB_WRITE_OR : write OR
 *	- DCB_WRITE_AND : write AND
 *
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int FCP::setFD(
	BYTE FDB,		///< FDB, Argument must be given in the format of OR-ing of different constants defined for FDB.
	BYTE DCB,		///< DCB, Argument must be given in the format of OR-ing of different constants defined for DCB.
	WORD MRL, 		///< Maximum record length. 
	WORD no_record		///< Number of records in the file.
)	{
	int len = 0;
	BYTE value[6];
	value[len++] = FDB;
	value[len++] = DCB;
	value[len++] = MRL >> 8;
	value[len++] = MRL & 0xFF;
	
	if(no_record > 127)	value[len++] = no_record >> 8;
	value[len++] = no_record & 0xFF;

	DO fd_do(FCP_TAG_FDB);
	int return_code = fd_do.setValue(len, value);
	if(return_code != NOERROR)	return return_code;

	return copyDOtoList(fd_do);
}

/**
 * Sets the name of the DF 
 * It adds a DO with "Tag" as 'FCP_TAG_DF_NAME' and "Value" field by the DF name given as an argument.
 * It is applicable to only DFs. 
 * \note DF name must be upto maximum of 16 bytes. 
 *
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int FCP::setDFname(
	WORD length,		///< Length of the DF name.
	const BYTE *DF_name	///< Pointer to the DF name.  
)	{
	
	DO dfname_do(FCP_TAG_DF_NAME);
	int return_code = dfname_do.setValue(length, DF_name);
	if(return_code != NOERROR)	return return_code;

	return copyDOtoList(dfname_do);
}

/** 
 * Sets the short file identifier. 
 * It adds the DO with "Tag" as 'FCP_TAG_SHORT_ID' and "Value" field as the short EF identifier given in the argument. 
 * It applies only to the EFs. If this tag is not present then least five bits of the File identifier (tag �FCP_TAG_FILE_ID�) 
 * can be used as short EF identifier (unless they represent 0 or �1F�).
 * If this tag specifies no value (length 0) then the corresponding EF will have no short EF identifier.
 * \note Bits 5 to 1 encode the short EF identifier.
 *
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int FCP::setShortfid(
	BYTE short_fid	///< Short EF identifier(bits 5 to 1 encode the short EF identifier)
)	{
	BYTE sfid = (BYTE)(short_fid << 3);
	DO sfid_do(FCP_TAG_SHORT_ID);
	int return_code = sfid_do.setValue(1, &sfid);
	if(return_code != NOERROR)	return return_code;

	return copyDOtoList(sfid_do);
}

/**
 * Sets the Life Cycle Status integer (LCSI)
 * and adds the DO with "Tag" as 'FCP_TAG_LCSI' and "Value" field as argument given for LCSI. 
 *
 * Constants defined for LCSI:
 *	- LCSI_CREATION : Creation State
 *	- LCSI_INITIALISATION : Initialization State
 *	- LCSI_ACTIVATED : Activated State(optional)
 *	- LCSI_DEACTIVATED : Deactivated State(optional)
 *	- LCSI_TERMINATION : Termination State
 *
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int FCP::setLCSI(
	BYTE LCSI	///< Life Cycle Status integer,indicates various states of life cycle viz. creation, initialisation, activation, termination states.
			///<  Argument must be one of the constants defined for LCSI.
)	{
	DO lcsi_do(FCP_TAG_LCSI);
	int return_code = lcsi_do.setValue(1, &LCSI);
	if(return_code != NOERROR)	return return_code;

	return copyDOtoList(lcsi_do);
}

/** 
 * To choose the Security Environment(SE) Template to be used for different Security conditions when SE object is passed as an argument.
 * It adds the Security Environment DO with "Tag" as 'FCP_TAG_SE' to the FCP by the object of SE class. 
 * It is applicable to DFs only. 
 *
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int FCP::setSE(
	const SE &se	///< Reference to the SE class Object.
)	{
	return copyDOtoList(se);
}

/**
 * To choose the Security Environment(SE) Template to be used for different Security conditions when file id of the EF under the DF containing 
 * Security environment template is given. It adds the security Environment DO with tag 'FCP_TAG_SE_FILE' to the FCP by taking file id of the 
 * EF under the DF containing Security environment template.
 * It is applicable to DFs only. 
 * For more info see SE class.
 * 
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int FCP::setSE(
	WORD fileid		///< File id of the EF containing SE template.
)	{
	BYTE value[2] = { fileid >> 8, fileid & 0xFF};

	DO sefile_do(FCP_TAG_SE_FILE);
	int return_code = sefile_do.setValue(2, value);
	if(return_code != NOERROR)	return return_code;

	return copyDOtoList(sefile_do);
}

/**
 * Adds the security attributes DO with tag 'FCP_TAG_COMPACT' to the FCP by taking Compact Access rule as an argument.
 * It adds the DO with 'Length' field as the number of (SC)security conditions plus one (AM)access mode byte 
 * and value field as AM & SC bytes. 
 *
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int FCP::setSA(
	const CompactAccessRule& obj	///< A Compact Access Rule.
)	{
	int len = obj.getTotalLength();
	BYTE *value = (BYTE*) malloc(len);
	if(value == NULL)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
	obj.getTotalBytes(value);

	DO compact_rule_do(FCP_TAG_COMPACT);
	int return_code = compact_rule_do.setValue(len, value);
	free(value);
	if(return_code != NOERROR)	return return_code;

	return copyDOtoList(compact_rule_do);
}

/**
 * Adds the security attributes DO with tag 'FCP_TAG_COMPACT' to the FCP by taking List of Compact Access rules
 * as an argument.
 * 
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int FCP::setSA(
	const list<CompactAccessRule>& collection	///< A List of Compact Access Rules.
)	{
	DO compact_rule_do(FCP_TAG_COMPACT);

	for (list<CompactAccessRule>::const_iterator p = collection.begin(); p!=collection.end(); p++) {
		int length = p->getTotalLength();
		BYTE *value  = (BYTE*) malloc(length);
		if(value == NULL)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;

		p->getTotalBytes(value);
		int return_code = compact_rule_do.appendValue(length, value);
		free(value);
		if(return_code != NOERROR)	return return_code;
	}
	return copyDOtoList(compact_rule_do);
}

/**
 * Adds the security attributes DO with tag 'FCP_TAG_EXPANDED' to the FCP by taking Expanded Access rule as an argument. 
 * It adds a constructed DO with value field consisting of AM DOs followed by SC DOs.
 * \note If the security attributes are not defined in expanded or in compact form, default security
 * attributes of �no security� will be used. Thus the information in a file with no security attribute
 * can be operated upon by an application.
 * 
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int FCP::setSA(
	const ExpandedAccessRule& obj		///< An Expanded Access Rule.
)	{
	int len = obj.getTotalLength();
	BYTE *value = (BYTE *)malloc(len);
	if(value == NULL)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;	
	obj.getTotalBytes(value);

	DO expanded_rule_do(FCP_TAG_EXPANDED);
	int return_code = expanded_rule_do.setValue(len, value);
	free(value);
	if(return_code != NOERROR)	return return_code;

	return copyDOtoList(expanded_rule_do);
}

/**
 * Adds the security attributes DO with tag 'FCP_TAG_EXPANDED' to the FCP by taking a list of Expanded Access rules as an argument.
 * It adds a constructed DO with value field consisting of list of  AM DOs followed by SC DOs.
 * 
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int FCP::setSA(
	const list<ExpandedAccessRule>& collection	///< A List of Expanded Access Rules.
)	{
	DO expanded_rule_do(FCP_TAG_EXPANDED);
	
	for (list<ExpandedAccessRule>::const_iterator p = collection.begin(); p!=collection.end(); p++)	{
		int length = p->getTotalLength();
		BYTE *value  = (BYTE*) malloc(length);
		if(value == NULL)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;

		p->getTotalBytes (value);
		int return_code = expanded_rule_do.appendValue(length, value);
		free(value);
		if(return_code != NOERROR)	return return_code;
	}
	return copyDOtoList(expanded_rule_do);
}

int FCP::getFCPValueLength(void) const	{
	return this->getConstructedLength();
}

/**
 * To get the total length of FCP template (including the FCP's "Tag" and "Length" value).
 * \return Total Length of FCP i.e. [FCP tag + FCPlength length + sum of total lengths of all the DOs in "Value" field of FCP which is a list of DOs ].
 */
int FCP::getFCPLength(void) const	{
	int length = this->getConstructedLength();
	int i = 2 + length;	// atleast two bytes for T & L + length of value
	if(length > 127)	i++;
	if(length > 255)	i++;
	return i;
}

/** 
 * Writes the Total bytes in the FCP template in the buffer passed as an argument.
 * Including FCP's "Tag" i.e. 'FCP_TAG' & "Length" which is sum of the totalLengths of all the DO's in "Value" field followed by 
 * bytes in "Value" field which is a list of DOs. 
 *
 * \return Returns one of the following constants:
 *	- NOERROR;
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int FCP::getTotalBytes(
	BYTE *buffer		///< Buffer in which total byte stream would be written.
) const 	{
	if(buffer == NULL)	return ERROR_WRONG_INPUT_PARAMETERS;
	int length = this->getConstructedLength();
	int i = 0;
	// setting FCP tag
    	buffer[i++] = FCP_TAG;

	// setting FCP length
	if(length <= 127)	{
		buffer[i++] = (BYTE) length;
	} else if(length <=255)	{
		buffer[i++] = 0x81;
		buffer[i++] = (BYTE) length;
	} else	{
		buffer[i++] = 0x82;
		buffer[i++] = (BYTE) (length >> 8);
		buffer[i++] = (BYTE) (length & 0x00FF);
	}
	this->getConstructedValue(buffer+i);
	return NOERROR;
}
