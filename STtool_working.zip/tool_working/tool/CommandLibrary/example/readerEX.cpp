/*
 *It test reader fucntionality of command library
 */

#include "cmdlib.h"

int main() {
	LPTSTR reader_name = NULL;
	int reader_num;
	int i;

	Reader * reader = new Reader();
	int numReaders = reader->getNumReader();
	if(numReaders == 0)	{
    		printf("Connection Failed: no reader found.");
    		exit(1);
	}

	printf("Number of connected readers => %d\n\n", numReaders);
	const LPTSTR * readerList = reader->ListReaders();
	// choose of the readers to connect
	printf("Choose one of the following readers to use by typing in the corresponding number:\n");
	for(i=0; i<numReaders; i++)	{
		printf("%d %s\n", i, readerList[i]);
	}
    	while((scanf("%d", &i) != 1) || i<0 || i>=numReaders) {
      		while (getchar() != '\n');
      		fprintf(stderr, "Please enter a number between 0 and %d to choose a reader\n", numReaders-1);
    	}
	reader_num = i;
	reader_name = readerList[reader_num];
	printf("\n");

	// connect to the desired reader	
	if(reader->connectReader(reader_name, SCARD_SHARE_SHARED, SCARD_PROTOCOL_T0) == NOERROR)	{
		printf("Connection successful with %s\n\n", reader_name);
	}
	else {
		fprintf(stderr, "Connection failed with %s\n", reader_name);
		delete reader;
    		exit(1);
	}
		
	//print the ATR of the card
	DWORD atr_len = 35;
	BYTE* atr = (BYTE*) malloc(atr_len);
	if(atr == NULL)	{
		fprintf(stderr, "Dynamic memory allocation failure\n");
		delete reader;
    		exit(1);
	}
	
	int return_value = reader->getATR(atr, atr_len);
	if(return_value == NOERROR)	{
		printf("ATR: ");
		for(int j =0; j < (int)atr_len; j++)
			printf("%02X ",atr[j]);
		printf("\n\n");
	}
	else	{
		fprintf(stderr, "Error in getting ATR from reader %s\n", reader_name);
		delete reader;
		delete atr;
	}

	// diconnect from the reader
	reader->disconnectReader();
	printf("Disconnected from %s\n", reader_name);
  	return 0;
}
