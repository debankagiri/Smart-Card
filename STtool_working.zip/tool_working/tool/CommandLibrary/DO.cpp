#include "DO.h"
#include "Error.h"

/**
 * This is the default constructor.
 * It sets value of the "Length" field to be Zero(0) and "Value" field to be NULL.
 */
DO::DO(void)	{
	length = 0;
	value = NULL;
}

/** 
 * This is the default destructor.
 * Frees the memory occupied by "Value" field.
 */
DO::~DO(void)	{
	if(value != NULL)	free(value);
	value = NULL;
}

/**
 * Sets the value of the "Tag" field with the given argument, initializes "Length" to 0 and "Value" to NULL.
 */
DO::DO(
	WORD tag_arg 			///< Tag argument.
)	{
	tag = tag_arg;
	length = 0;
	value = NULL;
}

/**
 * Sets the 'Tag', 'Length' and 'Value' fields with the corresponding arguments.
 * \note "Length" must contain the exact number of bytes in "Value" field. 
 * 
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION	exception indicating that a dynamic memory allocation failed.
 * \throw ERROR_WRONG_INPUT_PARAMETERS	exception indicating that wrong parameters were supplied.
 */
DO::DO(
	const BYTE tag_arg[], 	///< Tag argument as an array.
	WORD length_arg,	///< length of value field.
	const BYTE *value_arg	///< Value argument as an array. 
)	{
	int return_code = setTag(tag_arg);
	if(return_code != NOERROR)	throw return_code;
	value = NULL;
	length = 0;
	return_code = setValue(length_arg, value_arg);
	if(return_code != NOERROR)	throw return_code;
}

/** 
 * Sets the 'Tag'(of maximum 2 bytes), 'Length' and 'Value' fields with the corresponding arguments.
 * \note "Length" must contain the exact number of bytes in "Value" field.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION	exception indicating that a dynamic memory allocation failed.
 * \throw ERROR_WRONG_INPUT_PARAMETERS	exception indicating that wrong parameters were supplied.
 */
DO::DO(
	WORD tag_arg, 			///< Tag argument.
	WORD length_arg,		///< length of value field.
	const BYTE *value_arg 		///< Value argument as an array.
) 	{
	tag = tag_arg;
	value = NULL;
	length = 0;
	int return_code = setValue(length_arg, value_arg);
	if(return_code != NOERROR)	throw return_code;
}

/** 
 * Sets the "Tag" and one BYTE "Value" field with the corresponding arguments, "Length" is implicitly assumed to be 1.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION	exception indicating that a dynamic memory allocation failed.
 * \throw ERROR_WRONG_INPUT_PARAMETERS	exception indicating that wrong parameters were supplied.
 */
DO::DO(
	WORD tag_arg, 		///< Tag argument. 
	BYTE value_arg 		///< One BYTE(8-bit) Value argument.
)	{
	tag = tag_arg;
	value = NULL;
	length = 0;
	int return_code = setValue(1, &value_arg); 
	if(return_code != NOERROR)	throw return_code;
}

/** 
 * Initializes the 'Tag', 'Length' and 'Value'(TLV) fields by extracting the values from the Byte-Stream consisting of the concatenation of TLV fields.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION	exception indicating that a dynamic memory allocation failed.
 * \throw ERROR_WRONG_INPUT_PARAMETERS	exception indicating that wrong parameters were supplied.
 */
DO::DO(
	const BYTE *byte_stream		///< Array of bytes from which DO's various fields has to be extracted to initialize TLV(should not be NULL).
)	{
	if(!byte_stream)	throw ERROR_WRONG_INPUT_PARAMETERS;

	int i=1, len;
	value = NULL;
	length = 0;
	setTag(byte_stream);
	if (tag > 0xFF) i = 2;
		len = byte_stream[i++];
	if (len == (BYTE) 0x82){
		int a = byte_stream[i++] * 256;
		len = a + byte_stream[i++];
	}
	else 	if(len == (BYTE)0x81) {
			len = byte_stream[i++];
		}
	int return_code = setValue(len, byte_stream+i);
	if(return_code != NOERROR)	throw return_code;
}

/** 
 * Copy Constructor. Creates a new copy of the given DO. 
 * 
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION	exception indicating that a dynamic memory allocation failed.
 * \throw ERROR_WRONG_INPUT_PARAMETERS	exception indicating that wrong parameters were supplied.
 */
DO::DO(
	const DO &do_arg  	///< Reference to the DO object whose copy is to be made.
)	{
	tag = do_arg.tag;
	value = NULL;
	length = 0;
	int return_code = setValue(do_arg.getLength(), do_arg.getValue());
	if(return_code != NOERROR)	throw return_code;
}

/**
 * To set the "Tag" of DO with the value of the given argument. 
 *
 * \return returns one of the following constants:
 *	- NOERROR
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int DO::setTag(
	const BYTE *tag_arg	 	///< Tag argument as an array. 
)	{
	if(tag_arg == NULL)	return ERROR_WRONG_INPUT_PARAMETERS;
	if((tag_arg[0] & 0x1F) == 0x1F)	tag = tag_arg[0] * 256 + tag_arg[1];
	else	tag = tag_arg[0];
	return NOERROR;
}

/** 
 * Sets the "Tag" of DO with the value of tag_arg. 
 */
void DO::setTag(
	const WORD tag_arg		///< Tag argument. 
)	{
	tag = tag_arg;
}

/**
 * Sets the "Value" and "Length" fields with the corresponding arguments.
 * Previous values of "Length" and "Value" fields are overwritten with the new arguments.
 * \note "Length" must contain the exact number of bytes in "Value" field. 
 * 
 * \return returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int DO::setValue(
	WORD length_arg,		///< length of the value field.	
	const BYTE *value_arg		///< Value argument.
)	{
	if(length_arg < 0)	return ERROR_WRONG_INPUT_PARAMETERS;
	if((length_arg != 0) & (value_arg == NULL))	return ERROR_WRONG_INPUT_PARAMETERS;

	if(length_arg > 0)	{
		if((VALUECHUNK*((length + VALUECHUNK - 1)/VALUECHUNK)) <= length_arg)	{
			this->value = (BYTE*) realloc(this->value, VALUECHUNK * ((length_arg+VALUECHUNK-1)/VALUECHUNK));
			if(this->value == NULL)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
		}
    		memcpy(this->value, value_arg, length_arg);
	}
	this->length = length_arg;
	return NOERROR;
}

/**
 * To get the value of "Tag" field of DO.
 * \return value of the "Tag" field of the DO. 
 */
WORD DO::getTag(void) const	{
	return tag;
}

/** 
 * To get the value of the "Length" field of DO.
 * \return value of the "Length" field of the DO. 
 */
WORD DO::getLength() const	{
	return length;
}	

/**
 * To get the pointer to the "Value" field of DO.
 * \return Returns the pointer to the "Value" field of the DO. 
 */ 
const BYTE* DO::getValue(void) const	{
	return value;
}

/** 
 * Writes the whole byte stream by concatenating the 'Tag', 'Length' and 'Value' in the same order as given in the buffer.
 * \note It is assumed that given buffer is of sufficient size.
 * \return returns one of the following constants:
 * 	- NOERROR
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int DO::getTotalBytes(
	BYTE *buffer	///< A buffer to store the Byte-stream of concatenated TLV fields of the DO.
) const	{	
  	if(buffer == NULL)	return ERROR_WRONG_INPUT_PARAMETERS;

	WORD i = 0;
	if (tag < (unsigned) 0xFF) 
		buffer[i++] = (BYTE)tag;
	else {
		buffer[i++] = tag >> 8;
		buffer[i++] = (tag & 0xFF);
	}	
	if(length<=127)	// If length is 1 byte
		buffer[i++] = (BYTE) length;
	else	if(length <= 255) { 		// If length is 2 bytes appending 81 before length by convention
			buffer[i++] = 0x81;
			buffer[i++] = (BYTE) length;
		} 
		else {	// If length is 3 bytes appending 82 before length by convention	
			buffer[i++] = 0x82;
			buffer[i++] = length >> 8;
			buffer[i++] = (length & 0xFF);
		}
	memcpy(buffer+i, value, length);
	return NOERROR;
}

/**
 * To get the total length of the DO.
 * It is calculated by summing up the number of bytes in "Tag", "Length" and "Value" fields.
 * \return Total length of the DO. 
 * \note Please note the difference in TotalLength and Length of DO. 
 */
int DO::getTotalLength(void) const	{
	WORD i = 2 + length; // At least two bytes for T and L. length for the value.
	if (tag > 0xFF) i++;
	if (length > 127) i++;
	if (length > 255) i++;
	return i;
}

/** 
 * Appends the buffer to the "Value" field and modifies the "Length" field according to the length of the buffer to be appended.
 * \return returns one of the following constants:
 *	- NOERROR
 *	- ERROR_WRONG_INPUT_PARAMETERS
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *
 * \note length_arg must contain the exact number of bytes in buffer which has to be appended . 
 */
int DO::appendValue(
	WORD length_arg,			///< Length of the buffer to be appended.
	const BYTE *buffer			///< Buffer to be appended.	
)	{
	if(length_arg < 0)	return ERROR_WRONG_INPUT_PARAMETERS;
	if((length_arg != 0)  & (buffer == NULL))	return ERROR_WRONG_INPUT_PARAMETERS;
	
	if(length_arg > 0)	{
		this->value = (BYTE *)realloc(this->value, VALUECHUNK*((this->length+length_arg-1+VALUECHUNK)/VALUECHUNK));
		if(this->value == NULL)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
		memcpy(this->value + this->length, buffer, length_arg);
		this->length += length_arg;
	}
	return NOERROR;
}	

/**
 * Sets the "Value" and "Length" of the parent DO(now constructed DO) with the collection of DO's passed as a List.
 * Previous values of "Length" and "Value" fields are overwritten with the new arguments.
 *
 * \return returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 */
int DO::appendConstructedValue(
	const DOList& collection		///< Argument passed as collection of DO's using inbuilt "list" template. 
)	{
	int constructed_len = collection.getConstructedLength();
	if(constructed_len > 0)	{
		this->value = (BYTE*)	realloc(this->value, VALUECHUNK*((this->length + constructed_len-1+VALUECHUNK)/VALUECHUNK));
		if(this->value == NULL)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
		collection.getConstructedValue(this->value + this->length);
		this->length += constructed_len;
	}
	return NOERROR;
}

/** 
 * Appends the (Byte stream of)DO given in argument to the end of the "Value" field of current DO and modifies the "Length" field accordingly. 
 * It may be used to build constructed DOs easily.
 *
 * \return returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 */
int DO::appendDO(
	const DO& do_arg		///< DO whose byte-stream is to be appended.
)	{
	int i = do_arg.getTotalLength();
	BYTE *buffer = NULL;

	if((buffer = (BYTE *)malloc(i)) == NULL)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
	do_arg.getTotalBytes(buffer);

	appendValue(i, buffer);
	free(buffer);
	return NOERROR;
}

/**
 * Appends the argument(given in TLV format) to the "Value" field and modifes the "Length" field accordingly.
 * It may be used to build constructed DOs easily.
 *
 * \return returns one of the following constants:
 *	- NOERROR
 *	- ERROR_WRONG_INPUT_PARAMETERS
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 */
int DO::appendDO(
	WORD tag_arg,				///< Tag of the DO to be appended.
	WORD length_arg,			///< Length of the DO to be appended.
	const BYTE *value_arg			///< Value field of the DO to be appended.
)	{
	try	{
		DO temp(tag_arg, length_arg, value_arg);
		return appendDO(temp);
	}
	catch(int exp)	{
		return exp;
	}
	return NOERROR;
}

/**
 * This function returns the combined length of all the DOs in the DOList.
 * \returns The conbined length of all the DOs in the list.
 */
int DOList::getConstructedLength() const	{
	int tmp = 0;
	for(DOList::const_iterator p = begin(); p != end(); p++)	{
		tmp += p->getTotalLength();
	}
	return tmp;
}

/**
 * This function returns the BYTE string corresponding to the DOs in the DOList in the input buffer.
 * \note Sufficient memory must be allocated for the buffer (getConstructedLength() gives the length of the buffer).
 *
 * \returns Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int DOList::getConstructedValue(
	BYTE* buffer			///< buffer where the DOs are stored.
) const	{
	if(buffer == NULL)	return ERROR_WRONG_INPUT_PARAMETERS;
	int tmp = 0;
	for(DOList::const_iterator p = begin(); p != end(); p++)	{
		p->getTotalBytes(buffer + tmp);
		tmp += p->getTotalLength();
	}
	return NOERROR;
}

/**
 * This functions extracts the DOs out of the supplied byte stream and adds then to the DOList.
 *
 * \return This function returns one of the following constants:
 *	- NOERROR
 *	- ERROR_WRONG_INPUT_PARAMETERS
 * 	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 */
int DOList::setList(
	int length,			///< length of the byte stream
	const BYTE* byte_stream		///< byte stream from which to get list of DOs.
)	{
	if((length < 0) || ((length != 0) && (byte_stream == NULL)))	throw ERROR_WRONG_INPUT_PARAMETERS;
	if(length == 0)	return NOERROR;		// DO nothing
	
	try	{
		for(int offset = 0; offset < length; ) {
			DO tmp_do(byte_stream + offset);
			offset += tmp_do.getTotalLength();
			this->push_back(tmp_do);
		}
	}
	catch(bad_alloc &)	{
		return ERROR_DYNAMIC_MEMORY_ALLOCATION;
	}
	catch(int exp)	{
		return exp;
	}
	return NOERROR;
}

/**
 * This function is used to add data objects to the DOList.
 *
 * \note A copy of the DO is added to the list.
 *
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int DOList::copyDOtoList(const DO& do_arg)	{
	try	{
		this->push_back(do_arg);
	}
	catch(bad_alloc&)	{
		return ERROR_DYNAMIC_MEMORY_ALLOCATION;
	}
	catch(int exp)	{
		return exp;
	}
	return NOERROR;
}
