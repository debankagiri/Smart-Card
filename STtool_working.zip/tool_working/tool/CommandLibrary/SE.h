#pragma once

#include "stdafx.h"
#include "CRT.h"

#define SE_TAG		0x7B
#define SE_SEID		0x80
#define SE_LCSI		0x8A

using namespace std;

/**
 * \brief Class representing Security Environment Template. 
 *
 * SE template is a constructed DO whose 'Value' field contains the following DOs:
 *	- DO of Security Environment(SE) number.
 *	- DO for Life Cycle Status Indicator (LCSI).
 *	- One or more CRT (Control Reference Template) to indicate the security conditions that must be met.
 */
class SE : public DO	{
	BYTE SEID;	///< Security environment Identifier.
	BYTE LCSI;	///< Life Cycle Status Indicator.
	int init(BYTE SEID, BYTE LSCI);

public:
	SE(BYTE SEID);
	SE(BYTE SEID, BYTE LCSI);
	SE(BYTE SEID, BYTE LCSI, const list<CRT> crtlist);

	int addCRT(const list<CRT>& crtlist);
	int addCRT(const CRT& crt);

	BYTE getSEID(void) const;
	BYTE getLCSI(void) const;
};
