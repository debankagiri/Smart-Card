#include "stdafx.h"
#include "CRT.h"

/** 
 * Default Constructor. 
 * Sets the value of the "Tag" field with the given argument, initializes "Length" to 0 and "Value" to NULL.
 *
 * Constants defined for CRT:
 * 	- CRT_AT
 *	- CRT_HT
 *	- CRT_CCT
 *	- CRT_DST
 *	- CRT_CT
 */
CRT::CRT(
	BYTE tag_arg		///< Tag argument. Value would be one of the constants defined for CRT.
): DO(tag_arg) {}


/**
 * Constructor sets the 'Tag', 'Length' and 'Value' with the corresponding arguments.
 *
 * Constants defined for CRT:
 * 	- CRT_AT
 *	- CRT_HT
 *	- CRT_CCT
 *	- CRT_DST
 *	- CRT_CT
 *
 * \note "Length" must contain the exact number of bytes in "Value" field of CRT.	
 * \throw EXCEPTION_WRONG_INPUT_PARAMETERS	exception indicating that wrong parameters were supplied.
 * \throw EXCEPTION_NOT_ENOUGH_MEMORY	exception indicating that a dynamic memory allocation failed.
 */
CRT::CRT(
	BYTE tag_arg,			///< Tag argument. Value would be one of the constants defined for CRT.
	WORD length_arg,		///< Length of value field.
	const BYTE *value_arg		///< Value argument as an array.
): DO(tag_arg, length_arg, value_arg) {}


/** 
 * Copy Constructor. Creates a new copy of the given DO. 
 * \throw EXCEPTION_WRONG_INPUT_PARAMETERS	exception indicating that wrong parameters were supplied.
 * \throw EXCEPTION_NOT_ENOUGH_MEMORY	exception indicating that a dynamic memory allocation failed.
 */
CRT::CRT(
	const CRT &do_arg		///< Reference to the CRT object whose copy is to be made.
): DO(do_arg) {}

/** Default destructor. Frees the memory occupied by "Value" field. */
CRT::~CRT(void) {}

/** 
 *Initializes the CRDO accordingly to the arguments(TLV) given and appends it to the "Value" field of CRT
 * also modifies the "Length" of the CRT appropriately.
 *
 * Constants defined for CRDO's tag field.
 * 	- CRT_ALGO_REF
 *	- CRT_KEY_DIRECT_SYM
 *	- CRT_KEY_PUBLIC_ASYM
 *	- CRT_KEY_SESSION_SYM
 *	- CRT_KEY_PRIVATE_ASYM
 *	- CRT_NULL_BLOCK
 *	- CRT_CHAINING_BLOCK
 *	- CRT_IV_BLOCK
 *	- CRT_CHALLENGE_OR_DATA
 *	- CRT_USAGE_QUALIFIER
 *	
 * \return returns one of the following constants:
 *	- NOERROR
 *	- ERROR_WRONG_INPUT_PARAMETERS
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 */
int CRT::appendCRDO(
	BYTE tag_CRDO,				///< Tag argument would be one of the constants defined for CRDO's tag field.
	WORD length_CRDO,			///< Length of the CRDO.
	const BYTE *value_CRDO			///< Value argument according to the tag selected.
)	{
	return appendDO(tag_CRDO, length_CRDO, value_CRDO);
}
