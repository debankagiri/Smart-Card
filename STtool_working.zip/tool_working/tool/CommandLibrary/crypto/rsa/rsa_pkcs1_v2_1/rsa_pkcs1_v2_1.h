#ifndef _RSA_PKCS1_V2_1_H
#define _RSA_PKCS1_V2_1_H

#include "tomcrypt.h"

// salt length is kept as 0x14 because scosta uses this length
#define SALT_LEN 0x14

/// constants for return values
#define CRYPTO_VERIFY_SUCCESS 	 	 0
#define CRYPTO_VERIFY_FAILURE 	 	-1
#define CRYPTO_INCONSISTENT_INPUT 	-2
#define CRYPTO_INCONSISTENT_OUTPUT 	-3
#define CRYPTO_INCONSISTENT_KEY 	-4
#define CRYPTO_INCONSISTENT_IV 		-5
#define CRYPTO_NOT_ENOUGH_MEMORY	-6
#define CRYPTO_INTERNAL_ERROR		-10

typedef unsigned char BYTE;

/**
 * In RSA iv has no meaning thus not used
 * iv and ivlen are never used by the algo
 */

extern "C"
#ifdef WIN32
	 __declspec(dllexport) 
#endif
int getEncryptLen(const BYTE* in, int inlen, const BYTE* key, int keylen, const BYTE* iv, int ivlen);

extern "C"
#ifdef WIN32
	 __declspec(dllexport) 
#endif
int encrypt(const BYTE* in , int inlen, BYTE *out, int outlen, const BYTE * key, int keylen, const BYTE *iv, int ivlen);

extern "C"
#ifdef WIN32
	 __declspec(dllexport) 
#endif
int getDecryptLen(const BYTE* in, int inlen, const BYTE* key, int keylen, const BYTE* iv, int ivlen);

extern "C"
#ifdef WIN32
	 __declspec(dllexport) 
#endif
int decrypt(const BYTE* in , int inlen, BYTE *out, int outlen,  const BYTE * key, int keylen, const BYTE *iv, int ivlen);

extern "C"
#ifdef WIN32
	 __declspec(dllexport) 
#endif
int getDsigLen(const BYTE* in, int inlen, const BYTE* key, int keylen, const BYTE* iv, int ivlen);

extern "C"
#ifdef WIN32
	 __declspec(dllexport) 
#endif
int dsig_compute(const BYTE* in, int inlen, BYTE *out, int outlen, const BYTE * key, int keylen, const BYTE* iv, int ivlen);

extern "C"
#ifdef WIN32
	 __declspec(dllexport) 
#endif
int dsig_verify(const BYTE* msg, int msglen, BYTE* sig , int siglen, const BYTE *key, int keylen, const BYTE* iv, int ivlen);

#endif
