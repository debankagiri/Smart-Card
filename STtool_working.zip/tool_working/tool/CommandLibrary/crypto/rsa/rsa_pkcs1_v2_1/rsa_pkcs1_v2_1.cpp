#include <tomcrypt.h>
#include <stdio.h>
#include "rsa_pkcs1_v2_1.h"

int getLength(const BYTE* in, int inlen, const BYTE* key, int keylen)	{
	int length;
	rsa_key rsakey;
	// registering math lib
	ltc_mp = ltm_desc;

	// importing key
	if(rsa_import(key, keylen, &rsakey) != CRYPT_OK)	{
		rsa_free(&rsakey);
		return CRYPTO_INCONSISTENT_KEY;
	}
	// finding length of the modulus
	length = mp_unsigned_bin_size((rsakey.N));
	rsa_free(&rsakey);
	return length;
}

extern "C"
int getEncryptLen(const BYTE* in, int inlen, const BYTE* key, int keylen, const BYTE* iv, int ivlen)	{
	return getLength(in, inlen, key, keylen);
}

extern "C"
int getDecryptLen(const BYTE* in, int inlen, const BYTE* key, int keylen, const BYTE* iv, int ivlen)	{
	return getLength(in, inlen, key, keylen);
}

extern "C"
int getDsigLen(const BYTE* in, int inlen, const BYTE* key, int keylen, const BYTE* iv, int ivlen)	{
	return getLength(in, inlen, key, keylen);
}

int RSA_encrypt(const BYTE* in, int inlen, BYTE* out, unsigned long outlen, const BYTE* label, int labellen, rsa_key* rsakey)	{
	int hash_idx, prng_idx;

	// registering math lib
	ltc_mp = ltm_desc;

	// registering prng & hash
	if(register_prng(&sprng_desc) == -1)	return CRYPTO_INTERNAL_ERROR;
	if(register_hash(&sha1_desc) == -1)	return CRYPTO_INTERNAL_ERROR;
	hash_idx = find_hash("sha1");
	prng_idx = find_prng("sprng");

	int return_code = rsa_encrypt_key_ex(in, inlen, out, &outlen, label, labellen, NULL, \
		prng_idx, hash_idx, LTC_PKCS_1_OAEP, rsakey);
	if(return_code != CRYPT_OK)	{
		printf("encryption %s", error_to_string(return_code));
		return CRYPTO_INTERNAL_ERROR;
	}
	else return outlen;
}

int RSA_decrypt(const BYTE * in, int inlen, BYTE* out, unsigned long outlen, const BYTE* label, int labellen, rsa_key* rsakey)	{	
	int hash_idx, stat;

	// registering math lib
	ltc_mp = ltm_desc;

	// registering prng & hash
	if(register_hash(&sha1_desc) == -1)	return CRYPTO_INTERNAL_ERROR;
	hash_idx = find_hash("sha1");
			
	if(rsa_decrypt_key_ex(in, inlen, out, &outlen, label, labellen, 	\
		hash_idx, LTC_PKCS_1_OAEP, &stat, rsakey) != CRYPT_OK)	return CRYPTO_INTERNAL_ERROR;
	else return outlen;
}

/**
 * op should be: 0 - for encryption, 1 - for decryption
 * outlen should be atleast the length of the octet modules string
 */
int rsa_encrypt_decrypt(int op, const BYTE* in, int inlen, BYTE* out, int outlen, const BYTE* key, int keylen)	{
	rsa_key rsakey;
	int keysize, return_code;

	// registering math lib
	ltc_mp = ltm_desc;
	
	// importing key
	if(rsa_import(key, keylen, &rsakey) != CRYPT_OK)	{
		rsa_free(&rsakey);
		return CRYPTO_INCONSISTENT_KEY;
	}
	keysize = mp_unsigned_bin_size((rsakey.N));
	
	// outlen atleast modulus length
	// inlen < modulus length
	if(outlen < keysize)	{
		rsa_free(&rsakey);
		return CRYPTO_INCONSISTENT_OUTPUT;
	}

	if(inlen > keysize)	{
		rsa_free(&rsakey);
		return CRYPTO_INCONSISTENT_INPUT;
	}

	// encrypting or decrypting
	switch(op)	{
	case 0:
		return_code = RSA_encrypt(in, inlen, out, outlen, NULL, 0, &rsakey);
		break;
	case 1:
		return_code = RSA_decrypt(in, inlen, out, outlen, NULL, 0, &rsakey);
		break;
	}
	rsa_free(&rsakey);
	return return_code;
}

extern "C"
int encrypt(const BYTE* in, int inlen, BYTE *out, int outlen, const BYTE* key, int keylen, const BYTE *iv, int ivlen)	{
	return rsa_encrypt_decrypt(0, in, inlen, out, outlen, key, keylen);
}

extern "C"
int decrypt(const BYTE* in, int inlen, BYTE *out, int outlen, const BYTE* key, int keylen, const BYTE *iv, int ivlen)	{
	return rsa_encrypt_decrypt(1, in, inlen, out, outlen, key, keylen);
}

/**
* This function digitally signs the message digests(hashes). 
*/
extern "C"
int dsig_compute(const BYTE* msg, int msglen, BYTE *sig, int siglen, const BYTE * key, int keylen, const BYTE* iv, int ivlen)	{
	rsa_key rsakey;
	int keysize, hash_idx, prng_idx;
	unsigned long length = siglen;

	ltc_mp = ltm_desc;
	if(rsa_import(key, keylen, &rsakey) != CRYPT_OK)	{
		rsa_free(&rsakey);
		return CRYPTO_INCONSISTENT_KEY;
	}

	keysize = mp_unsigned_bin_size((rsakey.N));
	
	if(siglen < keysize)	{
		rsa_free(&rsakey);
		return CRYPTO_INCONSISTENT_OUTPUT;
	}

	// registering hash & random number generator
	if(register_prng(&sprng_desc) == -1)	{
		rsa_free(&rsakey);
		return CRYPTO_INTERNAL_ERROR;
	}
	if(register_hash(&sha1_desc) == -1)	{
		rsa_free(&rsakey);
		return CRYPTO_INTERNAL_ERROR;
	}
	hash_idx = find_hash("sha1");
	prng_idx = find_prng("sprng");

	// creating a temporay buffer for calculating hash
	BYTE *hash = (BYTE*) malloc(20 * sizeof(BYTE));
	if(hash == NULL)	{
		rsa_free(&rsakey);
		return CRYPTO_NOT_ENOUGH_MEMORY;
	}
	unsigned long hashlen = 20;
	if(hash_memory(hash_idx, msg, msglen, hash , &hashlen) != CRYPT_OK)	{
		// if hashing fails then clean and return
		free(hash);
		rsa_free(&rsakey);
		return CRYPTO_INTERNAL_ERROR;
	}

	if(rsa_sign_hash_ex(hash, hashlen, sig, &length, LTC_PKCS_1_PSS, NULL, prng_idx, hash_idx, SALT_LEN, &rsakey) != CRYPT_OK)	{
		free(hash);
		rsa_free(&rsakey);
		return CRYPTO_INTERNAL_ERROR;
	}
	free(hash);
	rsa_free(&rsakey);
	return length;
}

extern "C"
int dsig_verify(const BYTE* msg, int msglen, BYTE* sig , int siglen, const BYTE *key, int keylen, const BYTE* iv, int ivlen)	{
	rsa_key rsakey;
	int keysize, hash_idx;
	int match = 0;

	ltc_mp = ltm_desc;
	if(rsa_import(key, keylen, &rsakey) != CRYPT_OK)	{
		rsa_free(&rsakey);
		return CRYPTO_INCONSISTENT_KEY;
	}

	keysize = mp_unsigned_bin_size((rsakey.N));
	
	// registering hash
	if(register_hash(&sha1_desc) == -1)	{
		rsa_free(&rsakey);
		return CRYPTO_INTERNAL_ERROR;
	}
	hash_idx = find_hash("sha1");

	// creating a temporay buffer for calculating hash
	BYTE *hash = (BYTE*) malloc(20 * sizeof(BYTE));
	if(hash == NULL)	{
		rsa_free(&rsakey);
		return CRYPTO_NOT_ENOUGH_MEMORY;
	}
	unsigned long hashlen = 20;
	if(hash_memory(hash_idx, msg, msglen, hash , &hashlen) != CRYPT_OK)	{
		// if hashing fails then clean and return
		free(hash);
		rsa_free(&rsakey);
		return CRYPTO_INTERNAL_ERROR;
	}

	if(rsa_verify_hash_ex(sig, siglen, hash, hashlen, LTC_PKCS_1_PSS, hash_idx, SALT_LEN, &match, &rsakey) != CRYPT_OK)	{
		free(hash);
		rsa_free(&rsakey);
		return CRYPTO_INTERNAL_ERROR;
	}
	free(hash);
	rsa_free(&rsakey);
	if((match) == 1)	return CRYPTO_VERIFY_SUCCESS;
	else return CRYPTO_VERIFY_FAILURE;
}
