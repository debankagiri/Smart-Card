#include <stdlib.h>
#include <string.h>

#include "aes.h"

extern "C"
int encrypt(const BYTE* in, int inlen, BYTE *out, int outlen,  const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
  std::string strKey,inp,outp,ivp;
  strKey.append(key,keylen);
  inp.append(in,inlen);
  ivp.append(iv,ivlen);
  AES256 aes(strKey);
  aes.set_IV(ivp);
  outp=aes.encrypt(inp);
  outlen=outp.length();
  for(int i=0;i<outlen;i++)
    out[i]=outp[i];
  return outlen;
}

extern "C"
int decrypt( const BYTE* in, int inlen, BYTE *out, int outlen,  const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
  std::string strKey,inp,outp,ivp;
  strKey.append(key,keylen);
  inp.append(in,inlen);
  ivp.append(iv,ivlen);
  AES256 aes(strKey);
  aes.set_IV(ivp);
  outp=aes.decrypt(inp);
  outlen=outp.length();
  for(int i=0;i<outlen;i++)
    out[i]=outp[i];
  return outlen;
}


extern "C"
int getEncryptLen(const BYTE *in, int inlen, const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
	int encryptLen = 1;
	if((inlen % AES_CBC_BLK_SIZE) == 0)
		encryptLen = inlen;
	else
		encryptLen = ((inlen/AES_CBC_BLK_SIZE) + 1) *AES_CBC_BLK_SIZE;
	return encryptLen;
}

extern "C"
int getDecryptLen(const BYTE *in, int inlen, const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
	int decryptLen = 1;
	if((inlen % AES_CBC_BLK_SIZE) == 0)
		decryptLen = inlen;
	else
		decryptLen = ((inlen/AES_CBC_BLK_SIZE) + 1) *AES_CBC_BLK_SIZE;
	return decryptLen;
}	

extern "C"
int getBlkSize(const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
	return AES_CBC_BLK_SIZE;
}	
