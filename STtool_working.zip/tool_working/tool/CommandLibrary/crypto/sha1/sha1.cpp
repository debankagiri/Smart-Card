#include "sha1_algos.h"
#include <string.h>
#define f0() ((b & c) | ((~b) & d))
#define f1() (b ^ c ^ d)
#define f2() ((b & c) | (b & d) | (c & d))
#define f3() f1()
#define f(i) ((i <20) ? f0() : ((i<40)? f1() : ((i<60) ? f2(): f3())))

static ubyte4 a, b, c, d, e;
static ubyte4 rot(ubyte4 v, BYTE c) {
	return ((v << c) | (v >> (32-c)));
}
static void sha_init( BYTE *inthash) {
	a = (inthash[0] << 24) | (inthash[1] << 16) | (inthash[2] << 8) | inthash[3];
	b = (inthash[4] << 24) | (inthash[5] << 16) | (inthash[6] << 8) | inthash[7];
	c = (inthash[8] << 24) | (inthash[9] << 16) | (inthash[10] << 8) | inthash[11];
	d = (inthash[12] << 24) | (inthash[13] << 16) | (inthash[14] << 8) | inthash[15];
	e = (inthash[16] << 24) | (inthash[17] << 16) | (inthash[18] << 8) | inthash[19];
}

static void copy_hash(BYTE *d, ubyte4 v) {
	d[0] = v >> 24;
	d[1] = (v >> 16) & 0xFF;
	d[2] = (v >> 8) & 0xFF;
	d[3] = v & 0xFF;
}

static void sha_loop(BYTE *data, BYTE *hash) { // Data length is always 64 byte (or 16 32-bit words)
	union {
		ubyte4 b4;
		BYTE b1[4];
	} t;
	BYTE i,j,k;
	ubyte4 kt;
	ubyte4 aorg, borg, corg, dorg, eorg;
	// Data is destroyed (becomes unrecognizable) after computations
	// Step1: Change endianity of data
	sha_init(hash);
	aorg = a;
	borg = b;
	corg = c;
	dorg = d;
	eorg = e;
	t.b4 = 1;
	if (t.b1[0] == 1) {
		for (i=0; i<64; i+=4) {
			t.b1[0] = data[i];
			data[i] = data[i+3];
			data[i+3] = t.b1[0]; 
			t.b1[0] = data[i+1];
			data[i+1] = data[i+2];
			data[i+2] = t.b1[0]; 
		}
	}
	// Init Kt = 0x5a827999 for the first 19 rounds
	kt = 0x5a827999;
	// Step2: Perform 80 rounds of SHA1
	for (i = 0; i<80; i++) {
		if (i == 20) kt = 0x6ed9eba1;
		if (i == 40) kt = 0x8f1bbcdc;
		if (i == 60) kt = 0xca62c1d6;
		t.b4 = *((ubyte4 *)(data + (i%16)*4)) + e + kt + rot(a, 5) + f(i);
		e = d; d = c; c = rot(b, 30); b = a; a = t.b4;
		if ((i & 0xf) == 0xf) {
			for (j=0; j<16; j++) {
				for (k=0; k<4; k++) {
					data[4*j + k] ^= (data[4*((j + 13) & 0x0f) + k] ^ data[4*((j + 8) & 0x0f) + k] ^ data[4*((j + 2) & 0x0f) + k]);
				}
				// Rotate by 1 bit
				t.b4 = *(ubyte4 *)(data + 4*j);
				t.b4 = rot(t.b4, 1);
				for (k=0; k<4; k++) data[4*j+k] = t.b1[k];
			}
			i = i;
		}
	}
	a+=aorg;
	b+=borg;
	c+=corg;
	d+=dorg;
	e+=eorg;
	copy_hash(hash, a);
	copy_hash(hash+4, b);
	copy_hash(hash+8, c);
	copy_hash(hash+12, d);
	copy_hash(hash+16, e);
}

	/* Input: SecBuffer1: Pointer to data to be hashed.
		  SecBuffer1Len: Size of the data
		  SecBuffer2: Pointer to hash buffer. A buffer of size atleast SHA1_HASHLEN.
	 */
void SHA1(const BYTE *SecBuffer1, int SecBuffer1Len, BYTE *SecBuffer2) {
	const BYTE hash[20] = {
		0x67, 0x45, 0x23, 0x01, 0xef, 0xcd, 0xab, 0x89,
		0x98, 0xba, 0xdc, 0xfe, 0x10, 0x32, 0x54, 0x76,
		0xc3, 0xd2, 0xe1, 0xf0};
	int i;
	int len = SecBuffer1Len;
	BYTE p[64];

	for (i=0; i<20; i++)
		SecBuffer2[i] = hash[i];
	while (len >= 64){
		memcpy(p, SecBuffer1+ SecBuffer1Len - len, 64);
		sha_loop(p, SecBuffer2);
		len -= 64;
	}
	// Padding
	memcpy(p, SecBuffer1 + SecBuffer1Len - len, len);
	p[len++] = 0x80;
	if (len > 56) {
		while (len != 64) p[len++] = 0;
		sha_loop(p, SecBuffer2);
		len = 0;
	}
	p[62] = (SecBuffer1Len >> 5) & 0xFF;
	p[63] = (SecBuffer1Len << 3) & 0xFF;
	for (i=len; i <62; i++) p[i] = 0;
	sha_loop(p, SecBuffer2);
}

extern "C"
int hash_compute(const BYTE *in, int inlen, BYTE *out, int outlen, const BYTE* key, int keylen, const BYTE* iv, int ivlen)	{
	if(outlen < SHA1_HASHLEN)	return CRYPTO_INCONSISTENT_OUTPUT;
	if(out == NULL)	return CRYPTO_INCONSISTENT_OUTPUT;
	SHA1(in, inlen, out);
	return SHA1_HASHLEN;
}

extern "C"
int hash_verify(const BYTE *in, int inlen, BYTE *hash, int hashlen, const BYTE* key, int keylen, const BYTE* iv, int ivlen)	{
	if(hashlen != SHA1_HASHLEN)	return CRYPTO_VERIFY_FAILURE;

	BYTE out[SHA1_HASHLEN];
	SHA1(in, inlen, out);
	for(int i =0; i<20;i++)
		if(out[i] != hash[i])
			return CRYPTO_VERIFY_FAILURE;
	return CRYPTO_VERIFY_SUCCESS;
}

extern "C"
int getHashLen(const BYTE *in, int inlen, const BYTE* key, int keylen, const BYTE* iv, int ivlen)	{
	return SHA1_HASHLEN;
}
