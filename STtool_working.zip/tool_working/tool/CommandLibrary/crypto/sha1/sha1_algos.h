#ifndef _SHA1_ALGOS_H
#define _SHA1_ALGOS_H

#include<string.h>
#include<stdlib.h>
#include<stdio.h>

#pragma once
#define SHA1_HASH 4
#define SHA1_HASHLEN 20

/// constants for return values
#define CRYPTO_VERIFY_SUCCESS 	 	 0
#define CRYPTO_VERIFY_FAILURE 	 	-1
#define CRYPTO_INCONSISTENT_INPUT 	-2
#define CRYPTO_INCONSISTENT_OUTPUT 	-3
#define CRYPTO_INCONSISTENT_KEY 	-4
#define CRYPTO_INCONSISTENT_IV 		-5
#define CRYPTO_NOT_ENOUGH_MEMORY	-6
#define CRYPTO_INTERNAL_ERROR		-10

typedef unsigned char BYTE;  
typedef unsigned short WORD; 

typedef  unsigned char ubyte;
typedef  unsigned short ubyte2;
typedef  unsigned int ubyte4;
typedef  char sbyte;
typedef  short byte2;
typedef  int byte4;

extern "C"
#ifdef WIN32
	 __declspec(dllexport) 
#endif
int getBlkSize(const BYTE* key, int keylen, const BYTE* iv, int ivlen);

extern "C"
#ifdef WIN32
	 __declspec(dllexport) 
#endif
int hash_compute(const BYTE *in, int inlen, BYTE *out, int outlen, const BYTE* key, int keylen, const BYTE* iv, int ivlen);

extern "C"
#ifdef WIN32
	 __declspec(dllexport) 
#endif
int hash_verify(const BYTE *in, int inlen, BYTE *hash, int hashlen, const BYTE* key, int keylen, const BYTE* iv, int ivlen);

#endif
