#include "tdescbc_algos.h"

/**
 * Encrypts or Decrypts a given text buffer, using Triple-DES algorithm in CBC mode.
 * @param op Whether to encrypt or decrypt the data
 * @return final length of outdata for success and CRYPTO_FAILURE for failure
 * DES CBC mode of operation
 */
int TDES_CBC(int op, struct TDES_CBC_Cryptospec *c, BYTE *indata, int indatalen, BYTE *outdata, int outdatalen) {
	if((c->keylen != TDES_CBC_KEY_LEN) || (c->key == NULL))	return CRYPTO_INCONSISTENT_KEY;
	if((indata == NULL) || (indatalen % TDES_CBC_BLK_SIZE)) return CRYPTO_INCONSISTENT_INPUT;
	if(outdata == NULL) return CRYPTO_INCONSISTENT_OUTPUT;
	
	if((op == TDES_CBC_ENCRYPT) || (op == TDES_CBC_DECRYPT))	{
		if(outdatalen < indatalen)	return CRYPTO_INCONSISTENT_OUTPUT;
	}
	if(op == TDES_CBC_COMPUTE)	
		if(outdatalen < TDES_CBC_BLK_SIZE)	return CRYPTO_INCONSISTENT_OUTPUT;

	BYTE *deskey = c->key;
	BYTE *iv = c->iv;
	int i, a;

	if (op == TDES_CBC_ENCRYPT) {
		des2key(deskey, EN0);
		for (a = 0; a < indatalen; a += TDES_CBC_BLK_SIZE) {
			if (a > 0) {
				for (i = 0; i < TDES_CBC_BLK_SIZE; i++)
					outdata[a+i] = indata[a + i] ^ outdata[a + i - TDES_CBC_BLK_SIZE];
			} else {
				for (i=0; i<TDES_CBC_BLK_SIZE; i++)
					outdata[i] = indata[i] ^ iv[i];
			}
			Ddes(outdata+a, outdata+a);
		}
		return indatalen;
    	} else if (op == TDES_CBC_DECRYPT) {
		des2key(deskey, DE1);
		for (a = indatalen; a > 0; a -= TDES_CBC_BLK_SIZE) {
			Ddes(indata + (a-TDES_CBC_BLK_SIZE), outdata + (a - TDES_CBC_BLK_SIZE));
			if (a > TDES_CBC_BLK_SIZE) {
				for (i = 0; i < TDES_CBC_BLK_SIZE; i++)
					outdata[a+i-TDES_CBC_BLK_SIZE] ^= indata[a + i - 2*TDES_CBC_BLK_SIZE];
			} else {
				for (i = 0; i < TDES_CBC_BLK_SIZE; i++)
					outdata[i] ^= iv[i];
			}
		}
		return indatalen;
    	} else if (op == TDES_CBC_COMPUTE) {
		des2key(deskey, EN0);
		for (a = 0; a < indatalen; a += TDES_CBC_BLK_SIZE) {
			if (a > 0) {
				for (i = 0; i < TDES_CBC_BLK_SIZE; i++)
					outdata[i] ^= indata[a + i];
			} else {
				for (i=0; i<TDES_CBC_BLK_SIZE; i++)
					outdata[i] = indata[i] ^ iv[i];
			}
			Ddes(outdata, outdata);
		}
		return TDES_CBC_BLK_SIZE;
	} 
	return CRYPTO_INTERNAL_ERROR;
}
