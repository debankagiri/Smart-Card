#include <stdlib.h>
#include <string.h>

#include "tdescbc_algos.h"

extern "C"
int encrypt(const BYTE* in, int inlen, BYTE *out, int outlen,  const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
 	struct TDES_CBC_Cryptospec cdup;
 	cdup.algo = NULL;
 	cdup.key = (BYTE*)key;
 	cdup.keylen = keylen;
 	cdup.ivlen = TDES_CBC_BLK_SIZE;
	cdup.iv = NULL;
 	if (ivlen == 0)	{
		if((cdup.iv = (BYTE *) calloc(TDES_CBC_BLK_SIZE, 1)) == NULL)	return CRYPTO_NOT_ENOUGH_MEMORY;
 		int return_code = TDES_CBC(TDES_CBC_ENCRYPT, &cdup, (BYTE*)in, inlen, out, outlen);
		free(cdup.iv);
		return return_code;
	}
	else	{
		if (ivlen != TDES_CBC_BLK_SIZE) 
        		return CRYPTO_INCONSISTENT_IV;
 		else	{
			cdup.iv = (BYTE*)iv;
 			return TDES_CBC(TDES_CBC_ENCRYPT, &cdup, (BYTE*)in, inlen, out, outlen);
		}
	}
}

extern "C"
int decrypt( const BYTE* in, int inlen, BYTE *out, int outlen,  const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
	struct TDES_CBC_Cryptospec cdup;
 	cdup.algo = NULL;
 	cdup.key = (BYTE*)key;
 	cdup.keylen = keylen;
 	cdup.ivlen = TDES_CBC_BLK_SIZE;
	cdup.iv = NULL;
 	if (ivlen == 0)	{
		if((cdup.iv = (BYTE *) calloc(TDES_CBC_BLK_SIZE, 1)) == NULL)	return CRYPTO_NOT_ENOUGH_MEMORY;
		int return_code = TDES_CBC(TDES_CBC_DECRYPT, &cdup, (BYTE*)in, inlen, out, outlen);
		free(cdup.iv);
		return return_code;
	}
 	else	{
		if (ivlen != TDES_CBC_BLK_SIZE) 
        		return CRYPTO_INCONSISTENT_IV;
		else	{
			cdup.iv = (BYTE*)iv;
			return TDES_CBC(TDES_CBC_DECRYPT, &cdup, (BYTE*)in, inlen, out, outlen);
		}
	}
}

extern "C"
int cc_compute(const BYTE* in, int inlen, BYTE *out, int outlen,  const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
 	struct TDES_CBC_Cryptospec cdup;
 	cdup.algo = NULL;
 	cdup.key = (BYTE*)key;
 	cdup.keylen = keylen;
 	cdup.ivlen = TDES_CBC_BLK_SIZE;
	cdup.iv = NULL;
 	if (ivlen == 0)	{
		if((cdup.iv = (BYTE *) calloc(TDES_CBC_BLK_SIZE, 1)) == NULL)	return CRYPTO_NOT_ENOUGH_MEMORY;
		int return_code = TDES_CBC(TDES_CBC_COMPUTE, &cdup, (BYTE*)in, inlen, out, outlen);
		free(cdup.iv);
		return return_code;
	}
 	else	{
		if (ivlen != TDES_CBC_BLK_SIZE) 
			return CRYPTO_INCONSISTENT_IV;
		else 	{
			cdup.iv = (BYTE*)iv;
			return TDES_CBC(TDES_CBC_COMPUTE, &cdup, (BYTE*)in, inlen, out, outlen);
		}
	}
}

extern "C"
int cc_verify(const BYTE* in, int inlen, BYTE *out, int outlen,  const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
	if(out == NULL)	return CRYPTO_INCONSISTENT_OUTPUT;

	// compute crypto checksum and match the crypto checksum with out buffer.
	BYTE* cc_buffer = NULL;
	if((cc_buffer = (BYTE*) malloc(TDES_CBC_BLK_SIZE)) == NULL)
		return CRYPTO_NOT_ENOUGH_MEMORY;

	int cc_buffer_len = cc_compute(in, inlen, cc_buffer, TDES_CBC_BLK_SIZE, key, keylen, iv, ivlen);
	if(cc_buffer_len > 0)	{
		if(cc_buffer_len != outlen)	cc_buffer_len = CRYPTO_VERIFY_FAILURE;
		else	{
			int i = 0;
			for(; i<outlen; i++)
				if(out[i] != cc_buffer[i])	break;
			if(i != outlen)	cc_buffer_len = CRYPTO_VERIFY_FAILURE;
			else	cc_buffer_len = CRYPTO_VERIFY_SUCCESS;
		}
	}
	free(cc_buffer);
	return cc_buffer_len;
}

extern "C"
int getEncryptLen(const BYTE *in, int inlen, const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
	int encryptLen = 1;
	if((inlen % TDES_CBC_BLK_SIZE) == 0)
		encryptLen = inlen;
	else
		encryptLen = ((inlen/TDES_CBC_BLK_SIZE) + 1) *TDES_CBC_BLK_SIZE;
	return encryptLen;
}

extern "C"
int getDecryptLen(const BYTE *in, int inlen, const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
	int decryptLen = 1;
	if((inlen % TDES_CBC_BLK_SIZE) == 0)
		decryptLen = inlen;
	else
		decryptLen = ((inlen/TDES_CBC_BLK_SIZE) + 1) *TDES_CBC_BLK_SIZE;
	return decryptLen;
}	

extern "C"
int getCCLen(const BYTE *in, int inlen, const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
	return TDES_CBC_BLK_SIZE;
}	

extern "C"
int getBlkSize(const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
	return TDES_CBC_BLK_SIZE;
}	
