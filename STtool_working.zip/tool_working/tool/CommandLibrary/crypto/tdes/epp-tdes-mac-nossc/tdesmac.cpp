#include "tdesmac_algos.h"

int TDES_MAC(struct TDES_MAC_Cryptospec *c, ubyte *indata, int indatalen, ubyte *outdata, int outdatalen)
{
	if((c->key == NULL) || (c->keylen != TDES_MAC_KEY_LEN))	return CRYPTO_INCONSISTENT_KEY;
        if((outdata == NULL) || (outdatalen < TDES_MAC_BLK_SIZE)) return CRYPTO_INCONSISTENT_OUTPUT;
        if((indata == NULL) || (indatalen % TDES_MAC_BLK_SIZE)) return CRYPTO_INCONSISTENT_INPUT;

	ubyte *deskey = (ubyte *)c->key;
	int a, j;

        for (a=0; a<8; a++) outdata[a] = 0;
    
	for (a = 0; a< indatalen; a+=8) {
		deskey_fun(deskey, EN0);
                for (j=0; j<8; j++)	outdata[j] ^= indata[a+j];
		des(outdata, outdata);
	}
	deskey_fun(deskey+8, DE1);
	des(outdata, outdata);
	deskey_fun(deskey, EN0);
	des(outdata, outdata);
	
        return TDES_MAC_BLK_SIZE;
}
