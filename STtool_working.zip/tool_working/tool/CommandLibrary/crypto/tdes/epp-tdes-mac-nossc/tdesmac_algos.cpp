#include <stdlib.h>
#include <string.h>

#include "tdesmac_algos.h"

extern "C"
int cc_compute( const BYTE* in, int inlen, BYTE *out, int outlen,  const BYTE *key, int keylen, const BYTE *iv, int ivlen)
{
	struct TDES_MAC_Cryptospec cdup;
	cdup.algo = NULL;
	cdup.key = (BYTE*)key;
	cdup.keylen = keylen;
	cdup.ivlen = TDES_MAC_BLK_SIZE;
	cdup.iv = NULL;
	if (ivlen == 0)	{
		if((cdup.iv = (BYTE *) calloc(TDES_MAC_BLK_SIZE, 1)) == NULL)	return CRYPTO_NOT_ENOUGH_MEMORY;
		int return_code =  TDES_MAC(&cdup, (BYTE*)in, inlen, out, outlen);
		free(cdup.iv);
		return return_code;
	}
	else	{
		if (ivlen != TDES_MAC_BLK_SIZE) 
			return CRYPTO_INCONSISTENT_IV;
		else	{
			cdup.iv = (BYTE*)iv;
			return TDES_MAC(&cdup, (BYTE*)in, inlen, out, outlen);
		}
	}
}

extern "C"
int cc_verify(const BYTE* in, int inlen, BYTE *out, int outlen,  const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
	if(out == NULL)	return CRYPTO_INCONSISTENT_OUTPUT;

	// compute crypto checksum and match the crypto checksumwith out buffer.
	BYTE* cc_buffer = NULL;
	if((cc_buffer = (BYTE*) malloc(TDES_MAC_BLK_SIZE)) == NULL)
		return CRYPTO_NOT_ENOUGH_MEMORY;

	int cc_buffer_len = cc_compute(in, inlen, cc_buffer, TDES_MAC_BLK_SIZE, key, keylen, iv, ivlen);
	if(cc_buffer_len > 0)	{
		if(cc_buffer_len != outlen)	cc_buffer_len = CRYPTO_VERIFY_FAILURE;
		else	{
			int i = 0;
			for(; i<outlen; i++)
				if(out[i] != cc_buffer[i])	break;
			if(i != outlen)	cc_buffer_len = CRYPTO_VERIFY_FAILURE;
			else	cc_buffer_len = CRYPTO_VERIFY_SUCCESS;
		}
	}
	free(cc_buffer);
	return cc_buffer_len;
}

extern "C"
int getCCLen(const BYTE *in, int inlen, const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
	return TDES_MAC_BLK_SIZE; 
}

extern "C"
int getBlkSize(const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
	return TDES_MAC_BLK_SIZE; 
}
