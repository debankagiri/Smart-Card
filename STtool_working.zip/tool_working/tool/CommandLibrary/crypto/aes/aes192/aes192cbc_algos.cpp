#include <iostream>
#include <stdlib.h>
#include <string.h>

#include "aes192cbc_algos.h"

extern "C"
int encrypt(const BYTE* in, int inlen, BYTE *out, int outlen,  const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
  BYTE *cdup;
  if (ivlen == 0) {
    if((cdup = (BYTE *) calloc(AES_CBC_BLK_SIZE, 1)) == NULL)	return CRYPTO_NOT_ENOUGH_MEMORY;
  }
  else {
    if (ivlen != AES_CBC_BLK_SIZE)
      return CRYPTO_INCONSISTENT_IV;
    else
      cdup = (BYTE *)iv;
  }
  if((keylen != AES_CBC_KEY_LEN) || (key == NULL))	return CRYPTO_INCONSISTENT_KEY;
  if((in == NULL) || (inlen % AES_CBC_BLK_SIZE)) return CRYPTO_INCONSISTENT_INPUT;
  if(out == NULL) return CRYPTO_INCONSISTENT_OUTPUT;
  
  if(outlen < inlen)	return CRYPTO_INCONSISTENT_OUTPUT;

  int i, a;
  AES_KEY aes_key;
  i=AES_set_encrypt_key(key,keylen*8,&aes_key);
  if(i<0) return CRYPTO_INTERNAL_ERROR;

  for (a = 0; a < inlen; a += AES_CBC_BLK_SIZE) {
    if (a > 0) {
      for (i = 0; i < AES_CBC_BLK_SIZE; i++)
	out[a+i] = in[a + i] ^ out[a + i - AES_CBC_BLK_SIZE];
    } else {
      for (i=0; i<AES_CBC_BLK_SIZE; i++)
	out[i] = in[i] ^ cdup[i];
    }
    AES_encrypt(out+a, out+a, &aes_key);
  }
  if (ivlen==0) free(cdup);
  return inlen;
}

extern "C"
int decrypt( const BYTE* in, int inlen, BYTE *out, int outlen,  const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
  BYTE *cdup;
  if (ivlen == 0) {
    if((cdup = (BYTE *) calloc(AES_CBC_BLK_SIZE, 1)) == NULL)	return CRYPTO_NOT_ENOUGH_MEMORY;
  }
  else {
    if (ivlen != AES_CBC_BLK_SIZE)
      return CRYPTO_INCONSISTENT_IV;
    else
      cdup = (BYTE *)iv;
  }
  if((keylen != AES_CBC_KEY_LEN) || (key == NULL))	return CRYPTO_INCONSISTENT_KEY;
  if((in == NULL) || (inlen % AES_CBC_BLK_SIZE)) return CRYPTO_INCONSISTENT_INPUT;
  if(out == NULL) return CRYPTO_INCONSISTENT_OUTPUT;
  
  if(outlen < inlen)	return CRYPTO_INCONSISTENT_OUTPUT;
  
  int i, a;
  AES_KEY aes_key;
  i=AES_set_decrypt_key(key,keylen*8,&aes_key);
  if(i<0) return CRYPTO_INTERNAL_ERROR;

  for (a = 0; a < inlen; a += AES_CBC_BLK_SIZE) {
    AES_decrypt(in+a, out+a, &aes_key);
    if (a > 0) {
      for (i = 0; i < AES_CBC_BLK_SIZE; i++)
	out[a+i] = out[a + i] ^ in[a + i - AES_CBC_BLK_SIZE];
    } else {
      for (i=0; i<AES_CBC_BLK_SIZE; i++)
	out[i] = out[i] ^ cdup[i];
    }
  }
  if (ivlen==0) free(cdup);
  return inlen;
}
extern "C"
int getEncryptLen(const BYTE *in, int inlen, const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
	int encryptLen = 1;
	if((inlen % AES_CBC_BLK_SIZE) == 0)
		encryptLen = inlen;
	else
		encryptLen = ((inlen/AES_CBC_BLK_SIZE) + 1) *AES_CBC_BLK_SIZE;
	return encryptLen;
}

extern "C"
int getDecryptLen(const BYTE *in, int inlen, const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
	int decryptLen = 1;
	if((inlen % AES_CBC_BLK_SIZE) == 0)
		decryptLen = inlen;
	else
		decryptLen = ((inlen/AES_CBC_BLK_SIZE) + 1) *AES_CBC_BLK_SIZE;
	return decryptLen;
}	

extern "C"
int getBlkSize(const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{
	return AES_CBC_BLK_SIZE;
}	
