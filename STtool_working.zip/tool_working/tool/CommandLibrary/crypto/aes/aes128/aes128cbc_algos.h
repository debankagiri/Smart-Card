#ifndef _AES_CBC_ALGOS_H
#define _AES_CBC_ALGOS_H

#include "aes.h"
#include<string.h>
#include<stdlib.h>
#include<stdio.h>

#pragma once
#define AES_CBC_ENCRYPT 	0
#define AES_CBC_DECRYPT 	1

#define AES_CBC_KEY_LEN 16
#define AES_CBC_BLK_SIZE 16

/// constants for return values
#define CRYPTO_VERIFY_SUCCESS 	 	 0
#define CRYPTO_VERIFY_FAILURE 	 	-1
#define CRYPTO_INCONSISTENT_INPUT 	-2
#define CRYPTO_INCONSISTENT_OUTPUT 	-3
#define CRYPTO_INCONSISTENT_KEY 	-4
#define CRYPTO_INCONSISTENT_IV 		-5
#define CRYPTO_NOT_ENOUGH_MEMORY	-6
#define CRYPTO_INTERNAL_ERROR		-10

typedef unsigned char BYTE;  
typedef unsigned short WORD; 

typedef  unsigned char ubyte;
typedef  unsigned short ubyte2;
typedef  unsigned int ubyte4;
typedef  char sbyte;
typedef  short byte2;
typedef  int byte4;


extern "C"
#ifdef WIN32
	 __declspec(dllexport) 
#endif
int encrypt(const BYTE *in, int inlen, BYTE *out, int outlen, const BYTE *key, int keylen, const BYTE *iv, int ivlen);

extern "C"
#ifdef WIN32
	 __declspec(dllexport) 
#endif
int decrypt(const BYTE *in, int inlen, BYTE *out, int outlen, const BYTE *key, int keylen, const BYTE *iv, int ivlen);

extern "C"
#ifdef WIN32
	 __declspec(dllexport) 
#endif
int getEncryptLen(const BYTE *in, int inlen, const BYTE *key, int keylen, const BYTE *iv, int ivlen);

extern "C"
#ifdef WIN32
	 __declspec(dllexport) 
#endif
int getDecryptLen(const BYTE *in, int inlen, const BYTE *key, int keylen, const BYTE *iv, int ivlen);

extern "C"
#ifdef WIN32
	 __declspec(dllexport) 
#endif
int getBlkSize(const BYTE *key, int keylen, const BYTE *iv, int ivlen);

#endif
