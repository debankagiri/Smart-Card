#include <iostream>
#include "mod-exp.h"

extern "C"
int encrypt(const BYTE* in, int inlen, BYTE *out, int outlen,  const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{

  /*a^b (mod c)*/
  mp_int a,b,c,temp;
  int result;
  
  if((result=mp_init_multi(&a,&b,&c,&temp,NULL))!=MP_OKAY) {
    fprintf(stderr,"Error initializing numbers:%s\n",mp_error_to_string(result));
    return CRYPTO_INTERNAL_ERROR;
  }

  if((result=mp_read_unsigned_bin(&a,in,inlen))!=MP_OKAY) {
    fprintf(stderr,"Error setting a :%s\n",mp_error_to_string(result));
    return CRYPTO_INTERNAL_ERROR;
  }

  if((result=mp_read_unsigned_bin(&b,iv,ivlen))!=MP_OKAY) {
    fprintf(stderr,"Error setting b :%s\n",mp_error_to_string(result));
    return CRYPTO_INTERNAL_ERROR;
  }

  if((result=mp_read_unsigned_bin(&c,key,keylen))!=MP_OKAY) {
    fprintf(stderr,"Error setting c :%s\n",mp_error_to_string(result));
    return CRYPTO_INTERNAL_ERROR;
  }

  if((result=mp_exptmod(&a,&b,&c,&temp))!=MP_OKAY) {
    fprintf(stderr,"Error computing modular exponentiation :%s\n",mp_error_to_string(result));
    return CRYPTO_INTERNAL_ERROR;
  }

  outlen=mp_unsigned_bin_size(&temp);
  mp_to_unsigned_bin(&temp,out);
  return outlen;

}

extern "C"
int decrypt(const BYTE* in, int inlen, BYTE *out, int outlen,  const BYTE *key, int keylen, const BYTE *iv, int ivlen)	{

  /*a^b (mod c)*/
  mp_int a,b,c,temp;
  int result;
  
  if((result=mp_init_multi(&a,&b,&c,&temp,NULL))!=MP_OKAY) {
    fprintf(stderr,"Error initializing numbers:%s\n",mp_error_to_string(result));
    return CRYPTO_INTERNAL_ERROR;
  }

  if((result=mp_read_unsigned_bin(&a,in,inlen))!=MP_OKAY) {
    fprintf(stderr,"Error setting a :%s\n",mp_error_to_string(result));
    return CRYPTO_INTERNAL_ERROR;
  }

  if((result=mp_read_unsigned_bin(&b,iv,ivlen))!=MP_OKAY) {
    fprintf(stderr,"Error setting b :%s\n",mp_error_to_string(result));
    return CRYPTO_INTERNAL_ERROR;
  }

  if((result=mp_read_unsigned_bin(&c,key,keylen))!=MP_OKAY) {
    fprintf(stderr,"Error setting c :%s\n",mp_error_to_string(result));
    return CRYPTO_INTERNAL_ERROR;
  }

  if((result=mp_exptmod(&a,&b,&c,&temp))!=MP_OKAY) {
    fprintf(stderr,"Error computing modular exponentiation :%s\n",mp_error_to_string(result));
    return CRYPTO_INTERNAL_ERROR;
  }

  outlen=mp_unsigned_bin_size(&temp);
  mp_to_unsigned_bin(&temp,out);
  return outlen;

}
