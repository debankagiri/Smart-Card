#ifndef _MOD_EXP_H
#define _MOD_EXP_H

#include<string.h>
#include<stdlib.h>
#include <stdlib.h>
#include <string.h>
#include <tommath.h>


typedef unsigned char BYTE;  
typedef unsigned short WORD; 

typedef  unsigned char ubyte;
typedef  unsigned short ubyte2;
typedef  unsigned int ubyte4;
typedef  char sbyte;
typedef  short byte2;
typedef  int byte4;
#define CRYPTO_INTERNAL_ERROR		-10


extern "C"
#ifdef WIN32
	 __declspec(dllexport) 
#endif
int encrypt(const BYTE *in, int inlen, BYTE *out, int outlen, const BYTE *key, int keylen, const BYTE *iv, int ivlen);

extern "C"
#ifdef WIN32
	 __declspec(dllexport) 
#endif
int decrypt(const BYTE *in, int inlen, BYTE *out, int outlen, const BYTE *key, int keylen, const BYTE *iv, int ivlen);

#endif
