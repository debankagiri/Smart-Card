#pragma once

#include "stdafx.h"

/** \defgroup reader Reader Management */

/*@{*/

/** 
 * \brief Class for smart card reader specific operations according to PC/SC API.
 *
 * This class provides functions for listing the readers connected to the system, connecting/disconnecting to a particular reader,
 * getting the ATR of the smart card in the connected reader and getting the state of the connected smart card.
 */
class Reader	{
  private:
  static SCARDCONTEXT hContext;		///< Reference handle to the connection to PC/SC resource manager.
  static int count;			///< Counter to keep check of the number of Reader objects.
  static LPTSTR mszReaders;		///< Smart card reader names in a concatenated form, delimited by NULL and ended with NULLNULL.
  static DWORD dwReaders;        	///< Length of the mszReaders.
  static LPTSTR *readerList;		///< Array of pointers, each pointer pointing to individual reader names in mszReaders.
  static BYTE numReader;		///< Number of smart card readers connected to the System.
  static int initPCSC(void);
  static int exitPCSC(void);

  LPTSTR readerName;			///< Name of the smart card reader.
  SCARDHANDLE hCard;			///< Handle to the connected smart card reader.
  DWORD dwActiveProtocol;		///< Active protocol of smart card reader (T0 / T1 / RAW).

  public:
  Reader(void);
  Reader(const Reader &reader_arg);
  ~Reader(void);
  
  static BYTE getNumReader(void);
  static const LPTSTR* ListReaders(void);
  static SCARDCONTEXT getHContext(void);

  SCARDHANDLE getHCard(void) const;
  int connectReader(int readerNo, DWORD dwShareMode, DWORD dwPreferredProtocols);
  int connectReader(const LPTSTR Readername, DWORD dwShareMode, DWORD dwPreferredProtocols);
  int reconnectReader(DWORD dwShareMode, DWORD dwPreferredProtocols, DWORD dwInitialization);
  int disconnectReader(void);	
  int disconnectReader(DWORD dwInitialization);

  DWORD getReaderProtocol(void) const;
  int getATR(BYTE* Atr, DWORD& AtrLen);
};

/*@}*/
