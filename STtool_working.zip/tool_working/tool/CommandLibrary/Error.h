#pragma once

#include "stdafx.h"

#define NOERROR           	 				 0	///< Constant indicating no error condition(normal functioning).
#define ERROR_DYNAMIC_MEMORY_ALLOCATION				-1	///< Error constant indicating error during dynamic memory allocation.
#define ERROR_WRONG_INPUT_PARAMETERS				-2	///< Error constant indicating error due to wrong input arguments.
#define ERROR_SMRESPONSE_INCORRECT_SMDO_OBTAINED		-3	///< Error constant indicating that wrong SM DOs were found in the supplied SM Response(SM DOs other than 0x80, 0x81, 0x86, 0x87, 0xB0, 0xB1, 0x82, 0x83, 0x99, 0x8E).
#define ERROR_SMRESPONSE_DUPLICATE_SMDOS_OBTAINED		-4	///< Error constant indicating that multiple SM DOs with same tags were found in supplied SM Response.
#define ERROR_SMRESPONSE_INCORRECT_CC_SMDO_OBTAINED		-5	///< Error constant indicating that the CC(0x8E) SM DO was not the last SM DO in the supplied SM Response.
#define ERROR_SMRESPONSE_INCORRECT_STATUS_SMDO_OBTAINED		-6	///< Error constant indicating that STATUS(0x99) SM DO found in SM Response had length more than 2.
#define ERROR_SMRESPONSE_CC_TAG_WRONG_PARAM    			-7	///< Error constant indicating wrong parameters of CC(0x8E) tag in SM Command tag list
#define ERROR_SMRESPONSE_CC_VERIFICATION_FAILED			-8	///< Error constant indicating that Crypto Checksum(integrity) Verification failed.
#define ERROR_SMRESPONSE_MULTIPLE_RESPONSE_STATUS_OBTAINED 	-9	///< Error constant indicating that multiple STATUS(0x99) SM DOs were obtained in supplied SM Response.
#define ERROR_SMRESPONSE_MULTIPLE_RESPONSE_DATA_OBTAINED	-10	///< Error constant indicating that multiple response(0x80, 0x81, 0x86, 0x87) SM DOs were obtained in supplied SM Response.
#define ERROR_SMRESPONSE_ENCDATA_AUTH_TAG_WRONG_PARAM		-11	///< Error constant indicating that wrong tag parameters(incorrect crypto specs) were provided with 0x87(ENDATA_AUTH) SM tag in supplied SM Response taglist.
#define ERROR_SMRESPONSE_ENCDATA_TAG_WRONG_PARAM		-12	///< Error constant indicating that wrong tag parameters(incorrect crypto specs) were provided with 0x86(ENDATA) SM tag in supplied SM Response taglist.
#define ERROR_SMRESPONSE_CRYPTODO_AUTH_TAG_WRONG_PARAM		-13	///< Error constant indicating that wrong tag parameters(incorrect crypto specs) were provided with 0x83(ENDATA_AUTH) SM tag in supplied SM Response taglist.
#define ERROR_SMRESPONSE_CRYPTODO_TAG_WRONG_PARAM		-14	///< Error constant indicating that wrong tag parameters(incorrect crypto specs) were provided with 0x82(ENDATA) SM tag in supplied SM Response taglist.
#define ERROR_SMRESPONSE_UNEXPECTED_SMDO_OBTAINED		-15	///< Error constant indicating that an unexpected SM DO was obtained in the supplied SM Response.
#define ERROR_SMRESPONSE_NO_SMDO_CORRESPONDING_TO_DO_TAG	-16	///< Error constant indicating that no matching DO was found corresponding to TAG_SM_DO SM tags supplied in SM Response taglist.
#define ERROR_SMCOMMAND_CC_TAG_WRONG_PARAM    			-17	///< Error constant indicating wrong parameters of CC(0x8E) tag in SM Command tag list
#define ERROR_SMCOMMAND_ENCDATA_TAG_WRONG_PARAM			-18	///< Error constant indicating wrong parameters of ENCDATA(0x86) tag in SM Response tag list
#define ERROR_SMCOMMAND_ENCDATA_AUTH_TAG_WRONG_PARAM		-19	///< Error constant indicating wrong parameters of ENCDATA(0x86) tag in SM Response tag list
#define ERROR_SMCOMMAND_ENVELOPE_TAG_WRONG_PARAM		-20	///< Error constant indicating wrong parameters of ENCDATA(0x86) tag in SM Response tag list
#define ERROR_SMCOMMAND_ENVELOPE_AUTH_TAG_WRONG_PARAM		-21	///< Error constant indicating wrong parameters of ENCDATA(0x86) tag in SM Response tag list
#define ERROR_SMCOMMAND_CRYPTODO_TAG_WRONG_PARAM		-22	///< Error constant indicating wrong parameters of CRYPTODO(0x82) tag in SM Response tag list
#define ERROR_SMCOMMAND_CRYPTODO_AUTH_TAG_WRONG_PARAM		-23	///< Error constant indicating wrong parameters of CRYPTODO(0x82) tag in SM Response tag list
#define ERROR_SM_TAG_REQUIRES_ALGO_SPECS_AND_SMCONTEXT_SUBLIST	-24	///< Error constant indicating that the SMContextEntry object for the SM Tag requires a cryptospec object and a SMContextList as sublist. 
#define ERROR_SM_TAG_REQUIRES_ALGO_SPECS			-25	///< Error constant indicating that the SMContextEntry object for the SM Tag requires a cryptosec object.
#define ERROR_SM_TAG_REQUIRES_SMCONTEXT_SUBLIST			-26	///< Error constant indicating that the SMContextEntry object for the SM tag requires a SMContextList as sublist.
#define ERROR_SM_TAG_REQUIRES_DATA_OBJECT			-27	///< Error constant indicating that the SMContextEntry object for the SM Tag requires a data object.
#define ERROR_INVALID_SM_TAG					-28	///< Error constant indicating that the supplied SM Tag is wrong(there is no SM tag with this value).

// Error constants defined corresponding to PCSClite Error constants:
#define PCSC_INVALID_VALUE			-29	///< Error constant corresponding to PCSClite error SCARD_E_INVALID_VALUE
#define PCSC_INVALID_HANDLE			-30	///< Error constant corresponding to PCSClite error SCARD_E_INVALID_HANDLE
#define PCSC_INSUFFICIENT_BUFFER		-31	///< Error constant corresponding to PCSClite error SCARD_E_INSUFFICIENT_BUFFER
#define PCSC_NO_READERS_AVAILABLE		-32	///< Error constant corresponding to PCSClite error SCARD_E_NO_READERS_AVAILABLE
#define PCSC_READER_UNAVAILABLE			-33	///< Error constant corresponding to PCSClite error SCARD_E_READER_UNAVAILABLE
#define PCSC_NO_SMARTCARD_PRESENT		-34	///< Error constant corresponding to PCSClite error SCARD_E_NO_SMARTCARD	
#define PCSC_READER_NOT_READY			-35	///< Error constant corresponding to PCSClite error SCARD_E_NOT_READY
#define PCSC_PROTOCOL_NOT_SUPPORTED		-36	///< Error constant corresponding to PCSClite error SCARD_E_UNSUPPORTED_FEATURE
#define PCSC_SHARING_VIOLATION			-37	///< Error constant corresponding to PCSClite error SCARD_E_SHARING_VIOLATION
#define PCSC_TRANSMISSION_ERROR			-38	///< Error constant corresponding to PCSClite error SCARD_E_NOT_TRANSACTED
#define PCSC_INVALID_PROTOCOL			-39	///< Error constant corresponding to PCSClite error SCARD_E_PROTO_MISMATCH
#define PCSC_SMARTCARD_RESET			-40	///< Error constant corresponding to PCSClite error SCARD_W_RESET_CARD
#define PCSC_NO_SERVICE				-41	///< Error constant corresponding to PCSClite error SCARD_E_NO_SERVICE
#define PCSC_NO_MEMORY				-42	///< Error constant corresponding to PCSClite error SCARD_E_NO_MEMORY
#define PCSC_CARD_REMOVED			-43	///< Error constant corresponding to PCSClite error SCARD_W_REMOVED_CARD
#define PCSC_UNPOWERED_CARD			-44	///< Error constant corresponding to PCSClite error SCARD_W_UNPOWERED_CARD
#define PCSC_UNRESPONSEIVE_CARD			-45	///< Error constant corresponding to PCSClite error SCARD_W_UNRESPONSIVE_CARD
#define PCSC_UNKNOWN_READER			-46	///< Error constant corresponding to PCSClite error SCARD_E_UNKNOWN_READER
#define PCSC_UNKNOWN_ERROR			-47	///< Error constant defined for any other PCSClite error.

// Return Constants 
#define CRYPTO_VERIFY_SUCCESS 		 0	///< Constant indicating the verification operation is successful.
#define CRYPTO_VERIFY_FAILURE 		-1	///< Constant indicating the verification operation is not successful.
#define CRYPTO_INCONSISTENT_INPUT 	-2	///< Constant indicating that the input(in buffer) supplied to the crypto function is not consistent with the crypto operation.
#define CRYPTO_INCONSISTENT_OUTPUT 	-3	///< Constant indicating that the output(out buffer) supplied is not sufficient to hold the output of the crypto algorithm.
#define CRYPTO_INCONSISTENT_KEY	 	-4	///< Constant indicating that the key supplied to the crypto function is not consistent with the crypto algorithm. 
#define CRYPTO_INCONSISTENT_IV 		-5	///< Constant indicating that the iv supplied to the crypto function is not consistent with the crypto algorithm.
#define CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION 	-6	///< Constant indicating dynamic memory allocation failure in Crypto library.
#define CRYPTO_LIBRARY_NOTFOUND		-7	///< Constant indicating the cryptographic library was not found.
#define CRYPTO_LIBRARY_FOUND		-8	///< Constant indicating the cryptographic library was found.
#define CRYPTO_OP_NOT_SUPPORTED		-9	///< Constant indicating the crypto operation is not supported by the crypto library.
#define CRYPTO_INTERNAL_ERROR		-10	///< Constant indicating that the crypto function fails due to some internal errors.

int return_PCSC_Error(LONG rv);
const char* cmdlib_stringify_error(int err);
