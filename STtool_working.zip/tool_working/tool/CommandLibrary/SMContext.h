#pragma once

#include "stdafx.h"
#include "CRT.h"
#include "crypto.h"

/**
 * \defgroup sm Secure Messaging
 * \brief This modules explains how Secure Messgaing is implemented and can be used by an application.
 *
 */

/*@{*/

/** \name Macros for Secure Messaging Tags */
/*@{*/
#define TAG_SM_DATA 		0x80 
#define TAG_SM_DATA_AUTH 	0x81
#define TAG_SM_CRYPTODO 	0x82
#define TAG_SM_CRYPTODO_AUTH 	0x83
#define TAG_SM_ENCDATA 		0x86
#define TAG_SM_ENCDATA_AUTH 	0x87
#define TAG_SM_CH_AUTH 		0x89
#define TAG_SM_CC 		0x8E
#define TAG_SM_LE 		0x96	
#define TAG_SM_LE_AUTH 		0x97
#define TAG_SM_STATUS 		0x99
#define TAG_SM_PLAINDO 		0xB0			
#define TAG_SM_PLAINDO_AUTH 	0xB1
#define TAG_SM_CCT 		0xB4
#define TAG_SM_CCT_AUTH 	0xB5
#define TAG_SM_CT 		0xB8
#define TAG_SM_CT_AUTH 		0xB9
#define TAG_SM_CHINCLUDE 	0x0C
#define TAG_SM_DO 		0xD0
#define TAG_SM_ENVELOPE		0xE0
#define TAG_SM_ENVELOPE_AUTH	0xE1
/*@}*/

class SMContextEntry;

/**
 * \brief List containg pointers to SM tags(SMContextEntry).
 *
 * SMContextEntry object pointers can be added to the list using push_back() function.
 * The SMContextEntry objects whise pointers are stored in the list are not deleted when the list is deleted. Thus it is the responsibility of 
 * the application to delete the SMContextEntry objects.
 */
typedef std::list<SMContextEntry*> SMContextList;

/** 
 * \brief Secure Messaging(SM) Context structure. This structure provides lists for managing the SM tags for SM command APDUs & SM response APDUs. 
 * 
 * It contains two lists:
 *	- SMCommandList	: This list contains SMContextEntry objects(SM tags) corresponding to SM DOs that must be provided in the SM command APDU by the IFD.
 *	- SMResponseList : This list contains SMContextEntry objects(SM tags) corresponding to SM DOs that might be present in the SM response APDU.
 *
 * The Command Library uses the SMCommandList for creating a secure messaging APDU corresponding to an plain APDU. The SMResponseList is used by Command Library for
 * extacting the protected response and protected status bytes from the SM response.
 *
 * \note It is the responsibility of the application to delete the SMContextEntry objects whose pointers are stored in the SMCommandList and SMResponseList.
 */
struct SMContext	{
	SMContextList SMCommandList;	///< SMContextList for managing command APDU tags
	SMContextList SMResponseList;	///< SMContextList for managing response APDU tags
};

/**
 * \brief This structure is an abstract representation of the SM tags. 
 *
 * A SM tag may have the following associated with it:
 *	- algorithm specifications : This defined the cryptographic algorithm's specifications to be used while creating/decoding the SM DO corresponding to the SM Tag.
 *	- a SM tag sublist : This defines a sub list of SM tags. 
 *	- a Data Object : This defines a Data Object(DO) that must be present in the SM DO corresponding to the SM tag.
 * 
 * List of SM tags(defined in SCOSTA-CL) and Macros defined in Command Library corresponding to them:
 *	- 0x80 : TAG_SM_DATA 
 *	- 0x81 : TAG_SM_DATA_AUTH
 *	- 0x82 : TAG_SM_CRYPTODO	- This SM tag requires a sublist(SMContextList) and an algorithm specification(cryptospec).
 *	- 0x83 : TAG_SM_CRYPTODO_AUTH	- This SM tag requires a sublist(SMContextList) and an algorithm specification(cryptospec).
 *	- 0x86 : TAG_SM_ENCDATA		- This SM tag requires an algorithm specification(cryptospec).
 *	- 0x87 : TAG_SM_ENCDATA_AUTH	- This SM tag requires an algorithm specification(cryptospec).
 *	- 0x89 : TAG_SM_CH_AUTH
 *	- 0x8E : TAG_SM_CC		- This SM tag requires an algorithm specification(cryptospec).
 *	- 0x96 : TAG_SM_LE
 *	- 0x97 : TAG_SM_LE_AUTH
 *	- 0x99 : TAG_SM_STATUS
 *	- 0xB0 : TAG_SM_PLAINDO	- This SM tag requires a sublist(SMContextList).
 *	- 0xB1 : TAG_SM_PLAINDO_AUTH	- This SM tag requires a sublist(SMContextList).
 *	- 0xB4 : TAG_SM_CCT		- This SM tag requires a DO object conataing the Control Reference Templates(CRT).
 *	- 0xB5 : TAG_SM_CCT_AUTH	- This SM tag requires a DO object conataing the Control Reference Templates(CRT).
 *	- 0xB8 : TAG_SM_CT		- This SM tag requires a DO object conataing the Control Reference Templates(CRT).
 *	- 0xB9 : TAG_SM_CT_AUTH		- This SM tag requires a DO object conataing the Control Reference Templates(CRT).
 * 
 * Four other special macros are also available:
 *	- 0x0C : TAG_SM_CHINCLUDE	- An SMContextEntry object corresponding to this tag signifies that while constructing the SM command APDU 
 *						the command header must also be included in crypto checksum.
 *	- 0xD0 : TAG_SM_DO		- SMContextEntry object corresponding to this tag reuires an DO object. The corresponding object will be added 
 *						in the SM command APDU as it is. No form of processing will be done corresponding to this tag.
 *	- 0xE0 : TAG_SM_ENVELOPE	- A SMContextEntry object corresponding to this tag signifies that the APDU will sent as an SM ENVELOPE with 
 *						the cryptogram in an 86 SM DO. This SM tag requires an algorithm specification(cryptospec).
 *	- 0xE1 : TAG_SM_ENVELOPE_AUTH	- A SMContextEntry object corresponding to this tag signifies that the APDU will sent as an SM ENVELOPE with 
 *						the cryptogram in an 87 SM DO. This SM tag requires an algorithm specification(cryptospec).
 *
 * A number of macro functions have been defined for creating SMContextEntry objects corresponding to the above defined SM tags.
 */
class SMContextEntry {
	public:
	BYTE tag;				///< tag number of the tag.
	cryptospec *algo;			///< algorithm associated with the tag
	const SMContextList *contextList;	///< SMtag sublist associated with the tag
	const DO *generic_do;			///< Data Object associated with the tag

	SMContextEntry(WORD tag, cryptospec *algo=NULL, const SMContextList *contextList=NULL, const DO *generic_do=NULL);
};

/** \name Macros for Creating SMContextEntry Objects */
/*@{*/
#define SMContextEntry_DATA() new SMContextEntry(TAG_SM_DATA)	///< Creates SMContextEntry object with SM tag TAG_SM_DATA .
#define SMContextEntry_DATA_AUTH() new SMContextEntry(TAG_SM_DATA_AUTH)		///< Creates an SMContextEntry object with SM tag TAG_SM_DATA_AUTH .

/**
 * Creates a SMContextEntry object with SM tag TAG_SM_CRYPTODO .
 * It takes crypto(pointer to an object of cryptospec) and SMList(pointer to an object of SMontextList) as inputs.
 * crypto defines the cryptogram to be used for confidentiality and SMList contains the inner SM tags.
 */
#define SMContextEntry_CRYPTODO(crypto, SMList) new SMContextEntry(TAG_SM_CRYPTODO, crypto, SMList)

/**
 * Creates a SMContextEntry object SM tag TAG_SM_CRYPTODO_AUTH .
 * It takes crypto(pointer to an object of cryptospec) and SMList(pointer to an object of SMontextList) as inputs.
 * crypto defines the cryptogram to be used for confidentiality and SMList contains the inner SM tags.
 */
#define SMContextEntry_CRYPTODO_AUTH(crypto, SMList) new SMContextEntry(TAG_SM_CRYPTODO_AUTH, crypto, SMList)	

/** 
 * Creates a SMContextEntry object with SM tag TAG_SM_ENCDATA .
 * It takes crypto(pointer to an object of cryptospec) as input, which defines the cryptogram to be used for confidentiality.
 */
#define SMContextEntry_ENCDATA(crypto) new SMContextEntry(TAG_SM_ENCDATA, crypto)

/**
 * Creates a SMContextEntry object with SM tag TAG_SM_ENCDATA_AUTH . 
 * It takes crypto(pointer to an object of cryptospec) as input, which defines the cryptogram to be used for confidentiality.
 */
#define SMContextEntry_ENCDATA_AUTH(crypto) new SMContextEntry(TAG_SM_ENCDATA_AUTH, crypto)

/** 
 * Creates a SMContextEntry object with SM tag TAG_SM_ENVELOPE.
 * It takes crypto(pointer to an object of cryptospec) as input, which defines the cryptogram to be used for confidentiality.
 */
#define SMContextEntry_ENVELOPE(crypto) new SMContextEntry(TAG_SM_ENVELOPE, crypto)

/**
 * Creates a SMContextEntry object with SM tag TAG_SM_ENVELOPE_AUTH . 
 * It takes crypto(pointer to an object of cryptospec) as input, which defines the cryptogram to be used for confidentiality.
 */
#define SMContextEntry_ENVELOPE_AUTH(crypto) new SMContextEntry(TAG_SM_ENVELOPE_AUTH, crypto)

#define SMContextEntry_CH_AUTH() new SMContextEntry(TAG_SM_CH_AUTH)	///< Creates a SMContextEntry object with SM tag TAG_SM_CH_AUTH .

/**
 * Creates a SMContextEntry object with SM tag TAG_SM_CC .
 * It takes a crypto(pointer to an object of cryptospec) as input, which defines the cryptographic checksum algorithm specifications.
 */
#define SMContextEntry_CC(crypto) new SMContextEntry(TAG_SM_CC, crypto)		

#define SMContextEntry_LE() new SMContextEntry(TAG_SM_LE)	///< Creates a SMContextEntry object with SM tag TAG_SM_LE . 
#define SMContextEntry_LE_AUTH() new SMContextEntry(TAG_SM_LE_AUTH)	///< Creates a SMContextEntry object with SM tag TAG_SM_LE_AUTH . 
#define SMContextEntry_STATUS() new SMContextEntry(TAG_SM_STATUS)	///< Creates a SMContextEntry object with SM tag TAG_SM_STATUS tag. 

/**
 * Creates a SMContextEntry object with SM tag TAG_SM_PLAINDO .
 * It takes as input a SMList(pointer to an SMContextList object) which contains the inner SM tags.
 */
#define SMContextEntry_PLAINDO(SMList) new SMContextEntry(TAG_SM_PLAINDO, NULL, SMList)

/**
 * Creates a SMContextEntry object with SM tag TAG_SM_PLAINDO_AUTH .
 * It takes as input a SMList(pointer to an SMContextList object) which contains the inner SM tags.
 */
#define SMContextEntry_PLAINDO_AUTH(SMList) new SMContextEntry(TAG_SM_PLAINDO_AUTH, NULL, SMList)

/**
 * Creates a SMContextEntry object with SM tag TAG_SM_CCT .
 * It takes as input crt(pointer to a DO object), which defines the CCT control reference data(CRT).
 */
#define SMContextEntry_CCT(crt) new SMContextEntry(TAG_SM_CCT, NULL, NULL, (DO *)crt)

/**
 * Creates a SMContextEntry object with SM tag TAG_SM_CCT_AUTH .
 * It takes as input crt(pointer to a DO object), whcih defines the CCT control reference data(CRT).
 */
#define SMContextEntry_CCT_AUTH(crt) new SMContextEntry(TAG_SM_CCT_AUTH, NULL, NULL, (DO *)crt)

/**
 * Creates a SMContextEntry object with SM tag TAG_SM_CT.
 * It takes as input crt(pointer to a DO object), whcih defines the CT control reference data(CRT).
 */
#define SMContextEntry_CT(crt) new SMContextEntry(TAG_SM_CT, NULL, NULL, (DO *)crt)

/**
 * Creates a SMContextEntry object with SM tag TAG_SM_CT .
 * It takes as input crt(pointer to a DO object), whcih defines the CT control reference data(CRT).
 */
#define SMContextEntry_CT_AUTH(crt) new SMContextEntry(TAG_SM_CT_AUTH, NULL, NULL, (DO*)crt)

#define SMContextEntry_CHINCLUDE() new SMContextEntry(TAG_SM_CHINCLUDE)	///< Creates a SMContextEntry object with SM tag TAG_SM_CHINCLUDE . 

/**
 * Creates a SMContextEntry object with SM tag TAG_SM_DO . 
 * It takes as input generic_do, whcih is a pointer to a DO object.
 */
#define SMContextEntry_DO(generic_do) new SMContextEntry(TAG_SM_DO, NULL, NULL, generic_do)
/*@}*/

/*@}*/
