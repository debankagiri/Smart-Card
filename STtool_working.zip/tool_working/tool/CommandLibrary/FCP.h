#pragma once

#include "stdafx.h"
#include "Compact.h"
#include "Expanded.h"
#include "SE.h"

// Constants defined for File Descriptor Byte(FDB).
#define FDB_SHAREABLE 0x40		///< FDB for "shareable file".
#define FDB_NOT_SHAREABLE 0x00		///< FDB for "Not shareable file".
#define FDB_DF 0x38			///< FDB for file type as DF.
#define	FDB_WORKING_EF 0x00		///< FDB for file type as working EF.
#define FDB_INTERNAL_EF 0x08		///< FDB for file type as internal EF.
#define	FDB_TRANSPARENT 0x01		///< FDB for EF structure as "transparent".
#define	FDB_LINEAR_FIXED 0x02		///< FDB for EF structure as "linear fixed,no further info".
#define	FDB_LINEAR_FIXED_TLV 0x03	///< FDB for EF structure as "linear fixed,SIMPLE-TLV".
#define FDB_LINEAR_VARIABLE 0x04	///< FDB for EF structure as "linear variable,no further info".
#define	FDB_LINEAR_VARIABLE_TLV 0x05	///< FDB for EF structure as "linear variable,SIMPLE-TLV".
#define FDB_CYCLIC 0x06			///< FDB for EF structure as "Cyclic,no further info".
#define	FDB_CYCLIC_TLV 0x07		///< FDB for EF structure as "Cyclic,SIMPLE-TLV".

// Constants defined for DCB
#define DCB_WRITE_ONCE 0x01 		///< Data coding byte(DCB) describing behaviour of write functions as "one-time write".
#define DCB_WRITE_OR 0x41		///< Data coding byte(DCB) describing behaviour of write functions as "write OR".
#define DCB_WRITE_AND 0x61		///< Data coding byte(DCB) describing behaviour of write functions as "write AND".

using namespace std;

/** 
 * \brief This class introduces FCP(File Control Parameter) as a collection or List of DOs.
 *
 * It has been extended over DOList Class.
 * \note Convention for parameter passing: 
 * 	Whenever the length of "Value" field is fixed by SCOSTA standards implicitly,there is no need of giving length.
 *	If "Value" is of variable length then user has to specify the length explicitly.
 */
class FCP : private DOList	{
public:
	FCP(WORD file_id);
	
	int addDOtoFCP(const DO& do_arg);
	int setFileSize(WORD size);
	int setFD(BYTE FDB);
	int setFD(BYTE FDB, BYTE DCB);
	int setFD(BYTE FDB, BYTE DCB, WORD MRL, WORD no_record);
	int setDFname(WORD length, const BYTE *DF_name);
	int setShortfid(BYTE short_fid);
	int setLCSI(BYTE LCSI);

	int setSE(const SE& se);
	int setSE(WORD fileid);
	int setSA(const CompactAccessRule& obj);
	int setSA(const list<CompactAccessRule>& collection);
	int setSA(const ExpandedAccessRule& obj);
	int setSA(const list<ExpandedAccessRule>& collection);

	int getFCPValueLength(void) const;
	int getFCPLength(void) const;
	int getTotalBytes(BYTE *buffer) const;	
};
