#include "APDU.h"

/** 
 * Default Constructor.
 * Initalizes all the fields and members of APDU object to Zero or NULL. 
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception constant indicating dynamic memory failure.
 */
APDU::APDU(void)	{
	this->data = NULL;
	this->response = NULL;
	int return_code = setAPDU(0, 0, 0, 0, 0, NULL, 0, NULL);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Copy Constructor. Creates a new copy of the APDU.
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception constant indicating dynamic memory failure.
 */
APDU::APDU(
	const APDU& APDU_arg  	///< Reference to the APDU object whose copy is to be made.
)	{
	this->data = NULL;
	this->response = NULL;
	int return_code;
	return_code = setAPDU(APDU_arg.getCLA(), APDU_arg.getINS(), APDU_arg.getP1(), APDU_arg.getP2(), APDU_arg.getLc(), 
				APDU_arg.getData(), APDU_arg.getLe(), APDU_arg.getFunc_cb());

	this->Le_rcv = APDU_arg.getLe_rcv();
	memcpy(this->response, APDU_arg.getResponse(), this->Le_rcv);

  	this->SW1 = APDU_arg.getSW1();
	this->SW2 = APDU_arg.getSW2();
}

/** 
 * Constructor, initializes the data memeber of apdu.
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception constant indicating dynamic memory failure.
 */
APDU::APDU(
	BYTE CLA,			///< Class Byte which indicates the class of the command.
    	BYTE INS,			///< Instruction Byte which indicates the command to process.
    	BYTE P1,			///< Parameter Byte 1.
    	BYTE P2,			///< Parameter Byte 2.
    	int Lc,				///< Length of Lc_buffer i.e. the Data field.
    	const BYTE *Lc_buffer,		///< Command Data field.
    	int Le,				///< Expected length of the Response - Zero(0) means no response is expected.
	func_callback func_cb		///< Call back function pointer for logging.
)	{
	this->data = NULL;
	this->response = NULL;
	int return_code = setAPDU(CLA, INS, P1, P2, Lc, Lc_buffer, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/** 
 * Constructor, initializes all the values except Lc(initialized to 0), data(initialized to NULL) accordingly.
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception constant indicating dynamic memory failure.
 */
APDU::APDU(
	BYTE CLA,			///< Class Byte which indicates the class of the command.
    	BYTE INS,			///< Instruction Byte which indicates the command to process.
    	BYTE P1,			///< Parameter Byte 1.
    	BYTE P2,			///< Parameter Byte 2.
    	int Le,				///< Expected length of the Response - Zero(0) means no response is expected.
	func_callback func_cb		///< Call back function pointer for logging.
)	{
	this->data = NULL;
	this->response = NULL;
  	int return_code = setAPDU(CLA, INS, P1, P2, 0, NULL, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/** 
 * Constructor, initializes all the values except CLA(implicity assumed to be '00') accordingly.
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception constant indicating dynamic memory failure.
 */
APDU::APDU(
	BYTE INS,			///< Instruction Byte which indicates the command to process.
    	BYTE P1,			///< Parameter Byte 1.
    	BYTE P2,			///< Parameter Byte 2.
    	int Lc,				///< Length of Lc_buffer, i.e., Data field.
    	const BYTE *Lc_buffer,		///< Command data field.
    	int Le,				///< Expected length of the Response - Zero(0) means no response is expected.
	func_callback func_cb		///< Call back function pointer for logging.
)	{
	this->data = NULL;
	this->response = NULL;
  	int return_code = setAPDU(0, INS, P1, P2, Lc, Lc_buffer, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/** 
 * Constructor, initializes all the values except CLA(implicity assumed to be '00'), 
 * Lc(initialized to 0), data(initialized to NULL) accordingly.
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception constant indicating dynamic memory failure.
 */
APDU::APDU(
	BYTE INS,			///< Instruction Byte which indicates the command to process.
    	BYTE P1,			///< Parameter Byte 1.
    	BYTE P2,			///< Parameter Byte 2.
    	int Le,				///< Expected length of the Response - Zero(0) means no response is expected.
	func_callback func_cb		///< Call back function pointer for logging.
)	{
	this->data = NULL;
	this->response = NULL;
  	int return_code = setAPDU(0, INS, P1, P2, 0, NULL, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Frees the memory occupied by data & response
 */
APDU::~APDU(void)
{
  	if(this->data != NULL)	free(this->data);
  	if(this->response != NULL)	free(this->response);
  	this->data = NULL;
  	this->response = NULL;
}

/**
 * Function to do padding. 
 * \return This function returns true if padding is done and false when no padding is done.
 */
bool APDU::DoPadding(
	int *plen, 		///< pointer to size of buffer. Initially it gives the size of buffer and at he end it stores the length of buffer after padding.
	BYTE *buffer, 		///< pointer to buffer to be padded
	int blksize, 		///< block size for which the padding has to be done.
	int forcepad		///< if set to 1 then padding is necessarily done, else padding may happen or not.
)	{
	int len = *plen;
	if(forcepad || (len % blksize) || (len < blksize))	buffer[len++] = 0x80;
	while (len % blksize)	buffer[len++] = 0x00;
	if(*plen == len)	return false;
	*plen = len;
	return true;
}

/**
 * Function to remove padding. 
 */
void APDU::UndoPadding(
	BYTE *buffer, 		///< pointer to buffer from which the padding has to be removed.
	int *buflen		///< pointer to the length of buffer.
) const	{
  	int len = *buflen;
  	while(len && (buffer[len-1] == 0))	len--;
  	if (buffer[len-1] == 0x80)	len--;
  	else len = *buflen;	// Restore the length as there was no 80000 kind of padding
  	*buflen = len;
}

/**
 * Function to remove padding. 
 */
void APDU::UndoPaddingTLV(
	BYTE *buffer, 
	int *buflen
) const	{
	int len = *buflen;
	// First try UndoPadding
	UndoPadding(buffer, buflen);
	if (*buflen == len) return; // There was no 800000
	// Now check if the DO structure is maintained.
	BYTE temp_len = 0;
	while (temp_len < *buflen) {
		temp_len += (2 + buffer[temp_len+1]);
	}
	if (temp_len == *buflen) return;
	// Restore length since the DO strucutre was appropriate
	*buflen = len;
}

/**
 * Creates Secure Messaging Data Objects(SM DOs) and adds then to the supplied DOList.
 *
 * The SM Command Taglist should not contain tags other than the following tags:
 *	- TAG_SM_DO
 *	- TAG_SM_CCT
 *	- TAG_SM_CCT_AUTH
 *	- TAG_SM_CT
 *	- TAG_SM_CT_AUTH
 *	- TAG_SM_CHINCLUDE
 *	- TAG_SM_CH_AUTH
 *	- TAG_SM_DATA
 *	- TAG_SM_DATA_AUTH
 *	- TAG_SM_ENCDATA
 *	- TAG_SM_ENCDATA_AUTH
 *	- TAG_SM_PLAINDO
 *	- TAG_SM_PLAINDO_AUTH
 *	- TAG_SM_CRYPTODO_AUTH
 *	- TAG_SM_CC
 *	- TAG_SM_LE
 *	- TAG_SM_LE_AUTH
 *
 * This function first check whether the provided SM Command tags are correct or not. These check are as follows:
 *	- 1. TAG_SM_DO, TAG_SM_CCT, TAG_SM_CCT_AUTH, TAG_SM_CT & TAG_SM_CT_AUTH tags should contain a DO(generic_do).
 *	- 2. TAG_SM_ENDATA, TAG_SM_ENCDATA_AUTH & TAG_SM_CC tags should contain a crypto specfication(algo).
 *	- 3. TAG_SM_PLAINDO & TAG_SM_PLAINDO_AUTH tags should contain a SMContextList sub list(contextList).
 *	- 4. TAG_SM_CRYPTODO & TAG_SM_CRYPTODO_AUTH tags should contain a crypto specification(algo) and a SMContextList sub list(contextList).
 * 
 * The SM DOs are created based on the supplied SM Tags supplied in SMContextList SM command list.
 *
 * \note The SM DOs corresponding to TAG_SM_DATA, TAG_SM_DATA_AUTH, TAG_SM_ENCDATA & TAG_SM_ENCDATA_AUTH tags are only created when protected APDU has 
 *	some data(Nc of protected APDU  > 0)
 *
 * \return This function returns one of the following constants:
 *	- NOERROR 						: It indicates that the function executed successfully.
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION 			: It indicates dynamic memory allocation failure.
 *	- ERROR_WRONG_INPUT_PARAMETERS 				: It indicates that wrong input parameters were supplied while creating SM DO objects.
 *	- ERROR_INVALID_SM_TAG 					: It indicates that the supplied SM list contains an invalid tag(tags other than the above listed ones).
 *	- ERROR_SM_TAG_REQUIRES_ALGO_SPECS			: It indicates that check 2 on supplied SM Command tags failed.
 *	- ERROR_SM_TAG_REQUIRES_DATA_OBJECT			: It indicates that check 1 on supplied SM Command tags failed.
 *	- ERROR_SM_TAG_REQUIRES_SMCONTEXT_SUBLIST		: It indicates that check 3 on supplied SM Command tags failed.
 *	- ERROR_SM_TAG_REQUIRES_ALGO_SPECS_AND_SMCONTEXT_SUBLIST: It indicates that check 4 on supplied SM Command tags failed.
 *	- ERROR_SMCOMMAND_CC_TAG_WRONG_PARAM 			: It indicates that Cryptographic Checksum Computation operation failed while creating CC SM DO.
 *	- ERROR_SMCOMMAND_ENCDATA_TAG_WRONG_PARAM 		: It indicates that Encryption operation filed while creating ENCDATA SM DO.
 *	- ERROR_SMCOMMAND_ENCDATA_AUTH_TAG_WRONG_PARAM 		: It indicates that Encryption operation failed while creating ENDATA_AUTH SM DO.
 *	- ERROR_SMCOMMAND_CRYPTODO_TAG_WRONG_PARAM 		: It indicates that Encryption operation failed while creating CRYPTODO SM DO.
 *	- ERROR_SMCOMMAND_CRYPTODO_AUTH_TAG_WRONG_PARAM 	: It indicates that Encryption operation failed while creating CRYPTODO_AUTH SM DO.
 */
int APDU::calContext(
	const SMContextList* ctx, 	///< SM command tag list
	DOList& SMDO_list		///< Reference to DoList in which the various SM Dos will be added.
)	{
  	for(SMContextList::const_iterator p = ctx->begin(); p!=ctx->end(); p++)	{
		const SMContextEntry* smEntry = (const SMContextEntry*)(*p);
		BYTE tag = smEntry->tag;
		if((tag == TAG_SM_CHINCLUDE) || (tag == TAG_SM_CC))	continue;
		switch(tag) {
			case 0x80 : 
			case 0x81 : 
				{	
					if(Lc == 0)	break;
					DO sm_do(tag);
					int return_code = sm_do.setValue(Lc, data);
					if(return_code != NOERROR)	return return_code;

					return_code = SMDO_list.copyDOtoList(sm_do);
					if(return_code != NOERROR)	return return_code;
					break;
	        		}
			case 0xB4 :
			case 0xB8 :
			case 0xB5 :
			case 0xB9 :
			case 0xD0:
				{
					if(smEntry->generic_do == NULL)	return ERROR_SM_TAG_REQUIRES_DATA_OBJECT;
					int return_code = SMDO_list.copyDOtoList(*(smEntry->generic_do));
					if(return_code != NOERROR)	return return_code;
          				break;
				}
			case 0x89 :
				{	
					BYTE tdata[4];
					tdata[0] = CLA;
					tdata[1] = INS;
					tdata[2] = P1;
					tdata[3] = P2;

					DO sm_do(tag);
					int return_code = sm_do.setValue(4, tdata);
					if(return_code != NOERROR)	return return_code;

					return_code = SMDO_list.copyDOtoList(sm_do);
					if(return_code != NOERROR)	return return_code;
       					break;
				}
			case 0x96 :
			case 0x97 :
				{
					int tlen = 0;
					BYTE tdata[2];
					if(Le <= 256)	{
						tlen = 1;
						tdata[0] = (BYTE)Le;
					}
					else	{
						tlen = 2;
						tdata[0] = (BYTE)((Le & 0x0000FF00) >> 8);
						tdata[1] = (BYTE)(Le & 0x000000FF);
					}
          				
					DO sm_do(tag);
					int return_code = sm_do.setValue(tlen, tdata);
					if(return_code != NOERROR)	return return_code;

					return_code = SMDO_list.copyDOtoList(sm_do);
					if(return_code != NOERROR)	return return_code;
					break;
        			}
			case 0xB0 :
      			case 0xB1 :
	        		{	
					if(smEntry->contextList == NULL)	return ERROR_SM_TAG_REQUIRES_SMCONTEXT_SUBLIST;
					// if the sub taglist is empty then add a 0xB0/0xB1 SM DO with Zero length.
					DOList SMDO_list_tmp;
					DO sm_do(tag);
          				int return_code = calContext(smEntry->contextList, SMDO_list_tmp);
					if(return_code == NOERROR)	{
						return_code = sm_do.appendConstructedValue(SMDO_list_tmp);
						if(return_code != NOERROR)	return return_code;
					}
					else return return_code;
						
					return_code = SMDO_list.copyDOtoList(sm_do);
					if(return_code != NOERROR)	return return_code;
					break;
        			}
			case 0x86:
			case 0x87:
				{
					if(smEntry->algo == NULL)	return ERROR_SM_TAG_REQUIRES_ALGO_SPECS;
					
					if(this->Lc == 0)	break;

					int tdata_len = this->Lc;
					BYTE *tdata = NULL;
					
					int blksize = getBlockSize(*(smEntry->algo));
					if(blksize <= 0)	{
						if(blksize == CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
						switch(tag)	{
							case 0x86:	return ERROR_SMCOMMAND_ENCDATA_TAG_WRONG_PARAM;
							case 0x87:	return ERROR_SMCOMMAND_ENCDATA_AUTH_TAG_WRONG_PARAM;
						}
					}

					if((tdata = (BYTE*) malloc(tdata_len + blksize)) == NULL)
						return ERROR_DYNAMIC_MEMORY_ALLOCATION;
	
					memcpy(tdata, data, Lc);
	
					// Do Padding
					bool ispadded = DoPadding(&tdata_len, tdata, blksize, 0);
	
					// encrypt tdata and store cipher in tout.
					int tout_len = getOutLen(ENCRYPT, tdata, tdata_len, *(smEntry->algo));
					if(tout_len <= 0)	{	// getOutLen failed.
						free(tdata);
						if(tout_len == CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
						else	{
							switch(tag)	{
								case 0x86:	return ERROR_SMCOMMAND_ENCDATA_TAG_WRONG_PARAM;
								case 0x87:	return ERROR_SMCOMMAND_ENCDATA_AUTH_TAG_WRONG_PARAM;
							}
						}
						break;
					}
	
					BYTE *tout = (BYTE*) malloc(tout_len);
					if(tout == NULL)	{
						free(tdata);
						return ERROR_DYNAMIC_MEMORY_ALLOCATION;
					}
	
					tout_len = CryptoFunc(ENCRYPT, tdata, tdata_len, tout, tout_len, *(smEntry->algo));
					free(tdata);
					if(tout_len <= 0)	{	// CryptoFunc failed
						free(tout);
						if(tout_len == CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
						else	{
							switch(tag)	{
								case 0x86:	return ERROR_SMCOMMAND_ENCDATA_TAG_WRONG_PARAM;
								case 0x87:	return ERROR_SMCOMMAND_ENCDATA_AUTH_TAG_WRONG_PARAM;
							}
						}
						break;
					}
					
					int return_code = NOERROR;
					DO sm_do(tag);

					BYTE PI = (ispadded) ? 0x01 : 0x02;
					return_code = sm_do.setValue(1, &PI);
					if(return_code != NOERROR)	{
						free(tout);
						return return_code;
					}
					
					return_code = sm_do.appendValue(tout_len, tout);
					free(tout);
					if(return_code != NOERROR)	return return_code;

          				return_code = SMDO_list.copyDOtoList(sm_do);
					if(return_code != NOERROR)	return return_code;

					break;
				}
			case TAG_SM_ENVELOPE:
			case TAG_SM_ENVELOPE_AUTH:
				{
					if(smEntry->algo == NULL)	return ERROR_SM_TAG_REQUIRES_ALGO_SPECS;
					int blksize = getBlockSize(*(smEntry->algo));
					if(blksize <= 0)	{
						if(blksize == CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
						switch(tag)	{
							case TAG_SM_ENVELOPE:		return ERROR_SMCOMMAND_ENVELOPE_TAG_WRONG_PARAM;
							case TAG_SM_ENVELOPE_AUTH:	return ERROR_SMCOMMAND_ENVELOPE_AUTH_TAG_WRONG_PARAM;
						}
					}
					
					// APDU is coded in a buffer(the encoding s similar to T1 APDU TPDU transformation)
					int tdata_len = getTAPDUlen(SCARD_PROTOCOL_T1);
					BYTE *tdata = NULL;
					if((tdata = (BYTE*) malloc(tdata_len + blksize)) == NULL)
						return ERROR_DYNAMIC_MEMORY_ALLOCATION;
					getTAPDU(SCARD_PROTOCOL_T1, tdata);
	
					// Do Padding
					bool ispadded = DoPadding(&tdata_len, tdata, blksize, 0);
	
					// encrypt tdata and store cipher in tout.
					int tout_len = getOutLen(ENCRYPT, tdata, tdata_len, *(smEntry->algo));
					if(tout_len <= 0)	{	// getOutLen failed.
						free(tdata);
						if(tout_len == CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
						else	{
							switch(tag)	{
								case TAG_SM_ENVELOPE:		return ERROR_SMCOMMAND_ENVELOPE_TAG_WRONG_PARAM;
								case TAG_SM_ENVELOPE_AUTH:	return ERROR_SMCOMMAND_ENVELOPE_AUTH_TAG_WRONG_PARAM;
							}
						}
						break;
					}
	
					BYTE *tout = (BYTE*) malloc(tout_len);
					if(tout == NULL)	{
						free(tdata);
						return ERROR_DYNAMIC_MEMORY_ALLOCATION;
					}
	
					tout_len = CryptoFunc(ENCRYPT, tdata, tdata_len, tout, tout_len, *(smEntry->algo));
					free(tdata);
					if(tout_len <= 0)	{	// CryptoFunc failed
						free(tout);
						if(tout_len == CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
						else	{
							switch(tag)	{
								case TAG_SM_ENVELOPE:		return ERROR_SMCOMMAND_ENVELOPE_TAG_WRONG_PARAM;
								case TAG_SM_ENVELOPE_AUTH:	return ERROR_SMCOMMAND_ENVELOPE_AUTH_TAG_WRONG_PARAM;
							}
						}
						break;
					}
					
					int return_code = NOERROR;
					int sm_do_tag = 0x86;
					if(tag == TAG_SM_ENVELOPE_AUTH)	sm_do_tag = 0x87;

					DO sm_do(sm_do_tag);

					BYTE PI = (ispadded) ? 0x01 : 0x02;
					return_code = sm_do.setValue(1, &PI);
					if(return_code != NOERROR)	{
						free(tout);
						return return_code;
					}
					
					return_code = sm_do.appendValue(tout_len, tout);
					free(tout);
					if(return_code != NOERROR)	return return_code;

          				return_code = SMDO_list.copyDOtoList(sm_do);
					if(return_code != NOERROR)	return return_code;

					break;
				}
			case 0x82:
			case 0x83:
				{
					if((smEntry->algo == NULL) || (smEntry->contextList == NULL))	return ERROR_SM_TAG_REQUIRES_ALGO_SPECS_AND_SMCONTEXT_SUBLIST;

					int tdata_len = 0;
					BYTE *tdata = NULL;
					DOList SMDO_list_tmp;
	
					int return_code = calContext(smEntry->contextList, SMDO_list_tmp);
					if(return_code != NOERROR)	return return_code;
					tdata_len = SMDO_list_tmp.getConstructedLength();
	
					int blksize = getBlockSize(*(smEntry->algo));
					if(blksize <= 0)	{
						if(blksize == CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
						switch(tag)	{
							case 0x82:	return ERROR_SMCOMMAND_CRYPTODO_TAG_WRONG_PARAM;
							case 0x83:	return ERROR_SMCOMMAND_CRYPTODO_AUTH_TAG_WRONG_PARAM;
						}
					}

					if((tdata = (BYTE*) malloc(tdata_len + blksize)) == NULL)
						return ERROR_DYNAMIC_MEMORY_ALLOCATION;
	
					SMDO_list_tmp.getConstructedValue(tdata);
					
					// Do Padding
					DoPadding(&tdata_len, tdata, blksize, 0);
	
	
					// encrypt tdata and store cipher in tout.
					int tout_len = getOutLen(ENCRYPT, tdata, tdata_len, *(smEntry->algo));
					if(tout_len <= 0)	{	// getOutLen failed.
						free(tdata);
						if(tout_len == CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
						else	{
							switch(tag)	{
								case 0x82:	return ERROR_SMCOMMAND_CRYPTODO_TAG_WRONG_PARAM;
								case 0x83:	return ERROR_SMCOMMAND_CRYPTODO_AUTH_TAG_WRONG_PARAM;
							}
						}
						break;
					}
	
					BYTE *tout = (BYTE*) malloc(tout_len);
					if(tout == NULL)	{
						free(tdata);
						return ERROR_DYNAMIC_MEMORY_ALLOCATION;
					}
	
					tout_len = CryptoFunc(ENCRYPT, tdata, tdata_len, tout, tout_len, *(smEntry->algo));
					free(tdata);
					if(tout_len <= 0)	{	// CryptoFunc failed
						free(tout);
						if(tout_len == CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
						else	{
							switch(tag)	{
								case 0x82:	return ERROR_SMCOMMAND_CRYPTODO_TAG_WRONG_PARAM;
								case 0x83:	return ERROR_SMCOMMAND_CRYPTODO_AUTH_TAG_WRONG_PARAM;
							}
						}
						break;
					}
					
					DO sm_do(tag);

					return_code = sm_do.appendValue(tout_len, tout);
					free(tout);
					if(return_code != NOERROR)	return return_code;

          				return_code = SMDO_list.copyDOtoList(sm_do);
					if(return_code != NOERROR)	return return_code;

					break;
				}
			default:
				{
					return ERROR_INVALID_SM_TAG;
				}
		}
	}
	
	// computing TAG_SM_CC tags
	// If there are more than one TAG_SM_CC tags, then we add CC DO for each of these tags at the end of the tag list.
	// Command Library leaves it to the Smartcard to decide whether multiple CC DOs are accepted or not.
	for(SMContextList::const_iterator p = ctx->begin(); p != ctx->end(); p++)	{
		if((*p)->tag != TAG_SM_CC)	continue;

		cryptospec *tcrypto = (*p)->algo;
		if(tcrypto == NULL)	return ERROR_SM_TAG_REQUIRES_ALGO_SPECS;

		int blksize = getBlockSize(*tcrypto);
		if(blksize <= 0)	{
			if(blksize == CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
			return ERROR_SMCOMMAND_CC_TAG_WRONG_PARAM;
		}

		BYTE * cc_buffer = (BYTE*) malloc(VALUECHUNK);
		if(cc_buffer == NULL)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
		int cc_buffer_len = 0;

		BYTE last_tag = LAST_TAG_NONE;  

		// check if there is TAG_SM_CHINCLUDE. If it is there then include it in the computation of CC DO.
		for(SMContextList::const_iterator q = ctx->begin(); q != ctx->end(); q++)	{
			if((*q)->tag == TAG_SM_CHINCLUDE)	{
				cc_buffer[cc_buffer_len++] = 0x0C;
				cc_buffer[cc_buffer_len++] = INS;
				cc_buffer[cc_buffer_len++] = P1;
				cc_buffer[cc_buffer_len++] = P2;
				last_tag = LAST_TAG_EVEN;
			}
		}
	
		// populate cc_buffer
		for(DOList::const_iterator q = SMDO_list.begin(); q != SMDO_list.end(); q++)	{
			BYTE tag = (BYTE)q->getTag();
			int tlen = q->getTotalLength();
			if(tlen > 2)	{
				if(tag & 0x01)	{
					if(last_tag == LAST_TAG_EVEN)	DoPadding(&cc_buffer_len, cc_buffer, blksize, 1);	// pad cc_buffer
					
					// include sm_do in cc_buffer
					if((cc_buffer = (BYTE *)realloc(cc_buffer, cc_buffer_len + tlen + VALUECHUNK)) == NULL)
						return ERROR_DYNAMIC_MEMORY_ALLOCATION;
					q->getTotalBytes(cc_buffer+cc_buffer_len);
					cc_buffer_len += tlen;
					last_tag = LAST_TAG_ODD;
				}
				else	if(!(tag & 0x01) && (last_tag == LAST_TAG_ODD))	last_tag = LAST_TAG_EVEN;
			}
		}
		
		// compulsorily pad cc_buffer here
		DoPadding(&cc_buffer_len, cc_buffer, blksize, 1);

		// get the length of crypto checksum.
		int tout_len = getOutLen(CC_COMPUTE, cc_buffer, cc_buffer_len, *tcrypto);
		if(tout_len <= 0)	{	// getOutLen failed.
			free(cc_buffer);
			if(tout_len == CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
			else	return ERROR_SMCOMMAND_CC_TAG_WRONG_PARAM;
		}
		BYTE *tout = (BYTE*) malloc(tout_len);
		if(tout == NULL)	{
			free(cc_buffer);
			return ERROR_DYNAMIC_MEMORY_ALLOCATION;
		}
		tout_len = CryptoFunc(CC_COMPUTE, cc_buffer, cc_buffer_len, tout, tout_len, *tcrypto);
		free(cc_buffer);
		if(tout_len <= 0)	{	// CryptoFunc failed
			free(tout);
			if(tout_len == CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
			else	return ERROR_SMCOMMAND_CC_TAG_WRONG_PARAM;
		}
		DO sm_do(TAG_SM_CC);
		int return_code = sm_do.setValue(tout_len, tout);
		free(tout);
		if(return_code != NOERROR)	return return_code;

		return_code = SMDO_list.copyDOtoList(sm_do);
		if(return_code != NOERROR)	return return_code;
	}
	return NOERROR;
}

/**
 * Processes the SM Response received from the card and extracts the protected response APDU.
 * 
 * This function takes as input, pointer to a list(ctx) of SM tags expected in the SM response. This list consists of two types of SM tags:
 *	- Required Tags: These are SM tags with tag as TAG_SM_DO. These tags contain a data object with them. The data objects provided with these tags 
 *	must necessarily be present in the SM response in the same format.
 *	- Expected Tags: These are SM tags with tag other than TAG_SM_DO. SM respone may contain data objects with tag same as the SM tag.
 *
 * This function perfoms some structural checks on the provided SM reponse. These structural checks are as follows:
 *	- SM response must contain only these tags 0x80, 0x81, 0x86, 0x87, 0xB0, 0xB1, 0x82, 0x83, 0x8E, 0x99.
 *	- There should not be two data objects in SM response with same tags.
 *	- If a data object with tag 0x8E is present, it should be the last data object present in SM response.
 *	- If a data object with tag 0x99 is present, its value length should be 2.
 *	- If a data object with a recursive tag(0xB0, 0xB1, 0x82 & 0x83) is present, it should not contain recursive tags inside it.
 *	- Each data object present in SM response must either have same tag as an Expected tag or must exactly match a data object contained in a Required tag.
 *	- The data objects contained in supplied Required tags must necessarily be present in SM response. 
 *
 * This function also check whether the provided SM Response tags are correct or not. These check are as follows:
 *	- Check 1. TAG_SM_DO tags should contain a DO(generic_do).
 *	- Check 2. TAG_SM_ENCDATA, TAG_SM_ENCDATA_AUTH, TAG_SM_ENVELOPE, TAG_SM_ENVELOPE_AUTH & TAG_SM_CC tags should contain a crypto specfication(algo).
 *	- Check 3. TAG_SM_PLAINDO & TAG_SM_PLAINDO_AUTH tags should contain a SMContextList sub list(contextList).
 *	- Check 4. TAG_SM_CRYPTODO & TAG_SM_CRYPTODO_AUTH tags should contain a crypto specification(algo) and a SMContextList sub list(contextList).
 * 
 * This function basically works in three stages:
 *	- 1. Check whether SM Response tags provided are correct.
 *	- 2. Perform structural checks stated above on the SM response.
 *	- 3. If SM Response contains crypto checksum then verify integrity using the first Expected tag with TAG_SM_CC tag.
 *	- 4. Extract protected response APDU, using the Expected tags. If multiple Expected tags are provided for a SM tag then the first Expected tags is used for 
 *		processing the data object.
 *
 * \note If protected response data is present in multiple data objects in SM response then an error is reported.
 *
 * \return This function can return one of the following constants:
 *	- NOERROR						: indicates that the function returned normally.
 *	- ERROR_WRONG_INPUT_PARAMETERS				: indicates that wrong parameters were provided.
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION				: indicates that dynamic memory allocation failed.
 *	- ERROR_SM_TAG_REQUIRES_ALGO_SPECS			: It indicates that check 2 on supplied SM Response tags failed.
 *	- ERROR_SM_TAG_REQUIRES_DATA_OBJECT			: It indicates that check 1 on supplied SM Response tags failed.
 *	- ERROR_SM_TAG_REQUIRES_SMCONTEXT_SUBLIST		: It indicates that check 3 on supplied SM Response tags failed.
 *	- ERROR_SM_TAG_REQUIRES_ALGO_SPECS_AND_SMCONTEXT_SUBLIST: It indicates that check 4 on supplied SM Response tags failed.
 *	- ERROR_SMRESPONSE_INCORRECT_SMDO_OBTAINED		: indicates that an SM data object with tag other than 0x80, 0x81, 0x82, 0x83, 0x86, 
 *									0x87, 0xB0, 0xB1, 0x99, 0x8E obtained.
 *	- ERROR_SMRESPONSE_DUPLICATE_SMDOS_OBTAINED		: indicates that multiple SM data objects with same tags were obtained.
 *	- ERROR_SMRESPONSE_INCORRECT_CC_SMDO_OBTAINED		: indicates that 0x8E(cc) SM data object found in SM response was not at the end of SM context.
 *	- ERROR_SMRESPONSE_INCORRECT_STATUS_SMDO_OBTAINED	: indicates that 0x99(STATUS) SM data object found in SM response has wrong length.
 *	- ERROR_SMRESPONSE_CC_VERIFICATION_FAILED		: indicates that Crypto Chesksum verification of SM response failed.
 *	- ERROR_SMRESPONSE_MULTIPLE_RESPONSE_STATUS_OBTAINED	: indicates that multiple response 0x99 SM data objects were obtained.
 *	- ERROR_SMRESPONSE_MULTIPLE_RESPONSE_DATA_OBTAINED: indicates that multiple response(0x80, 0x81, 0x86, 0x87) SM data objects were obtained.
 *	- ERROR_SMRESPONSE_ENCDATA_AUTH_TAG_WRONG_PARAM		: indicates that wrong tag parameters(incorrect crypto specs) were provided with 
 *									0x87(ENDATA_AUTH) SM tag.
 *	- ERROR_SMRESPONSE_ENCDATA_TAG_WRONG_PARAM		: indicates that wrong tag parameters(incorrect crypto specs) were provided with 0x86(ENDATA) SM tag.
 *	- ERROR_SMRESPONSE_CRYPTODO_AUTH_TAG_WRONG_PARAM	: indicates that wrong tag parameters(incorrect crypto specs) were provided with 
 *									0x83(ENDATA_AUTH) SM tag.
 *	- ERROR_SMRESPONSE_CRYPTODO_TAG_WRONG_PARAM		: indicates that wrong tag parameters(incorrect crypto specs) were provided with 0x82(ENDATA) SM tag.
 *	- ERROR_SMRESPONSE_UNEXPECTED_SMDO_OBTAINED		: indicates that an unexpected SM data object was obtained.
 *	- ERROR_SMRESPONSE_NO_SMDO_CORRESPONDING_TO_DO_TAG	: indicates that a SM data object was not found for a Required Tag.
 */
int APDU::calResponse(
	const SMContextList* ctx,	///< pointer to the list of SM Tags expected in the SM response.
	int sm_response_len,		///< Length of the SM response buffer.
	const BYTE* sm_response		///< Buffer containing SM response from card.
)	{
	bool isSM_ENVELOPE = false;
	bool isSM_ENVELOPE_AUTH = false;
	// constructing the required list and the expected list
	SMContextList exp_list;
	DOList req_list;
	try	{
		for(SMContextList::const_iterator q = ctx->begin(); q != ctx->end(); q++)	{
			if((*q)->tag == TAG_SM_DO)	{
				if((*q)->generic_do == NULL)	return ERROR_SM_TAG_REQUIRES_DATA_OBJECT;
				req_list.push_back(*((*q)->generic_do));
			}
			else	{
				switch((*q)->tag)	{
					case TAG_SM_CC:
					case TAG_SM_ENCDATA:
					case TAG_SM_ENCDATA_AUTH:
					case TAG_SM_ENVELOPE:
					case TAG_SM_ENVELOPE_AUTH:
						if((*q)->algo == NULL)	return ERROR_SM_TAG_REQUIRES_ALGO_SPECS;
						break;
					case TAG_SM_PLAINDO:
					case TAG_SM_PLAINDO_AUTH:
						if((*q)->contextList == NULL)	return ERROR_SM_TAG_REQUIRES_SMCONTEXT_SUBLIST;
						break;
					case TAG_SM_CRYPTODO:
					case TAG_SM_CRYPTODO_AUTH:
						if(((*q)->algo == NULL) || ((*q)->contextList == NULL))	return ERROR_SM_TAG_REQUIRES_ALGO_SPECS_AND_SMCONTEXT_SUBLIST;
						break;
				}
				exp_list.push_back(*q);
			}
		}
	}
	catch(bad_alloc &)	{
		return ERROR_DYNAMIC_MEMORY_ALLOCATION;
	}
	catch(int exp)	{
		return exp;
	}

	// constructing the received list
	DOList recv_list; 
	int return_code = recv_list.setList(sm_response_len, sm_response);
	if(return_code != NOERROR)	return return_code;

	/* 
	structural checks on the received SM response:
		1. Only these tags(0x80, 0x81, 0x86, 0x87, 0xB0, 0xB1, 0x82, 0x83, 0x8E, 0x99) can be present in recv_list.
		2. There should not be duplicate tags in recv_list.
		3. 0x8E tags if present should be the last tag present in the recv_list.
		4. 0x99 tags if present should have length as 2.
		5. All the tags present in recv_list should be present in union of req_list and exp_list
		6. All the DOs present in the req_list should be present in recv_list.
	*/
	tag_do_map smdo_map;
	smdo_map.insert(make_pair(0x80, (const DO*)NULL));
	smdo_map.insert(make_pair(0x81, (const DO*)NULL));
	smdo_map.insert(make_pair(0x82, (const DO*)NULL));
	smdo_map.insert(make_pair(0x83, (const DO*)NULL));
	smdo_map.insert(make_pair(0x86, (const DO*)NULL));
	smdo_map.insert(make_pair(0x87, (const DO*)NULL));
	smdo_map.insert(make_pair(0xB0, (const DO*)NULL));
	smdo_map.insert(make_pair(0xB1, (const DO*)NULL));
	smdo_map.insert(make_pair(0x99, (const DO*)NULL));
	smdo_map.insert(make_pair(0x8E, (const DO*)NULL));

	for(DOList::const_iterator q = recv_list.begin(); q != recv_list.end(); q++)	{
		BYTE tag = (BYTE)q->getTag();
		tag_do_map::iterator it = smdo_map.find(tag);
		if(it == smdo_map.end())	return ERROR_SMRESPONSE_INCORRECT_SMDO_OBTAINED;	// check 1
		else	{
			if(it->second == NULL)	it->second = (const DO*)(&*q);	
			else	return ERROR_SMRESPONSE_DUPLICATE_SMDOS_OBTAINED;		// check 2;
		}
	}

	for(tag_do_map::const_iterator q = smdo_map.begin(); q != smdo_map.end(); q++)	{
		if((q->first == 0x8E) && (q->second != NULL))	{	// check 3
			if(recv_list.back().getTag() != 0x8E)	return ERROR_SMRESPONSE_INCORRECT_CC_SMDO_OBTAINED;
		}
		if((q->first == 0x99) && (q->second != NULL))	{	// check 4
			if(q->second->getLength() != 2)	return ERROR_SMRESPONSE_INCORRECT_STATUS_SMDO_OBTAINED;
		}
		if(q->second != NULL)	{	// check 5
			DOList::iterator p = req_list.begin();
			for( ; p != req_list.end(); p++)	{
				if(p->getTag() != q->second->getTag())	continue;

				int tlen = q->second->getLength();
				if(tlen != p->getLength())	continue;

				const BYTE* buf1 = q->second->getValue();
				const BYTE* buf2 = p->getValue();
				int i = 0;
				for( ; i < tlen; i++)	if(buf1[i] != buf2[i])	break;
				if(i == tlen)	break;
			}
			if(p != req_list.end())	req_list.erase(p);
			else	{
				SMContextList::const_iterator z = exp_list.begin();
				if(q->second->getTag() == 0x86)	{
					for(; z != exp_list.end(); z++)	if(((*z)->tag == TAG_SM_ENVELOPE) || ((*z)->tag == TAG_SM_ENCDATA))	break;
					if(z == exp_list.end())	return ERROR_SMRESPONSE_UNEXPECTED_SMDO_OBTAINED;
					else	{
						if((*z)->tag == TAG_SM_ENVELOPE)	isSM_ENVELOPE = true;
					}
				}
				else	{
					if(q->second->getTag() == 0x87)	{
						for(; z != exp_list.end(); z++)	if(((*z)->tag == TAG_SM_ENVELOPE_AUTH) || ((*z)->tag == TAG_SM_ENCDATA_AUTH))	break;
						if(z == exp_list.end())	return ERROR_SMRESPONSE_UNEXPECTED_SMDO_OBTAINED;
						else	{
							if((*z)->tag == TAG_SM_ENVELOPE_AUTH)	isSM_ENVELOPE_AUTH = true;
						}
					}
					else	{
						for(; z != exp_list.end(); z++)	if((*z)->tag == q->second->getTag())	break;
						if(z == exp_list.end())	return ERROR_SMRESPONSE_UNEXPECTED_SMDO_OBTAINED;
					}
				}
			}
		}
	}
	if(!req_list.empty())	return ERROR_SMRESPONSE_NO_SMDO_CORRESPONDING_TO_DO_TAG;	// check 6

	// verifying Integrity.
	if(recv_list.back().getTag() == TAG_SM_CC)	{
		SMContextList::const_iterator q = exp_list.begin();
		for( ; q != exp_list.end(); q++)	if((*q)->tag == TAG_SM_CC)	break;
		if(q != exp_list.end())	{
			BYTE *cc_buffer = NULL;
			int cc_buffer_len = 0;

			cryptospec *tcrypto = (*q)->algo;
			int blksize = getBlockSize(*tcrypto);
			if(blksize <= 0)	{
				if(blksize == CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
				return ERROR_SMRESPONSE_CC_TAG_WRONG_PARAM;
			}

			// contruct the cc_buffer
			for(DOList::const_iterator p = recv_list.begin(); p != recv_list.end(); p++)	{
				if(p->getTag() % 2) {
					int sm_do_len = p->getTotalLength();
					if((cc_buffer = (BYTE*) realloc(cc_buffer, cc_buffer_len + sm_do_len + VALUECHUNK)) == NULL)
						return ERROR_DYNAMIC_MEMORY_ALLOCATION;
					p->getTotalBytes(cc_buffer + cc_buffer_len);
					cc_buffer_len += sm_do_len;
				}
				else	DoPadding(&cc_buffer_len, cc_buffer, blksize, 1);
			}
	
			int return_code = CryptoFunc(CC_VERIFY, cc_buffer, cc_buffer_len, (BYTE*)recv_list.back().getValue(), recv_list.back().getLength(), *tcrypto);
			free(cc_buffer);
	
			if(return_code != CRYPTO_VERIFY_SUCCESS)	{
				if(return_code == CRYPTO_VERIFY_FAILURE)	return ERROR_SMRESPONSE_CC_VERIFICATION_FAILED;
				else	return ERROR_SMRESPONSE_CC_TAG_WRONG_PARAM;
			}
		}
	}
	
	// process SM DOs to extract the protected Response APDU
	// extracting the protected response APDU is guided by the Expected Tags.
	for(DOList::const_iterator p = recv_list.begin(); p != recv_list.end(); p++)	{
		BYTE tag = (BYTE)p->getTag();

		SMContextList::const_iterator q = exp_list.begin();
		if((tag == 0x86) && (isSM_ENVELOPE))	{
			for( ; q != exp_list.end(); q++)	if((*q)->tag == TAG_SM_ENVELOPE)	break;
		}
		else	{
			if((tag == 0x87) && (isSM_ENVELOPE_AUTH))	{
				for( ; q != exp_list.end(); q++)	if((*q)->tag == TAG_SM_ENVELOPE_AUTH)	break;
			}
			else	{
				for( ; q != exp_list.end(); q++)	if((*q)->tag == tag)	break;
			}
		}
		if(q == exp_list.end())	continue;	// tag not in expected list.

		switch(tag)	{
			case 0x99:
				{	
					if(!((this->SW1 == 0x00) && (this->SW2 == 0x00)))	return ERROR_SMRESPONSE_MULTIPLE_RESPONSE_STATUS_OBTAINED;

					const BYTE* tvalue = p->getValue();
					this->SW1 = *(tvalue);
					this->SW2 = *(tvalue+1);
					break;
				}
      			case 0x80: 
      			case 0x81:
        			{
					if(this->Le_rcv != -1)	return ERROR_SMRESPONSE_MULTIPLE_RESPONSE_DATA_OBTAINED;

					this->Le_rcv = p->getLength();
					if(this->Le_rcv > this->Le)	this->Le_rcv = this->Le;
					memcpy(this->response, p->getValue(), this->Le_rcv);
          				break;
        			}
			case 0x86:
			case 0x87:
        			{
					cryptospec *tcrypto = (*q)->algo;

					int tvalue_len = p->getLength();
					if(tvalue_len == 0)	break;
					
					const BYTE* tvalue = p->getValue();
        	  			BYTE PI = *tvalue; 	// Padding indicator byte

					int tout_len = getOutLen(DECRYPT, tvalue + 1, tvalue_len - 1, *tcrypto);
					if(tout_len <= 0)	{	// decryption failure report error.
					if(tout_len == CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
					else	if(tag & 0x01)	return ERROR_SMRESPONSE_ENCDATA_AUTH_TAG_WRONG_PARAM;
						else	return ERROR_SMRESPONSE_ENCDATA_TAG_WRONG_PARAM;
					}

					BYTE* tout = (BYTE*) malloc(tout_len);
					if(tout == NULL)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;

					tout_len = CryptoFunc(DECRYPT, tvalue+1, tvalue_len-1, tout, tout_len, *tcrypto);
					if(tout_len <= 0)	{	// decryption failure report error.
						free(tout);
						if(tout_len == CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
						else	if(tag & 0x01)	return ERROR_SMRESPONSE_ENCDATA_AUTH_TAG_WRONG_PARAM;
							else	return ERROR_SMRESPONSE_ENCDATA_TAG_WRONG_PARAM;
					}

		  			if(PI == 0x01) UndoPadding(tout, &tout_len);
					
					if(((*q)->tag == TAG_SM_ENVELOPE) || ((*q)->tag == TAG_SM_ENVELOPE_AUTH))	{
						if(!((this->SW1 == 0x00) && (this->SW2 == 0x00)))	return ERROR_SMRESPONSE_MULTIPLE_RESPONSE_STATUS_OBTAINED;
						this->SW1 = tout[tout_len-2];
						this->SW2 = tout[tout_len-1];
						if((this->Le_rcv != -1) && (tout_len > 2))	return ERROR_SMRESPONSE_MULTIPLE_RESPONSE_DATA_OBTAINED;
						this->Le_rcv = tout_len-2;
						if(this->Le_rcv > this->Le)	this->Le_rcv = this->Le;
						memcpy(this->response, tout, this->Le_rcv);
					}
					else	{
						if(this->Le_rcv != -1)	return ERROR_SMRESPONSE_MULTIPLE_RESPONSE_DATA_OBTAINED;
						this->Le_rcv = tout_len;
						if(this->Le_rcv > this->Le)	this->Le_rcv = this->Le;
						memcpy(this->response, tout, this->Le_rcv);
					}

					free(tout);
					break;
        			}
      			case 0xB0:
      			case 0xB1:
        			{
          				int return_code = calResponse((*q)->contextList, p->getLength(), p->getValue());
					if(return_code != NOERROR)	return return_code;
          				break;
        			}
      			case 0x82:
      			case 0x83:
        			{
					int tvalue_len = p->getLength();
					const BYTE* tvalue = p->getValue();
					
					int tout_len = 0;
					BYTE *tout = NULL;
					
					if(tvalue_len > 0)	{
						cryptospec *tcrypto = (*q)->algo;

						int tout_len = getOutLen(DECRYPT, tvalue, tvalue_len, *tcrypto);
						if(tout_len <= 0)	{	// decrypt failure report error.
							if(tout_len == CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
							else	if(tag & 0x01)	return ERROR_SMRESPONSE_CRYPTODO_AUTH_TAG_WRONG_PARAM;
								else	return ERROR_SMRESPONSE_CRYPTODO_TAG_WRONG_PARAM;
						}

						if((tout = (BYTE*) malloc(tout_len)) == NULL)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;

						tout_len = CryptoFunc(DECRYPT, tvalue, tvalue_len, tout, tout_len, *tcrypto);
						if(tout_len < 0)	{	// decrypt failure report error.
							free(tout);
							if(tout_len == CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
							else	if(tag & 0x01)	return ERROR_SMRESPONSE_CRYPTODO_AUTH_TAG_WRONG_PARAM;
								else	return ERROR_SMRESPONSE_CRYPTODO_TAG_WRONG_PARAM;
						}

						UndoPaddingTLV(tout, &tout_len);
					}
					int return_code = calResponse((*q)->contextList, tout_len, tout);
					free(tout);
					if(return_code != NOERROR)	return return_code;
					break;
				}
		}
	}
  	return NOERROR;
}

/**
 * Computes the length of the command TAPDU from command APDU depending on the protocol to be used.
 * \return Returns the length of command TAPDU
 */
int APDU::getTAPDUlen(
	DWORD protocol		///< protocol according to which the APDU has to be transmitted
)	{
	int tapdu_len = 4;	// CLA , INS, P1, P2
	if((protocol == SCARD_PROTOCOL_T1) || (protocol == SCARD_PROTOCOL_RAW)) {
    		if((Lc == 0) && (Le == 0))	tapdu_len += 0;
		else if(Lc == 0)	{
			if(Le <= 256)	tapdu_len++;
			else	tapdu_len +=3;
		}
		else if(Le == 0) {
			if(Lc > 255)	tapdu_len += 3+Lc;
			else	tapdu_len += 1+Lc;
		}
		else if((Lc > 255) || ((Le > 256)))	tapdu_len += 5+Lc;
		     else tapdu_len += 2+Lc;
	}
	else	{
		if((Lc ==0) && (Le == 0))	tapdu_len++;
		else	if(Lc > 0)	{
				if(Lc <= 255)	tapdu_len += 1+Lc;
				else	tapdu_len += 3+Lc;
			}
			else	{
				tapdu_len += 1;
			}
	}
	return tapdu_len;
}

/**
 * Constructs command TAPDU from command APDU depending on the protocol to be used.
 */
void APDU::getTAPDU(
	DWORD protocol,		///< protocol according to which the APDU has to be transmitted.
	BYTE *tapdu		///< Buffer for storing the calculated tapdu.
)	{
	if((protocol == SCARD_PROTOCOL_T1) || (protocol == SCARD_PROTOCOL_RAW)) {	// T1 Protocol or RAW protocol
    		if((Lc == 0) && (Le == 0)) {
			//tapdu[4] = 0;
		}
		else if(Lc == 0) {
			if((Le <= 256))	{
				tapdu[4] = (BYTE)(Le & 0x000000FF);
			}
			else	{
				tapdu[4] = 0x00;
				tapdu[5] = (BYTE)((Le & 0x0000FF00) >> 8);
				tapdu[6] = (BYTE)(Le & 0x000000FF);
			}
		}
		else if (Le == 0) {
			if(Lc > 255) {
				tapdu[4] = 0x00;
				tapdu[5] = (BYTE)((Lc & 0x0000FF00) >> 8);
				tapdu[6] = (BYTE)(Lc & 0x000000FF);
				memcpy(tapdu+7, data, Lc);
			} else {
				tapdu[4] = (BYTE)Lc;
				memcpy(tapdu+5, data, Lc);
			}
		}
		else {
			if((Lc > 255) || ((Le > 256))) {
				tapdu[4] = 0x00;
				tapdu[5] = (BYTE)((Lc & 0x0000FF00) >> 8);
				tapdu[6] = (BYTE)(Lc & 0x000000FF);
				memcpy(tapdu+7, data, Lc);
				tapdu[7+Lc] = (BYTE)((Le & 0x0000FF00) >> 8);
				tapdu[8+Lc] = (BYTE)(Le & 0x000000FF);
			} else {
				tapdu[4] = (BYTE)Lc;
				memcpy(tapdu+5, data, Lc);
				tapdu[5+Lc] = (BYTE)(Le & 0x000000FF);
			}
		}
	}
	else	{
		// T0 Protocol
		if((Lc == 0) && (Le == 0))	{
			tapdu[4] = 0;
		} else	{
			if(Lc > 0)	{
				if(Lc <= 255)	{
					tapdu[4] = (BYTE)(0x000000FF & Lc);
					memcpy(tapdu+5, data, Lc);
				} else	{
					tapdu[4] = 0x00;
					tapdu[5] = (BYTE)((Lc & 0x0000FF00) >> 8);
					tapdu[6] = (BYTE)(Lc & 0x000000FF);
					memcpy(tapdu+7, data, Lc);
				}
			} else	{
				if((Le <= 256))	{
					tapdu[4] = (BYTE)(Le & 0x000000FF);
				} else	{
					tapdu[4] = 0;
				}
			}
		}
	}
	tapdu[0] = CLA;
	tapdu[1] = INS; 
	tapdu[2] = P1;
	tapdu[3] = P2;
}

/**
 * This function transmits the TPDU corresponding to the apdu to card, receives the response and sets the response status bytes(SW1 & SW2).
 * \return Returns one of the following constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- PCSC_INSUFFICIENT_BUFFER
 *	- PCSC_INVALID_HANDLE
 *	- PCSC_INVALID_VALUE
 *	- PCSC_NO_SERVICE
 *	- PCSC_TRANSMISSION_ERROR
 *	- PCSC_INVALID_PROTOCOL
 *	- PCSC_READER_UNAVAILABLE
 *	- PCSC_SMARTCARD_RESET
 *	- PCSC_REMOVED_CARD
 */
int APDU::transmitAPDU(
	const Reader& reader	///< reference to Reader object to which the APDU has to be transmitted.
)	{
	if(func_cb)	(*func_cb)(LOG_CMD, LOG_EVENT_TRANSPORT, this);

	LPCSCARD_IO_REQUEST pioSendPci;
	DWORD proto, ctapdu_len, rtapdu_len;
	BYTE* ctapdu = NULL;

	proto = reader.getReaderProtocol();
	if(proto == SCARD_PROTOCOL_T0)	pioSendPci = SCARD_PCI_T0;
	if(proto == SCARD_PROTOCOL_T1)	pioSendPci = SCARD_PCI_T1;
	if(proto == SCARD_PROTOCOL_RAW)	pioSendPci = SCARD_PCI_RAW;

	// get TAPDU correspondifng to the protocol
	ctapdu_len = getTAPDUlen(proto);
	if((ctapdu = (BYTE*) malloc(sizeof(BYTE) * ctapdu_len)) == NULL)	
		return ERROR_DYNAMIC_MEMORY_ALLOCATION;
	getTAPDU(proto, ctapdu);

	if((proto == SCARD_PROTOCOL_T0) && (ctapdu_len > 260))	{
		// To Protocol Extended Lc: send in Envelope command
		for(DWORD offset = 0; offset < ctapdu_len; offset = offset+255)	{
			int tlc = ctapdu_len - offset;
			if(tlc > 255)	tlc = 255;
			APDU m(0x00, INS_CMD_GET_ENVELOPE, 0x00, 0x00, tlc, ctapdu+offset, 0, this->func_cb);
			m.transmitAPDU(reader);
			this->SW1 = m.getSW1();
			this->SW2 = m.getSW2();
			if((this->SW1 != 0x90) && (this->SW2 != 0x00))	break;
		}
		free(ctapdu);
		if((this->SW1 == 0x90) && (this->SW2 == 0x00))	{
			APDU m(0x00, INS_CMD_GET_ENVELOPE, 0x00, 0x00, 0, NULL, 0, this->func_cb);
			m.transmitAPDU(reader);
			this->SW1 = m.getSW1();
			this->SW2 = m.getSW2();
		}
	}
	else	{
		rtapdu_len = 2 + Le;
		LONG rv = SCardTransmit(reader.getHCard(), pioSendPci , ctapdu, ctapdu_len, NULL, this->response, &rtapdu_len);
		free(ctapdu);
		if (rv != SCARD_S_SUCCESS)	return return_PCSC_Error(rv);
		
		this->SW1 = this->response[rtapdu_len - 2];
		this->SW2 = this->response[rtapdu_len - 1];
		this->Le_rcv = rtapdu_len - 2;
	}

	if(func_cb)	(*func_cb)(LOG_RESP, LOG_EVENT_TRANSPORT, this);

	return NOERROR;
}

/** 
 * This function transmits the APDU to the smartcard and does some additional processing depending on the response status bytes.
 *
 * If SMContext is not supplied(i.e. SMContext is NULL), sendAPDU transmits the APDU to the smart card, and if the obtained SW1 is 0x61 it issues Get Response command 
 * to get the additional response data and if SW1 is 0x6C it retransmists the APDU again with the modified Le as SW2.
 *
 * If SMContext is supplied(i.e. SMContext is not NULL), sendAPDU first creates a secure messaging APDU(sm_apdu) using the calContext() function and 
 * the SMCommandList(list of SM tags) of the supplied SMContext. It then transmits the sm_apdu to the smart card.
 * On successfully receiving the sm response sendAPDU calls calResponse() function to process the sm response using the SMResponseList of the supplied SMContext
 * to extract the protected response APDU.
 *
 * \return Returns one of the follwoing constants:
 *	- NOERROR
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 *	- ERROR_WRONG_INPUT_PARAMETERS
 *	- ERROR_INVALID_SM_TAG
 *	- ERROR_SM_TAG_REQUIRES_ALGO_SPECS
 *	- ERROR_SM_TAG_REQUIRES_DATA_OBJECT
 *	- ERROR_SM_TAG_REQUIRES_SMCONTEXT_SUBLIST
 *	- ERROR_SM_TAG_REQUIRES_ALGO_SPECS_AND_SMCONTEXT_SUBLIST
 *	- ERROR_SMCOMMAND_CC_TAG_WRONG_PARAM
 *	- ERROR_SMCOMMAND_ENCDATA_TAG_WRONG_PARAM
 *	- ERROR_SMCOMMAND_ENCDATA_AUTH_TAG_WRONG_PARAM
 *	- ERROR_SMCOMMAND_CRYPTODO_TAG_WRONG_PARAM
 *	- ERROR_SMCOMMAND_CRYPTODO_AUTH_TAG_WRONG_PARAM
 *	- ERROR_SMRESPONSE_INCORRECT_SMDO_OBTAINED
 *	- ERROR_SMRESPONSE_DUPLICATE_SMDOS_OBTAINED
 *	- ERROR_SMRESPONSE_INCORRECT_CC_SMDO_OBTAINED
 *	- ERROR_SMRESPONSE_INCORRECT_STATUS_SMDO_OBTAINED
 *	- ERROR_SMRESPONSE_CC_VERIFICATION_FAILED
 *	- ERROR_SMRESPONSE_MULTIPLE_RESPONSE_STATUS_OBTAINED
 *	- ERROR_SMRESPONSE_MULTIPLE_RESPONSE_DATA_OBTAINED
 *	- ERROR_SMRESPONSE_ENCDATA_AUTH_TAG_WRONG_PARAM
 *	- ERROR_SMRESPONSE_ENCDATA_TAG_WRONG_PARAM
 *	- ERROR_SMRESPONSE_CRYPTODO_AUTH_TAG_WRONG_PARAM
 *	- ERROR_SMRESPONSE_CRYPTODO_TAG_WRONG_PARAM
 *	- ERROR_SMRESPONSE_UNEXPECTED_SMDO_OBTAINED
 *	- ERROR_SMRESPONSE_NO_SMDO_CORRESPONDING_TO_DO_TAG
 */
int APDU::sendAPDU(
	const Reader& reader,	///< reference to Reader object to which the APDU has to be transmitted.
	const SMContext *SM	///< SMContext Class object pointer according to which SM DOs would be addded in the SM APDU.
)	{
	int return_code = NOERROR;
	if(SM == NULL)	{
		if(func_cb)	(*func_cb)(LOG_CMD, LOG_EVENT_TRANSMIT, this);

		if((return_code = transmitAPDU(reader)) != NOERROR)	return return_code;
		
		while((this->SW1 == 0x61) & ((Le-Le_rcv) > 0))	{
			int tle = Le-Le_rcv;
			int tSW2 = (this->SW2 == 0) ? 256 : this->SW2;

			if(tSW2 < tle)	tle = tSW2;
			try	{
				APDU m(0x00, INS_CMD_GET_RESPONSE, 0, 0, 0, NULL, tle, this->func_cb);
				
				if(func_cb)	(*func_cb)(LOG_CMD, LOG_EVENT_AUTOGETRESPONSE, &m);

				return_code = m.transmitAPDU(reader);
				if(return_code != NOERROR)	return return_code;

				if(func_cb)	(*func_cb)(LOG_RESP, LOG_EVENT_AUTOGETRESPONSE, &m);

				this->SW1 = m.getSW1(); 
				this->SW2 = m.getSW2();
				int tLe_rcv = m.getLe_rcv();
				if(tLe_rcv > 0) {
					if(this->Le_rcv == -1)	this->Le_rcv = 0;
					memcpy(this->response + this->Le_rcv, m.getResponse(), tLe_rcv);
					this->Le_rcv += tLe_rcv;
				}
			}
			catch(int exp)	{
				return exp;
			}
		}
		
		if(this->SW1 == 0x6C)	{
			int tle = this->Le;
			this->Le = (this->SW2 == 0) ? 256 : this->SW2;
				
			if((this->response = (BYTE*) realloc(this->response, sizeof(BYTE) * this->Le)) == NULL)
				return ERROR_DYNAMIC_MEMORY_ALLOCATION;

			return_code = this->transmitAPDU(reader);
			if(return_code != NOERROR)	return return_code;

			this->Le = tle;
			if(this->Le_rcv > tle)	{
				this->Le_rcv = tle;
			}
		}
		if(func_cb)	(*func_cb)(LOG_RESP, LOG_EVENT_TRANSMIT, this);
	}
	else	{
		if(func_cb)	(*func_cb)(LOG_CMD, LOG_EVENT_UNPROTECTED, this);
		
		DOList SMDO_list;
		const SMContextList* ctx = &(SM->SMCommandList);
		return_code = calContext(ctx, SMDO_list);
		if(return_code != NOERROR)	return return_code;
	
		BYTE *tbuffer = NULL;
		int tlen = SMDO_list.getConstructedLength();
		if(tlen > 0)	{
			if((tbuffer = (BYTE*) malloc(tlen)) == NULL)	return ERROR_DYNAMIC_MEMORY_ALLOCATION;
			SMDO_list.getConstructedValue(tbuffer);
		}
		int tCLA;
		SMContextList::const_iterator p;
		for(p = ctx->begin(); p != ctx->end(); p++)
			if((*p)->tag == TAG_SM_CHINCLUDE)	break;
		if(p == ctx->end())	tCLA = 0x08;
  		else	tCLA = 0x0C;
		
		int tINS = this->INS;
		int tP1 = this->P1;
		int tP2 = this->P2;
		for(p = ctx->begin(); p != ctx->end(); p++)
			if(((*p)->tag == TAG_SM_ENVELOPE) || ((*p)->tag == TAG_SM_ENVELOPE_AUTH))	break;
		if(p != ctx->end())	{
			tINS = INS_CMD_GET_ENVELOPE;
			tP1 = 0x00;
			tP2 = 0x00;
		}

		try	{
			APDU sm_apdu(tCLA, tINS, tP1, tP2, tlen, tbuffer, 65536, this->func_cb);

			return_code = sm_apdu.sendAPDU(reader);
			if(return_code != NOERROR)	return return_code;

			if(sm_apdu.getLe_rcv() > 0)	{
				return_code = calResponse(&(SM->SMResponseList), sm_apdu.getLe_rcv(), sm_apdu.getResponse());
				if(return_code != NOERROR)	return return_code;
			}
			if((this->SW1 == 0x00) && (this->SW2 == 0x00))	{
				this->SW1 = sm_apdu.getSW1();
				this->SW2 = sm_apdu.getSW2();
			}
		}
		catch(int exp)	{
			if(tbuffer != NULL)	free(tbuffer);
			return exp;
		}
		if(tbuffer != NULL)	free(tbuffer);

		if(func_cb)	(*func_cb)(LOG_RESP, LOG_EVENT_UNPROTECTED, this);
	}
	return NOERROR;
}

/** 
 * Function to set the CLA byte of the APDU.
 */
void APDU::setCLA(
	BYTE CLA	///< Class Byte which indicates the class of the command.
)	{
  this->CLA = CLA;
}

/**
 * Function to set the instruction byte of the APDU.
 */
void APDU::setINS(
	BYTE INS	///< Instruction Byte which indicates the command to process.
) 	{
  this->INS = INS;
}

/** 
 * Function to set the P1 byte of the APDU.
 */
void APDU::setP1(
	BYTE P1		///< Parameter Byte 1.
) 	{
  this->P1 = P1;
}

/** 
 * Function to set the P2 byte of the APDU. 
 */
void APDU::setP2(
	BYTE P2		///< Parameter Byte 2.
) 	{
  this->P2 = P2;
}

/**
 * Function to set the Le byte of the APDU.
 */
int APDU::setLe(
	int Le		///< Maximum expected length of response.
) 	{
	this->Le = (Le <= 0) ? 0 : Le;
	if(this->response != NULL)	{	
		free(this->response);
		this->response = NULL;
	}
	if((this->response = (BYTE*) realloc(this->response, this->Le+2)) == NULL)	{
		this->Le = 0;
		return ERROR_DYNAMIC_MEMORY_ALLOCATION;
	}
	return NOERROR;
}

/** 
 * Function to set the value of data buffer and Lc byte of the APDU.
 * \note Lc must contain the exact number of bytes in data.
 * \return This funtion returns following:
 *		- NOERROR
 *		- ERROR_DYNAMIC_MEMORY_ALLOCATION
 */
int APDU::setData(
    	int Lc,				///< Length of Lc_buffer i.e. length of the data field.
    	const BYTE *Lc_buffer		///< Command Data field.
)	{
	this->Lc = (Lc <= 0) ? 0 : Lc;
	if(this->data != NULL)	free(this->data);
	if(this->Lc > 0)	{
		this->data = (BYTE*) malloc(this->Lc);
		if(this->data == NULL)	{
			this->Lc = 0;
			return ERROR_DYNAMIC_MEMORY_ALLOCATION;
		}
		memcpy(this->data, Lc_buffer, this->Lc);
	}
	else this->data = NULL;
	return NOERROR;
}

/** 
 * Function to set the value of appropriate fields of APDU with corresponding arguments. It also initializes the Le_rcv with -1 and SW1 & SW2 to 0x00.
 * \return This funtion returns following:
 *		- NOERROR
 *		- ERROR_DYNAMIC_MEMORY_ALLOCATION
 */
int APDU::setAPDU(
	BYTE CLA,			///< Class Byte which indicates the class of the command.
    	BYTE INS,			///< Instruction Byte which indicates the command to process.
    	BYTE P1,			///< Parameter Byte 1.
    	BYTE P2,			///< Parameter Byte 2.
    	int Lc,				///< Length of Lc_buffer i.e. the Data field.
    	const BYTE *Lc_buffer,		///< Command Data field.
    	int Le,				///< Expected length of the Response - Zero(0) means no response is expected.
	func_callback func_cb		///< Call back function pointer for logging.
)	{
  	this->CLA = CLA;
  	this->INS = INS;
  	this->P1 = P1;
  	this->P2 = P2;
	this->func_cb = func_cb;
	this->Le_rcv = -1;
	this->SW1 = 0x00;
	this->SW2 = 0x00;

	int return_code = setData(Lc, Lc_buffer);
	if(return_code != NOERROR)	return return_code;

	return_code = setLe(Le);
	return return_code;
}

void APDU::setFunc(
	func_callback func_cb		///< Call back function pointer for logging.
)	{
	this->func_cb = func_cb;
}

/** 
 * Function to get the value of class byte of APDU. 
 * \return returns the value of CLA byte of the APDU object
 */
BYTE APDU::getCLA(void) const 
{
  return CLA;
}

/** 
 * Function to get the value of instruction byte of APDU. 
 * \return returns the value of INS byte of the APDU object
 */
BYTE APDU::getINS(void) const 
{
  return INS;
}

/** 
 * Function to get the value of first parameter byte of APDU. 
 * \return returns the value of P1 byte of the APDU object
 */
BYTE APDU::getP1(void) const 
{
  return P1;
}

/** 
 * Function to get the value of second parameter byte of APDU.
 * \return returns the value of P2 byte of the APDU object
 */
BYTE APDU::getP2(void) const 
{
  return P2;
}

/** 
 * Function to get the length of the data field of APDU.
 * \return returns the length of the data in  command APDU data(i.e. Lc of the APDU object)
 */
int APDU::getLc(void) const 
{
  return Lc;
}

/**
 * Function to get the data field of APDU.
 * \return returns a constant pointer to data field of command APDU(i.e. data of the APDU object)
 */
const BYTE* APDU::getData(void) const 
{
  return data;
}

/** 
 * Function to get the expected length of response APDU.
 * \return retuns the length of expected response(i.e. Le of the APDU object) 
 */
int APDU::getLe(void) const 
{
  return Le;
}

/** 
 * Function to get the value of first status byte of response APDU. 
 * \return returns the value of SW1. 
 */
BYTE APDU::getSW1(void) const 
{
  return SW1;
}

/** 
 * Function to get the value of second status byte of response APDU.
 * \return returns the value of SW2. 
 */
BYTE APDU::getSW2(void) const 
{
  return SW2;
}

/** 
 * Function to get the response field(Le buffer) after sending the APDU. 
 * \return returns a constant pointer to the response buffer. 
 */
const BYTE* APDU::getResponse(void) const 
{ 
  return response;
}

/** 
 * Function to get the value of SW1 and SW2 in the concatenated format.
 * \return In the returned value, first byte would be SW1 followed by the SW2 byte. 
 */ 
WORD APDU::getSW1SW2(void) const
{
  return (((WORD)SW1 << 8) | SW2);
}

/** 
 * Function to get the Length of the response field returned by the command execution.
 * \return returns the length of the received buffer(i.e. Le_rcv)
 */
int APDU::getLe_rcv(void) const   
{
  return Le_rcv;
}	

/**
 * Function to get the pointer to logging function.
 * \return returns a pointer to logging function.
 */
func_callback APDU::getFunc_cb(void) const	{
	return this->func_cb;
}
