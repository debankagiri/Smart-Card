#pragma once

#include "stdafx.h"
#include <list>

#define VALUECHUNK 16	// Value chunk to be used for memory allocation.

using namespace std;

class DO;
class DOList;

/**
 * \brief Class used for representing ISO-7816 Data Objects.
 *
 * This class introduces object oriented behaviour in Data Objects, which are the basic data units of smart card.
 * The format of DO is "Tag-Length-Value", in short TLV. Here value of the "Length" field is length of "Value" field.
 * 	- "Tag" can be of  one byte or two bytes.
 * 	- The value of "Length" field can be of either one byte or two bytes.
 * 	- "Length" must contain the exact number of bytes in "Value" field.
 */
class DO	{
protected:
	WORD tag;		///< One-byte or two-byte tag for the DO.
	WORD length;		///< Length of the DO. A number between 0 to 65535.
	BYTE *value;		///< Value field of the DO.        
public:
	DO(void);
	virtual ~DO(void);	
	DO(WORD tag_arg);
	DO(const BYTE tag_arg[], WORD length_arg, const BYTE *value_arg);
	DO(WORD tag_arg, WORD length_arg, const BYTE *value_arg);
	DO(WORD tag_arg, BYTE value_arg);
	DO(const DO &do_arg);
	DO(const BYTE *byte_stream);

	int setTag(const BYTE *tag_arg);
	void setTag(const WORD tag_arg);
	int setValue(WORD length_arg, const BYTE *value_arg);
	
	WORD getTag(void) const;
	WORD getLength() const;
	const BYTE* getValue(void) const;
	int getTotalBytes(BYTE *buffer) const;
	int getTotalLength(void) const;

	int appendConstructedValue(const DOList& collection);
	int appendValue(WORD length_arg, const BYTE *buffer);
	int appendDO(const DO& do_arg);
	int appendDO(WORD tag_arg, WORD length_arg, const BYTE *value_arg);
};

/**
 * \brief This class represents a list of Data Objects(DO).
 *
 * This is implemented through a Standard Template Library List class.
 *
 * \note The DOs added to the list will be deleted when the List is deleted. 
 */
class DOList : public list<DO>	{
	public:
  	int setList(int length, const BYTE* byte_stream);
	int getConstructedLength() const;
	int getConstructedValue(BYTE * buffer) const;
	int copyDOtoList(const DO& do_arg);
};
