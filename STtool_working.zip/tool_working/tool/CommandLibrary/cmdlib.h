// Include this header file to use the functionality of Command Library. 

/** 
 * \mainpage Command Library
 * This project involved developing a Standard C++ Library according to the SCOSTA specifications(SCOSTA, SCOSTA-CL & SCOSTA-PKI) for Smart Cards.
 *
 * Salient features of the Command Library:
 *	- It provides an abstract way of communicating with Smart Card OS. Various APDU classes are provided through which smart card commands can 
 *	  be easily executed. 
 *
 *	- It supports T0, T1 & T-CL communication protocols.
 *
 * 	- It provides support for Secure Messaging(SM). SMContext & SMContextEntry classes are provided through which 
 *    	  SM tags can be easily created and added in SM command/response tags list. It also provides functions for calculating SM APDUs and 
 *	  decoding SM responses. 
 *
 *	- It includes a robust cryptographic library(Crypto Library) which supports various Cryptographic algorithms(Triple DES, SHA-1 & RSA). 
 *	  The crypto library is provided as a runtime library, which is dynamically loaded corresponding to the cryptographic algorithm. 
 * 	  Generic functions CryptoFunc() & getOutLen() are provided, through which the crypto library can be easily accessed.
 *
 * \author Sudhanshu Shukla (sudhan@iitk.ac.in), Smart-ID Lab, IIT Kanpur
 */
#pragma once

#include "CommandAPDU.h"
#include "APDU.h"
#include "Reader.h"
#include "crypto.h"
#include "Error.h"
