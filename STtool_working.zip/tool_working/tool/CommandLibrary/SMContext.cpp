#include "SMContext.h"

/**
 * Constructor for SMContextEntry class. This constructor takes tagnumber, algorithm, SMtag sublist, data object as input and initializes the tag object.
 * 
 * It ensures the following:
 *	- SMContextEntry objects are only formed for possible SM tags.
 *	- Formed SMContextry objects have all the necessary data members.
 * 
 * \throw ERROR_SM_TAG_REQUIRES_ALGO_SPECS_AND_SMCONTEXT_SUBLIST	exception indicating that the SMContextEntry object corresponding to the SM tag being 
 *									created requires a cryptospec object and an SMContextList as sublist.
 *
 * 
 * \throw ERROR_SM_TAG_REQUIRES_SMCONTEXT_SUBLIST	exception indicating that the SMContextEntry object corresponding to the SM tag being created requires 
 *							an SMContextList as sublist.
 *
 * \throw ERROR_SM_TAG_REQUIRES_ALGO_SPECS		exception indicating that the SMContextEntry object corresponding to the SM tag being created requires 
 *							a cryptospec object.
 *
 * \throw ERROR_SM_TAG_REQUIRES_DATA_OBJECT		exception indicating that the SMContextEntry object corresponding to the SM tag being created requires 
 *							a data object.
 *
 * \throw ERROR_INVALID_SM_TAG				exception indicating that the SM tag provided is invalid(Not allowed).
 */
SMContextEntry::SMContextEntry(
	WORD tag,				///< tag number of the SM tag. This is a compulsary field and has to be provided when creating the tag object.
	cryptospec *algo,			///< algorithm associated with the tag. Default value is NULL.
	const SMContextList *contextList, 	///< SMtag sublist associated with the tag. Default value is NULL.
	const DO *generic_do			///< generic do object. A copy of the DO object is added.
)	{
  	this->tag = tag; 
  	this->algo = algo; 
  	this->contextList = contextList;
	this->generic_do = generic_do;

	switch(this->tag)	{
		case TAG_SM_DATA:
		case TAG_SM_DATA_AUTH:
		case TAG_SM_CH_AUTH:
		case TAG_SM_LE:
		case TAG_SM_LE_AUTH:
		case TAG_SM_CHINCLUDE:
		case TAG_SM_STATUS:
			break;
		case TAG_SM_CRYPTODO:	
		case TAG_SM_CRYPTODO_AUTH:
			if((this->algo == NULL) || (this->contextList == NULL))	throw ERROR_SM_TAG_REQUIRES_ALGO_SPECS_AND_SMCONTEXT_SUBLIST;
			break;
		case TAG_SM_PLAINDO:
		case TAG_SM_PLAINDO_AUTH:
			if(this->contextList == NULL)	throw ERROR_SM_TAG_REQUIRES_SMCONTEXT_SUBLIST;
			break;
		case TAG_SM_ENCDATA:
		case TAG_SM_ENCDATA_AUTH:
		case TAG_SM_ENVELOPE:
		case TAG_SM_ENVELOPE_AUTH:
		case TAG_SM_CC:
			if(this->algo == NULL)	throw ERROR_SM_TAG_REQUIRES_ALGO_SPECS;
			break;
		case TAG_SM_CCT:
		case TAG_SM_CCT_AUTH:
		case TAG_SM_CT:
		case TAG_SM_CT_AUTH:
		case TAG_SM_DO:
			if(this->generic_do == NULL)	throw ERROR_SM_TAG_REQUIRES_DATA_OBJECT;
			break;
		default	:	
			throw ERROR_INVALID_SM_TAG;
	}
}
