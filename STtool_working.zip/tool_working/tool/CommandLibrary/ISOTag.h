#pragma once

#define FCP_TAG				0x62
#define FCP_TAG_SET_FILE_SIZE		0x80
#define FCP_TAG_FDB			0x82
#define FCP_TAG_FILE_ID			0x83 
#define FCP_TAG_DF_NAME			0x84
#define FCP_TAG_SHORT_ID		0x88
#define FCP_TAG_LCSI			0x8A
#define FCP_TAG_COMPACT			0x8C
#define FCP_TAG_EXPANDED		0xAB
#define FCP_TAG_SE			0x7B
#define FCP_TAG_SE_FILE			0x8D

//File related commands in SCOSTA.
#define INS_CMD_CREATE_FILE		0xE0
#define INS_CMD_SELECT_FILE		0xA4
#define INS_CMD_READ_BIN		0xB0
#define INS_CMD_READ_RECORDS		0xB2
#define INS_CMD_WRITE_BIN		0xD0
#define INS_CMD_WRITE_RECORD		0xD2
#define INS_CMD_UPDATE_BIN		0xD6
#define INS_CMD_UPDATE_RECORD		0xDC
#define INS_CMD_APPEND_RECORD		0xE2
#define INS_CMD_ERASE_BIN		0x0E
#define INS_CMD_ACTIVATE_FILE		0x44
#define INS_CMD_DEACTIVATE_FILE		0x04
#define INS_CMD_DELETE_FILE		0xE4
#define INS_CMD_TERMINATE_DF		0xE6
#define INS_CMD_TERMINATE_EF		0xE8
#define INS_CMD_TERMINATE_CARD_USAGE 	0xFE

//Security related commands in SCOSTA.
#define INS_CMD_INTERNAL_AUTHENTICATE			0x88
#define INS_CMD_EXTERNAL_AUTHENTICATE			0x82
#define INS_CMD_MUTUAL_AUTHENTICATE			0x82
#define INS_CMD_GET_CHALLENGE				0x84
#define INS_CMD_VERIFY					0x20
#define INS_CMD_ENABLE_VERIFICATION_REQUIREMENT		0x28
#define INS_CMD_DISABLE_VERIFICATION_REQUIREMENT	0x26
#define INS_CMD_CHANGE_REFERENCE_DATA			0x24
#define INS_CMD_RESET_RETRY_COUNTER			0x2C
#define INS_CMD_MSE					0x22
#define INS_CMD_PSO					0x2A

//DO related Commands in SCOSTA
#define INS_CMD_GET_DATA		0xCA
#define INS_CMD_PUT_DATA		0xDA
#define INS_CMD_GET_RESPONSE		0xC0

// GET ENVELOPE
#define INS_CMD_GET_ENVELOPE  		0xC2

// Constants defined for LCSI
#define LCSI_CREATION 		0x01	///< For life cycle status as "creation state".
#define LCSI_INITIALISATION 	0X03	///< For life cycle status as "initialization state".
#define LCSI_ACTIVATED 		0X05	///< For life cycle status as "operational state-activated".
#define LCSI_DEACTIVATED 	0x04	///< For life cycle status as "operational state-deactivated".
#define LCSI_TERMINATION 	0x0c	///< For life cycle status as "termination state".

// Constants defined for MSE operations
#define SEC_SET		0x01	///< Constant defined for the SET i.e. setting or replacing one component of the current SE.
#define SEC_STORE	0xF2	///< Constant defined for the STORE i.e. saving the current SE under the SEID byte in P2.
#define SEC_RESTORE	0xF3	///< Constant defined for the RESTORE i.e. replacing the current SE by the SE stored in the card.
#define SEC_ERASE	0xF4	///< Constant defined for the ERASE i.e. erasing a SE stored in the card.


// Constants defined for Access Mode Byte.
#define AM_DELETE_SELF	0x40		///< AM byte for deleting file.
#define AM_TERMINATE	0x20		///< AM byte for terminating(EF or DF) or terminating card usage.
#define AM_ACTIVATE	0x10		///< AM byte for activating a file.
#define AM_DEACTIVATE	0x08		///< AM byte for deactivating a file.

// Constants for Access_Mode Byte Specific only to DFs.
#define AM_CREATE_DF	0x04		///< AM byte for creating DF.
#define AM_CREATE_EF	0x02		///< AM byte for creating EF.
#define AM_DELETE_CHILD 0x01		///< AM byte for deleting file(child).

// Constants for Access_Mode Byte Specific only to EFs.
#define AM_WRITE_APPEND 0x04		///< AM byte for writing binary or record or appending record. 
#define AM_UPDATE_ERASE 0x02		///< AM byte for updating or erasing binary or record.	
#define AM_READ_SEARCH	0x01		///< AM byte for reading or searching binary or record.

// Constants defined for Security Condition Byte.
#define SC_COMPACT_NEVER 0xFF		///< SC byte constant for "NEVER".  
#define SC_NO_CONDITION 0x00		///< SC byte constant for "NO CONDITION".  
#define SC_NO_REFERENCE 0x00		///< SC byte indicating no reference to Security Environment.	

#define SC_SE1			0x01	///< Security Environment number 1.
#define SC_SE2			0x02	///< Security Environment number 2.
#define SC_SE3			0x03	///< Security Environment number 3.
#define SC_SE4			0x04	///< Security Environment number 4.	
#define SC_SE5			0x05	///< Security Environment number 5.
#define SC_SE6			0x06	///< Security Environment number 6.
#define SC_SE7			0x07	///< Security Environment number 7.
#define SC_SE8			0x08	///< Security Environment number 8.
#define SC_SE9			0x09	///< Security Environment number 9.
#define SC_SE10			0x0A	///< Security Environment number 10.
#define SC_SE11			0x0B	///< Security Environment number 11.	
#define SC_SE12			0x0C	///< Security Environment number 12.
#define SC_SE13			0x0D	///< Security Environment number 13.
#define SC_SE14			0x0E	///< Security Environment number 14.

#define SC_ATLEAST_ONE	0x00		///< Constant representing applicability of at least one condition.
#define SC_ALL		0x80		///< Constant representing applicability of all conditions.
#define SC_SM		0x40		///< Constant representing applicability of Secure Messaging.
#define SC_EXT_AUTH	0x20		///< Constant representing allowance of External Authentication.
#define SC_USER_AUTH	0x10		///< Constant representing allowance of User authentication(e.g.password presentation).

