#pragma once

#include "stdafx.h"
#include "APDU.h"
#include "FCP.h"

/**
 * \ingroup apdu
 * \defgroup derived_apdu ISO Command APDUs
 * 
 */

/*@{*/
//Constants defined for SelectFile command
//Selection by File identifier
#define SEL_ANY				0x00	///< Constant defined for the selecting a MF or DF or EF by short-id.
#define SEL_CHILD_DF			0x01 	///< Constant defined for the selecting a DF by short-id.
#define SEL_CHILD_EF 			0x02 	///< Constant defined for the selecting a EF by short-id.
#define SEL_PARENTDF_OF_CURRENTDF	0x03 	///< Constant deined for selecting the parent DF of the current DF
//Selection by DF name.
#define SEL_DF_NAME 			0x04	///< Constant defined for the selection by DF name.
//Selection by Path
#define SEL_FROM_MF 			0x08	///< Constant defined for the selection by path relative to MF.
#define SEL_FROM_CURRENT_DF 		0x09	///< Constant defined for the selection by path relative to current DF.

//Constants defined for the fileOp command - P2 BYTE
//Constants for file occurences.
#define FILEOP_FIRST_OCC	0x00	///< Constants defined for first Occurence.
#define FILEOP_LAST_OCC		0x01	///< Constants defined for Last Occurence.
#define FILEOP_NEXT_OCC		0x02	///< Constants defined for Next Occurence.
#define FILEOP_PREVIOUS_OCC	0x03	///< Constants defined for Previous Occurence.

//Constants for file control information.
#define FILEOP_RET_FCI		0x00	///< Constants defined for returning FCI template after execution of the command.
#define FILEOP_RET_FCP 		0x04	///< Constants defined for returning FCP template after execution of the command.
#define FILEOP_RET_FMD 		0x08	///< Constants defined for returning FMD template after execution of the command.
#define FILEOP_NO_RESPONSE	0x0C	///< Constants defined for returning nothing after execution of the command.

//Constants for P2 field of Read command for record type.
//Record identifier in P1 
#define READ_FIRST		0x00	///< Constants defined for reading First Occurence.
#define READ_LAST		0x01	///< Constants defined for reading Last Occurence.
#define READ_NEXT		0x02	///< Constants defined for reading Next Occurence.
#define READ_PREVIOUS		0x03	///< Constants defined for reading Previous Occurence.
//Constants defined for reading record P1.
#define READ_RECORD_P1		0x04	///< Record number in P1
#define READ_ALL_P1_TO_LAST	0x05	///< Constants defined for reading all records from P1 upto the last.
#define READ_ALL_LAST_TO_P1	0x06	///< Constants defined for reading all records from last upto the P1.

//Constants for "constant" field of Write and Update command for record type EF.
//Record number set to 0x00
#define WR_UP_FIRST		0x00	///< Constants defined for writing first record.
#define WR_UP_LAST		0x01	///< Constants defined for writing Last record.
#define WR_UP_NEXT		0x02	///< Constants defined for writing Next record.
#define WR_UP_PREVIOUS		0x03	///< Constants defined for writing Previous record.
//Record number in P1(not equal to 0x00)
#define WR_UP_REC_NO_P1		0x04	///< Constants defined for writing record number P1.

// Constants defined for the Reference data.
#define SEC_GLOBAL	0x00	///< Constant defined for the Global reference data, passed in P2 byte of SECURITY OPERATIONS Command.
#define SEC_SPECIFIC	0x80	///< Constant defined for the Specific reference data, passed in P2 byte of SECURITY OPERATIONS Command.

// Security constants defined for the SET mode of MSE Command.
#define SEC_SM_COMMAND_FIELD	0x10	///< Constant defined for the Secure Messaging in command data field.
#define SEC_SM_RESPNXE_FIELD	0x20	///< Constant defined for the Secure Messaging in response data field.
#define SEC_COMPUTE_DECIPHER	0x40	///< Constant defined for the Computation, decipherment, internal authentication and key agreement. 
#define SEC_VERIFY_ENCIPHER	0x80	///< Constant defined for the Verification, encipherment, external authentication and key agreement. 

// Constants defined for tag types.
#define DO_TAG_DUMPING		0x01	///< Used for dumping a file or for card-originated byte strings.
#define DO_TAG_SIMPLE_TLV	0x02	///< Simple TLV tag (one Byte).
#define DO_TAG_BER_TLV_ONE	0x03	///< BER-TLV tag(one byte).
#define DO_TAG_BER_TLV_TWO	0x04	///< BER-TLV tag(two byte).


/**
 * \brief Class for creating APDU for Envelope command.
 *
 * For more information refer to ISO 7816-4 INS=C2
 */
class EnvelopeAPDU : public APDU	{
	public:
		EnvelopeAPDU(int Lc, const BYTE* data, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for Create File command.
 *
 * For more information refer to ISO 7816-4 INS=E0
 */
class CreateFileAPDU : public APDU	{
	public:
		CreateFileAPDU(const FCP *fcp, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for Terminate Card Usage command.
 *
 * For more information refer to ISO 7816-4 INS=FE
 */
class TerminateCardUsageAPDU : public APDU	{
	public:
		TerminateCardUsageAPDU(func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for Select File command.
 *
 * For more information refer to ISO 7816-4 INS=A4
 */
class SelectFileAPDU : public APDU	{
	public:
  		SelectFileAPDU(BYTE P1, BYTE P2, int Lc, const BYTE* data, int Le, func_callback func_cb = NULL);
  		SelectFileAPDU(BYTE P1, BYTE P2, WORD fileid, int Le, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for Delete File command.
 *
 * For more information refer to ISO 7816-4 INS=E4
 */
class DeleteFileAPDU : public APDU	{
	public:
  		DeleteFileAPDU(BYTE P1, BYTE P2, int Lc, const BYTE* data, int Le, func_callback func_cb = NULL);
  		DeleteFileAPDU(BYTE P1, BYTE P2, WORD fileid, int Le, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for Activate File command.
 *
 * For more information refer to ISO 7816-4 INS=44
 */
class ActivateFileAPDU : public APDU	{
	public:
  		ActivateFileAPDU(BYTE P1, BYTE P2, int Lc, const BYTE* data, int Le, func_callback func_cb = NULL);
  		ActivateFileAPDU(BYTE P1, BYTE P2, WORD fileid, int Le, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for DeActivate File command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='04'
 */
class DeActivateFileAPDU : public APDU	{
	public:
  		DeActivateFileAPDU(BYTE P1, BYTE P2, int Lc, const BYTE* data, int Le, func_callback func_cb = NULL);
  		DeActivateFileAPDU(BYTE P1, BYTE P2, WORD fileid, int Le, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for Terminate DF command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='E6'
 */
class TerminateDFAPDU : public APDU	{
	public:
  		TerminateDFAPDU(BYTE P1, BYTE P2, int Lc, const BYTE* data, int Le, func_callback func_cb = NULL);
  		TerminateDFAPDU(BYTE P1, BYTE P2, WORD fileid, int Le, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for Terminate EF command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='E8'
 */
class TerminateEFAPDU : public APDU	{
	public:
  		TerminateEFAPDU(BYTE P1, BYTE P2, int Lc, const BYTE* data, int Le, func_callback func_cb = NULL);
  		TerminateEFAPDU(BYTE P1, BYTE P2, WORD fileid, int Le, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for ReadBinary command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='B0'
 */
class ReadBinaryAPDU : public APDU	{
	public:
  		ReadBinaryAPDU(BYTE sfid, BYTE offset, int Le, func_callback func_cb = NULL);
		ReadBinaryAPDU(WORD offset, int Le, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for WriteBinary command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='D0'
 */
class WriteBinaryAPDU : public APDU	{
	public:
		WriteBinaryAPDU(BYTE sfid, BYTE offset, int Lc, const BYTE *data, func_callback func_cb = NULL);
		WriteBinaryAPDU(WORD offset, int Lc, const BYTE *data, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for UpdateBinary command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='D6'
 */
class UpdateBinaryAPDU : public APDU	{
	public:
		UpdateBinaryAPDU(BYTE sfid, BYTE offset, int Lc, const BYTE *data, func_callback func_cb = NULL);
		UpdateBinaryAPDU(WORD offset, int Lc, const BYTE *data, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for EraseBinary command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='0E'
 */
class EraseBinaryAPDU : public APDU	{
	public:
		EraseBinaryAPDU(BYTE sfid, BYTE offset, func_callback func_cb = NULL);
		EraseBinaryAPDU(BYTE sfid, BYTE offset, WORD endoffset, func_callback func_cb = NULL);
		EraseBinaryAPDU(WORD offset, WORD endoffset, func_callback func_cb = NULL);
		EraseBinaryAPDU(WORD offset, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for ReadRecord command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='B2'
 */
class ReadRecordAPDU : public APDU	{
 	public:
		ReadRecordAPDU(BYTE recordnum, BYTE sfid, BYTE constant, int Le, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for WriteRecord command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='D2'
 */
class WriteRecordAPDU : public APDU	{
	public:
		WriteRecordAPDU(BYTE recordnum, BYTE sfid, BYTE constant, int record_len, const BYTE *record_data, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for UpdateRecord command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='DC'
 */
class UpdateRecordAPDU : public APDU	{
	public:
		UpdateRecordAPDU(BYTE recordnum, BYTE sfid, BYTE constant, int update_len, const BYTE *update_data, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for AppendRecord command.
 *
 * For more information refer to ISO/IEC 7816-4, INS=E2'
 */
class AppendRecordAPDU : public APDU	{
	public:
		AppendRecordAPDU(BYTE sfid, int append_data_len, const BYTE *append_data, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for External Authentication command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='82'.
 */
class ExternalAuthenticationAPDU : public APDU	{
	public:
		ExternalAuthenticationAPDU(BYTE algo, BYTE REF, BYTE qualifier, int resp_to_chal_len, const BYTE *resp_to_chal, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for Internal Authentication command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='88'.
 */
class InternalAuthenticationAPDU : public APDU	{
	public:
		InternalAuthenticationAPDU(BYTE algo, BYTE REF, BYTE qualifier, int chal_len, const BYTE *chal, int resp_len, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for Mutual Authentication command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='82'.
 */
class MutualAuthenticationAPDU : public APDU	{
	public:
		MutualAuthenticationAPDU(BYTE algo, BYTE REF, BYTE qualifier, int auth_data_len, const BYTE *auth_data, int exp_len, func_callback func_cb = NULL);
		MutualAuthenticationAPDU(BYTE algo, BYTE REF, BYTE qualifier, int chal_len, const BYTE *chal, int resp_to_chal_len, const BYTE* resp_to_chal, 
			int exp_len, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for Get Challenege command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='84'
 */
class GetChallengeAPDU : public APDU	{
	public:
		GetChallengeAPDU(BYTE algo, int exp_len, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for Verify command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='20'
 */
class VerifyAPDU : public APDU	{
	public:
		VerifyAPDU(BYTE REF, BYTE qualifier, int data_len, const BYTE *data, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for Change Reference Data command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='24'
 */
class ChangeReferenceDataAPDU : public APDU	{
	public:
		ChangeReferenceDataAPDU(BYTE REF, BYTE qualifier, int newrefdata_len, const BYTE *newrefdata, 
			int verifydata_len, const BYTE* verifydata, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for Enable Verification command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='28'
 */
class EnableVerificationAPDU : public APDU	{
	public:
		EnableVerificationAPDU(BYTE REF, BYTE qualifier, int verification_data_len, const BYTE *verification_data, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for Disable Verification command.
 *
 * For more information refer to ISO/IEC 7816-4, INS='26'
 */
class DisableVerificationAPDU : public APDU	{
	public:
		DisableVerificationAPDU(BYTE REF, BYTE qualifier, int verification_data_len, const BYTE *verification_data, func_callback func_cb = NULL);
};
	
/**
 * \brief Class for creating APDU for Reset Retry Counter command.
 *
 *For more information refer to ISO/IEC 7816-4, INS='22'
 */
class ResetRetryCounterAPDU : public APDU	{
	public:
		ResetRetryCounterAPDU(BYTE REF, BYTE qualifier, BYTE resetting_code, int newrefdata_len, const BYTE *newrefdata, func_callback func_cb = NULL);
		ResetRetryCounterAPDU(BYTE REF, BYTE qualifier, int newrefdata_len, const BYTE *newrefdata, func_callback func_cb = NULL);
};
		
/**
 * \brief Class for creating APDU for Manage Security Environment command in SET mode.
 *
 * For more information refer to ISO/IEC 7816-4, INS='2C'
 */
class MSESetAPDU : public APDU	{
	public:
		MSESetAPDU(BYTE securityOp, BYTE crt, int Lc, const BYTE *data, func_callback func_cb = NULL);
		MSESetAPDU(BYTE securityOp, BYTE crt, const DOList& crdos, func_callback func_cb = NULL);
};
		
/**
 * \brief Class for creating APDU for Manage Security Environment command in STore mode.
 *
 * For more information refer to ISO/IEC 7816-4, INS='2C'
 */
class MSEStoreAPDU : public APDU	{
	public:
		MSEStoreAPDU(BYTE SEID, func_callback func_cb = NULL);
};
		
/**
 * \brief Class for creating APDU for Manage Security Environment command in RESTORE mode.
 *
 * For more information refer to ISO/IEC 7816-4, INS='2C'
 */
class MSERestoreAPDU : public APDU	{
	public:
		MSERestoreAPDU(BYTE SEID, func_callback func_cb = NULL);
};
		
/**
 * \brief Class for creating APDU for Manage Security Environment command in ERASE mode.
 *
 * For more information refer to ISO/IEC 7816-4, INS='2C'
 */
class MSEEraseAPDU : public APDU	{
	public:
		MSEEraseAPDU(BYTE SEID, func_callback func_cb = NULL);
};
		
/**
 * \brief Class for creating APDU for Perform Security Operation command for encryption.
 *
 * For more information refer to ISO/IEC 7816-4, INS='2A'
 */
class PSOEncryptAPDU : public APDU	{
	public:
		PSOEncryptAPDU(int plain_data_len, const BYTE *plain_data, BYTE p1, int exp_len, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for Perform Security Operation command for decryption.
 *
 * For more information refer to ISO/IEC 7816-4, INS='2A'
 */
class PSODecryptAPDU : public APDU	{
	public:
		PSODecryptAPDU(int end_data_len, const BYTE *enc_data, BYTE p2, int exp_len, func_callback func_cb = NULL);
};
		
/**
 * \brief Class for creating APDU for Perform Security Operation command for computing cryptographic checksum.
 *
 * For more information refer to ISO/IEC 7816-4, INS='2A'
 */
class PSOComputeCCAPDU : public APDU	{
	public:
		PSOComputeCCAPDU(int plain_data_len, const BYTE *plain_data, int exp_cc_len, func_callback func_cb = NULL);
};
		
/**
 * \brief Class for creating APDU for Perform Security Operation command for verifying cryptographic checksum.
 *
 * For more information refer to ISO/IEC 7816-4, INS='2A'
 */
class PSOVerifyCCAPDU : public APDU	{
	public:
		PSOVerifyCCAPDU(int plain_data_len, const BYTE *plain_data, int cc_data_len, const BYTE *cc_data, int exp_len, func_callback func_cb = NULL);
		PSOVerifyCCAPDU(int data_len, const BYTE *data, int exp_len, func_callback func_cb = NULL);
};
		
/**
 * \brief Class for creating APDU for Perform Security Operation command for computing digital signature.
 * 
 * For more information refer to ISO/IEC 7816-4, INS='2A'
 */
class PSOComputeDigSigAPDU : public APDU	{
	public:
		PSOComputeDigSigAPDU(int data_len, const BYTE *data, int exp_digsig_len, func_callback func_cb = NULL);
};
		
/**
 * \brief Class for creating APDU for Perform Security Operation command for verifying digital signatures.
 * 
 * For more information refer to ISO/IEC 7816-4, INS='2A'
 */
class PSOVerifyDigSigAPDU : public APDU	{
	public:
		PSOVerifyDigSigAPDU(int digsig_data_len, const BYTE *digsig_data, int exp_len, func_callback func_cb = NULL);
};
		
/**
 * \brief Class for creating APDU for Perform Security Operation command for verifying certificates.
 * 
 * For more information refer to ISO/IEC 7816-4, INS='2A'
 */
class PSOVerifyCertificateAPDU : public APDU	{
	public:
		PSOVerifyCertificateAPDU(int cert_data_len, const BYTE *cert_data, int exp_len, func_callback func_cb = NULL);
};
		
/**
 * \brief Class for creating APDU for Perform Security Operation command for hashing.
 *
 * For more information refer to ISO/IEC 7816-4, INS='2A'
 */
class PSOHashAPDU : public APDU	{
	public:
		PSOHashAPDU(int dataLen, const BYTE *data, int Le, func_callback func_cb = NULL);
};

/**
 * \brief Class for creating APDU for Get Data command.
 *
 * For more informationrefer to ISO/IEC 7816, INS='CA'.
 */
class GetDataAPDU : public APDU	{
	public:
		GetDataAPDU(BYTE tag_type, WORD tag, int Le, func_callback func_cb = NULL); 
};

/**
 * \brief Class for creating APDU for Put Data command.
 * 
 * For more informationrefer to ISO/IEC 7816, INS='DA'.
 */
class PutDataAPDU : public APDU	{
	public:
		PutDataAPDU(BYTE tag_type, WORD tag, BYTE Lc, BYTE *data, func_callback func_cb = NULL); 
};

/**
 * \brief Class for creating APDU for Get Response command. 
 *
 * For more informationrefer to ISO/IEC 7816, INS='C0'.
 */
class GetResponseAPDU : public APDU	{
	public:
		GetResponseAPDU(int Le, func_callback func_cb = NULL);
};

/*@}*/
