#pragma once

#include "stdafx.h"

/**
 * \brief Class representing compact access rules.
 *
 * In Compact format, an access rule consists of an access mode byte followed by one 
 * or more security condition bytes (actual number is the number of bits of Access mode 
 * byte set to one except 8th bit). Each bit of access mode byte is associated with a security condition byte. 
 * This class represents only one access rule. For multiple access rules multiple objects of 
 * this class must be created.
 */
class CompactAccessRule
{
	BYTE Access_Mode;	///< Access mode byte.
	BYTE SC_Bytes[7];	///< Array of Security condition bytes.
	int No_Conditions;	///< No of conditions (Number of bits set to 1 for access mode byte, except for the 8th bit).
	
public:
	CompactAccessRule(void);

	int setCompactAccessRule(BYTE AM_op, BYTE SC_Byte);

	int getTotalLength(void) const;
	int getTotalBytes(BYTE *buffer) const;
};
