#pragma once

#include "stdafx.h"
#include <list>

#ifdef WIN32
	#include <direct.h>
	#include <windows.h>
#else
	#include <sys/types.h>
	#include <dlfcn.h>
#endif

#ifdef WIN32 
	#define WINLIN GetProcAddress 
#else
	#define WINLIN dlsym
#endif
using namespace std;

/** \defgroup crypto Cryptographic Library */
/*@{*/

/** \defgroup crypto_usage Using Cryptographic Library */
/*@{*/
/** \name Macros defined for Cryptographic Operations*/
/*@{*/
#define ENCRYPT 	0	///< Operation code for Encryption.
#define DECRYPT 	1	///< Operation code for Decryption.
#define CC_COMPUTE 	2	///< Operation code for Crypto Checksum Computation.
#define CC_VERIFY  	3	///< Operation code for Crypto Checksum Verification.
#define HASH_COMPUTE  	4	///< Operation code for Hash Computation.
#define HASH_VERIFY   	5	///< Operation code for Hash Verification.
#define DSIG_COMPUTE  	6	///< Operation code for Digital Signature Computation.
#define DSIG_VERIFY   	7	///< Operation code for Digital Signature Verification.
/*@}*/

/**
 * \brief This class defines a data structure which is used by command library to represent a cryptographic algorithm specifications.
 * 
 *\note Some of the Crypto Algorithms modify the value of iv. Thus is should not be provided as a constant string other wise it would result in
 * a runtime error.
 */ 
class cryptospec	{
	public:
		char *algo;	///< Pointer to string name of the cryptographic library.
		BYTE *key;	///< Pointer to key to be used by the cryptographic library.
		int keylen;	///< Length of the key to be used by the cryptographic library.
		BYTE *iv;	///< Pointer to iv to be used by the cryptographic library.
		int ivlen;	///< Length of iv to be used by the cryptographic library.
		
		cryptospec(char *algo, BYTE *key, int keylen, BYTE *iv, int ivlen);
};

/**
 * \name Functions for using Crypto Library
 */
/*@{*/
int getBlockSize(const char *algo, const BYTE *key, int keylen, BYTE *iv, int ivlen);
int getBlockSize(cryptospec &spec);

int getOutLen(int op, const BYTE *in, int inlen, const char *algo, const BYTE *key, int keylen, BYTE *iv, int ivlen);
int getOutLen(int op, const BYTE *in, int inlen, cryptospec &spec);

int CryptoFunc(int op, const BYTE *in, int inlen, BYTE *out, int outlen, const char *algo, const BYTE *key, int keylen, BYTE *iv, int ivlen);
int CryptoFunc(int op, const BYTE *in, int inlen, BYTE *out, int outlen, cryptospec &spec);
/*@}*/
/*@}*/

/** \defgroup crypto_internal Crypto Libraries Management */
/*@{*/

/** \name Function types defined for Cryptographic Operations */
/*@{*/
typedef int (*encrypt_Func) (const BYTE *in, int inlen, BYTE *out, int outlen, const BYTE *key, int keylen, BYTE *iv, int ivlen);	///< Function type defined for encrypt operation.
typedef int (*getEncryptLen_Func) (const BYTE *in, int inlen, const BYTE *key, int keylen, BYTE *iv, int ivlen);	///< Function type defined for getEncryptLen operation.

typedef int (*decrypt_Func) (const BYTE *in, int inlen, BYTE *out, int outlen, const BYTE *key, int keylen, BYTE *iv, int ivlen);	///< Function type defined for decrypt operation.
typedef int (*getDecryptLen_Func) (const BYTE *in, int inlen, const BYTE *key, int keylen, BYTE *iv, int ivlen);	///< Function type defined for getDecryptLen operation.

typedef int (*cc_compute_Func) (const BYTE *in, int inlen, BYTE *out, int outlen, const BYTE *key, int keylen, BYTE *iv, int ivlen);	///< Function type defined for cc_compute operation.
typedef int (*getCCLen_Func) (const BYTE *in, int inlen, const BYTE *key, int keylen, BYTE *iv, int ivlen);	///< Function type defined for getCCLen operation.
typedef int (*cc_verify_Func) (const BYTE *in, int inlen, BYTE *out, int outlen, const BYTE *Key, int keylen, BYTE *iv, int ivlen);	///< Function type defined for cc_verify operation.

typedef int (*hash_compute_Func) (const BYTE *in, int inlen, BYTE *out, int outlen, const BYTE *key, int keylen, BYTE *iv, int ivlen);	///< Function type defined for hash_compute operation.
typedef int (*getHashLen_Func) (const BYTE *in, int inlen, const BYTE *key, int keylen, BYTE *iv, int ivlen);	///< Function type defined for getHashLen operation.
typedef int (*hash_verify_Func) (const BYTE *in, int inlen, BYTE *out, int outlen, const BYTE *key, int keylen, BYTE *iv, int ivlen);	///< Function type defined for hash_verify operation.

typedef int (*dsig_compute_Func) (const BYTE *in, int inlen, BYTE *out, int outlen, const BYTE *key, int keylen, BYTE *iv, int ivlen);	///< Function type defined for dsig_compute operation.
typedef int (*getDsigLen_Func) (const BYTE *in, int inlen, const BYTE *key, int keylen, BYTE *iv, int ivlen);	///< Function type defined for getDsigLen operation.
typedef int (*dsig_verify_Func) (const BYTE *in, int inlen, BYTE *out, int outlen, const BYTE *Key, int keylen, BYTE *iv, int ivlen);	///< Function type defined for dsig_verify operation.
typedef int (*getBlockSize_Func) (const BYTE *key, int keylen, BYTE *iv, int ivlen);	///< Function type defined for getBlkSize operation.
/*@}*/

/**
 * \brief This class defines the basic data structure used in Command Library for managing libraries for various cryptographic algorithms.
 * 
 * It stores pointers to function for various operations provided by the cryptographic library.
 */
class Algoentry	{
	char* algo_name;			///< Library name
#ifdef WIN32
	HINSTANCE lib_handle;			///< Handle to loaded lib
#else
	void *lib_handle;			///< Handle to loaded lib
#endif
	getBlockSize_Func getBlkSize;		///< Pointer to getBlkSize function.
	encrypt_Func encrypt;			///< Pointer to encrypt function.
	getEncryptLen_Func getEncryptLen;	///< Pointer to getEncryptLen function.
	
	decrypt_Func decrypt;			///< Pointer to decrypt function.
	getDecryptLen_Func getDecryptLen;	///< Pointer to getDecryptLen function.
	
	cc_compute_Func cc_compute;		///< Pointer to cc_compute function. 
	cc_verify_Func cc_verify;		///< Pointer to cc_verify function.
	getCCLen_Func getCCLen;			///< Pointer to getCCLen function.
		
	hash_compute_Func hash_compute;		///< Pointer to hash_compute function.
	hash_verify_Func hash_verify;		///< Pointer to hash_verify function.
	getHashLen_Func getHashLen;		///< Pointer to getHashLen function.
		
	dsig_compute_Func dsig_compute;		///< Pointer to dsig_compute function.
	getDsigLen_Func getDsigLen;		///< Pointer to getDsigLen fucntion.
	dsig_verify_Func dsig_verify;		///< Pointer to dsig_verify function.
	
	void init();

	public:
	
	Algoentry(const char* algo_name);
	~Algoentry();
	bool isAlgorithm(const char* algo_name);
	int perform_crypto_op(int op, const BYTE *in, int inlen, BYTE *out, int outlen, const BYTE *key, int keylen, BYTE *iv, int ivlen);
	int get_crypto_op_outlen(int op, const BYTE *in, int inlen, const BYTE *key, int keylen, BYTE *iv, int ivlen);
	int get_crypto_blocksize(const BYTE *key, int keylen, BYTE *iv, int ivlen);
};

/**
 * \brief This defines a list for maintaing Algoentry objects for the cryptographic libraries that are used.
 *
 * It provides functions for getting a pointer to the Algoentry object of the desired cryptographic library.
 */
class AlgoentryList	{
	list<Algoentry*> algolist;	///< list to store the Algoentry object pointers

	public:
	~AlgoentryList();
	int getAlgoentry(const char* algo, Algoentry** algoentry);
};
/*@}*/
/*@}*/
