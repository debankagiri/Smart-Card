#include "CommandAPDU.h"

/**
 * Creates an apdu for the envelope command. Envelope command transmits[part of] either a command APDU that 
 * could not be transmitted by the available transmission protocol.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
EnvelopeAPDU::EnvelopeAPDU(
	int  Lc,			///< Length of the command data field or Zero if no data is present.
	const BYTE* data,		///< Pointer to the data field which contains file-id or path or DF name or is NULL.
	func_callback func_cb		///< pointer to call back function for logging the apdu.
)	{
	int return_code = this->setAPDU(0, INS_CMD_GET_ENVELOPE, 0, 0, Lc, data, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the create file command(used for creating DF & EF).
 * FCP class object is taken as an argument, which contains all the information about the file to be created.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
CreateFileAPDU::CreateFileAPDU(
	const FCP *fcp,			///< FCP class object, containg all the information about the file to be created.
	func_callback func_cb		///< pointer to call back function for logging the apdu.
)	{
	BYTE *buffer = NULL;
	int l = fcp->getFCPLength();
	if((buffer = (BYTE*) malloc(l)) == NULL)
		throw ERROR_DYNAMIC_MEMORY_ALLOCATION;
	fcp->getTotalBytes(buffer);
	int return_code = this->setAPDU(0, INS_CMD_CREATE_FILE, 0, 0, l, buffer, 0, func_cb);
	if(return_code != NOERROR)	{
		free(buffer);
		throw return_code;
	}
	free(buffer);
}

/**
 * Creates an apdu for the terminate card usage command.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
TerminateCardUsageAPDU::TerminateCardUsageAPDU(
	func_callback func_cb	///< pointer to call back function for logging the apdu.
)	{
	int return_code = this->setAPDU(0, INS_CMD_TERMINATE_CARD_USAGE, 0, 0, 0, NULL, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Select file.
 *
 * - Constants defined for P1-BYTE
 *	- SEL_ANY
 *	- SEL_CHILD_DF
 *	- SEL_CHILD_EF
 *	- SEL_PARENTDF_OF_CURRENTDF
 *	- SEL_DF_NAME
 *	- SEL_FROM_MF
 *	- SEL_FROM_CURRENT_DF
 *
 * - Constants defined for P2-BYTE
 *	- FILEOP_FIRST_OCC
 *	- FILEOP_LAST_OCC
 *	- FILEOP_NEXT_OCC
 *	- FILEOP_PREVIOUS_OCC
 *	- FILEOP_RET_FCI
 *	- FILEOP_RET_FCP
 *	- FILEOP_RET_FMD
 *	- FILEOP_NO_RESPONSE
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
SelectFileAPDU::SelectFileAPDU(
	BYTE P1,		///< It signifies the way to select the file. Argument would be one of the constants defined for the 'P1-BYTE'.
	BYTE P2,		///< Argument must be given by OR-ing the different constants defined for 'P2-BYTE'.
	int  Lc,		///< Length of the command data field or Zero if no data is present.
	const BYTE* data,	///< Pointer to the data field which contains file-id or path or DF name or is NULL.
	int Le,			///< Maximum length of data expected in response or Zero(0) for no response.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
	int return_code = this->setAPDU(0, INS_CMD_SELECT_FILE, P1, P2, Lc, data, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Select file.
 *
 * - Constants defined for P1-BYTE
 *	- SEL_ANY
 *	- SEL_CHILD_DF
 *	- SEL_CHILD_EF
 *	- SEL_PARENTDF_OF_CURRENTDF
 *	- SEL_DF_NAME
 *	- SEL_FROM_MF
 *	- SEL_FROM_CURRENT_DF
 *
 * - Constants defined for P2-BYTE
 *	- FILEOP_FIRST_OCC
 *	- FILEOP_LAST_OCC
 *	- FILEOP_NEXT_OCC
 *	- FILEOP_PREVIOUS_OCC
 *	- FILEOP_RET_FCI
 *	- FILEOP_RET_FCP
 *	- FILEOP_RET_FMD
 *	- FILEOP_NO_RESPONSE
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
SelectFileAPDU::SelectFileAPDU(
	BYTE P1,		///< P1 BYTE. It signifies the way to select the file. Argument would be one of the constants defined for P1-BYTE.
	BYTE P2,		///< P2 BYTE. Argument must be given by OR-ing the different constants defined for P2-BYTE.
	WORD fileid,		///< File-id of the file on which command has to be executed.
	int Le,			///< Maximum length of data expected in response or Zero(0) for no response.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
  	BYTE value[2];
  	value[0] = (BYTE)(fileid >> 8);
  	value[1] = (BYTE)(fileid & 0xFF);
  	int return_code = this->setAPDU(0, INS_CMD_SELECT_FILE, P1, P2, 2, value, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Delete file.
 *
 * - Constants defined for P1-BYTE
 *	- SEL_ANY
 *	- SEL_CHILD_DF
 *	- SEL_CHILD_EF
 *	- SEL_PARENTDF_OF_CURRENTDF
 *	- SEL_DF_NAME
 *	- SEL_FROM_MF
 *	- SEL_FROM_CURRENT_DF
 *
 * - Constants defined for P2-BYTE
 *	- FILEOP_FIRST_OCC
 *	- FILEOP_LAST_OCC
 *	- FILEOP_NEXT_OCC
 *	- FILEOP_PREVIOUS_OCC
 *	- FILEOP_RET_FCI
 *	- FILEOP_RET_FCP
 *	- FILEOP_RET_FMD
 *	- FILEOP_NO_RESPONSE
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
DeleteFileAPDU::DeleteFileAPDU(
	BYTE P1,		///< It signifies the way to select the file. Argument would be one of the constants defined for the 'P1-BYTE'.
	BYTE P2,		///< Argument must be given by OR-ing the different constants defined for 'P2-BYTE'.
	int  Lc,		///< Length of the command data field or Zero if no data is present.
	const BYTE* data,	///< Pointer to the data field which contains file-id or path or DF name or is NULL.
	int Le,			///< Maximum length of data expected in response or Zero(0) for no response.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
	int return_code = this->setAPDU(0, INS_CMD_DELETE_FILE, P1, P2, Lc, data, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Delete file.
 *
 * - Constants defined for P1-BYTE
 *	- SEL_ANY
 *	- SEL_CHILD_DF
 *	- SEL_CHILD_EF
 *	- SEL_PARENTDF_OF_CURRENTDF
 *	- SEL_DF_NAME
 *	- SEL_FROM_MF
 *	- SEL_FROM_CURRENT_DF
 *
 * - Constants defined for P2-BYTE
 *	- FILEOP_FIRST_OCC
 *	- FILEOP_LAST_OCC
 *	- FILEOP_NEXT_OCC
 *	- FILEOP_PREVIOUS_OCC
 *	- FILEOP_RET_FCI
 *	- FILEOP_RET_FCP
 *	- FILEOP_RET_FMD
 *	- FILEOP_NO_RESPONSE
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
DeleteFileAPDU::DeleteFileAPDU(
	BYTE P1,		///< P1 BYTE. It signifies the way to select the file. Argument would be one of the constants defined for P1-BYTE.
	BYTE P2,		///< P2 BYTE. Argument must be given by OR-ing the different constants defined for P2-BYTE.
	WORD fileid,		///< File-id of the file on which command has to be executed.
	int Le,			///< Maximum length of data expected in response or Zero(0) for no response.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
  	BYTE value[2];
  	value[0] = (BYTE)(fileid >> 8);
  	value[1] = (BYTE)(fileid & 0xFF);
  	int return_code = this->setAPDU(0, INS_CMD_DELETE_FILE, P1, P2, 2, value, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Activate file command.
 *
 * - Constants defined for P1-BYTE
 *	- SEL_ANY
 *	- SEL_CHILD_DF
 *	- SEL_CHILD_EF
 *	- SEL_PARENTDF_OF_CURRENTDF
 *	- SEL_DF_NAME
 *	- SEL_FROM_MF
 *	- SEL_FROM_CURRENT_DF
 *
 * - Constants defined for P2-BYTE
 *	- FILEOP_FIRST_OCC
 *	- FILEOP_LAST_OCC
 *	- FILEOP_NEXT_OCC
 *	- FILEOP_PREVIOUS_OCC
 *	- FILEOP_RET_FCI
 *	- FILEOP_RET_FCP
 *	- FILEOP_RET_FMD
 *	- FILEOP_NO_RESPONSE
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
ActivateFileAPDU::ActivateFileAPDU(
	BYTE P1,		///< It signifies the way to select the file. Argument would be one of the constants defined for the 'P1-BYTE'.
	BYTE P2,		///< Argument must be given by OR-ing the different constants defined for 'P2-BYTE'.
	int  Lc,		///< Length of the command data field or Zero if no data is present.
	const BYTE* data,	///< Pointer to the data field which contains file-id or path or DF name or is NULL.
	int Le,			///< Maximum length of data expected in response or Zero(0) for no response.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
	int return_code = this->setAPDU(0, INS_CMD_ACTIVATE_FILE, P1, P2, Lc, data, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Activate file command.
 *
 * - Constants defined for P1-BYTE
 *	- SEL_ANY
 *	- SEL_CHILD_DF
 *	- SEL_CHILD_EF
 *	- SEL_PARENTDF_OF_CURRENTDF
 *	- SEL_DF_NAME
 *	- SEL_FROM_MF
 *	- SEL_FROM_CURRENT_DF
 *
 * - Constants defined for P2-BYTE
 *	- FILEOP_FIRST_OCC
 *	- FILEOP_LAST_OCC
 *	- FILEOP_NEXT_OCC
 *	- FILEOP_PREVIOUS_OCC
 *	- FILEOP_RET_FCI
 *	- FILEOP_RET_FCP
 *	- FILEOP_RET_FMD
 *	- FILEOP_NO_RESPONSE
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
ActivateFileAPDU::ActivateFileAPDU(
	BYTE P1,		///< P1 BYTE. It signifies the way to select the file. Argument would be one of the constants defined for P1-BYTE.
	BYTE P2,		///< P2 BYTE. Argument must be given by OR-ing the different constants defined for P2-BYTE.
	WORD fileid,		///< File-id of the file on which command has to be executed.
	int Le,			///< Maximum length of data expected in response or Zero(0) for no response.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
  	BYTE value[2];
  	value[0] = (BYTE)(fileid >> 8);
  	value[1] = (BYTE)(fileid & 0xFF);
  	int return_code = this->setAPDU(0, INS_CMD_ACTIVATE_FILE, P1, P2, 2, value, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the DeActivate file command.
 *
 * - Constants defined for P1-BYTE
 *	- SEL_ANY
 *	- SEL_CHILD_DF
 *	- SEL_CHILD_EF
 *	- SEL_PARENTDF_OF_CURRENTDF
 *	- SEL_DF_NAME
 *	- SEL_FROM_MF
 *	- SEL_FROM_CURRENT_DF
 *
 * - Constants defined for P2-BYTE
 *	- FILEOP_FIRST_OCC
 *	- FILEOP_LAST_OCC
 *	- FILEOP_NEXT_OCC
 *	- FILEOP_PREVIOUS_OCC
 *	- FILEOP_RET_FCI
 *	- FILEOP_RET_FCP
 *	- FILEOP_RET_FMD
 *	- FILEOP_NO_RESPONSE
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
DeActivateFileAPDU::DeActivateFileAPDU(
	BYTE P1,		///< It signifies the way to select the file. Argument would be one of the constants defined for the 'P1-BYTE'.
	BYTE P2,		///< Argument must be given by OR-ing the different constants defined for 'P2-BYTE'.
	int  Lc,		///< Length of the command data field or Zero if no data is present.
	const BYTE* data,	///< Pointer to the data field which contains file-id or path or DF name or is NULL.
	int Le,			///< Maximum length of data expected in response or Zero(0) for no response.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
	int return_code = this->setAPDU(0, INS_CMD_DEACTIVATE_FILE, P1, P2, Lc, data, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the DeActivate file command.
 *
 * - Constants defined for P1-BYTE
 *	- SEL_ANY
 *	- SEL_CHILD_DF
 *	- SEL_CHILD_EF
 *	- SEL_PARENTDF_OF_CURRENTDF
 *	- SEL_DF_NAME
 *	- SEL_FROM_MF
 *	- SEL_FROM_CURRENT_DF
 *
 * - Constants defined for P2-BYTE
 *	- FILEOP_FIRST_OCC
 *	- FILEOP_LAST_OCC
 *	- FILEOP_NEXT_OCC
 *	- FILEOP_PREVIOUS_OCC
 *	- FILEOP_RET_FCI
 *	- FILEOP_RET_FCP
 *	- FILEOP_RET_FMD
 *	- FILEOP_NO_RESPONSE
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
DeActivateFileAPDU::DeActivateFileAPDU(
	BYTE P1,		///< P1 BYTE. It signifies the way to select the file. Argument would be one of the constants defined for P1-BYTE.
	BYTE P2,		///< P2 BYTE. Argument must be given by OR-ing the different constants defined for P2-BYTE.
	WORD fileid,		///< File-id of the file on which command has to be executed.
	int Le,			///< Maximum length of data expected in response or Zero(0) for no response.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
  	BYTE value[2];
  	value[0] = (BYTE)(fileid >> 8);
  	value[1] = (BYTE)(fileid & 0xFF);
  	int return_code = this->setAPDU(0, INS_CMD_DEACTIVATE_FILE, P1, P2, 2, value, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Terminate DF command.
 *
 * - Constants defined for P1-BYTE
 *	- SEL_ANY
 *	- SEL_CHILD_DF
 *	- SEL_CHILD_EF
 *	- SEL_PARENTDF_OF_CURRENTDF
 *	- SEL_DF_NAME
 *	- SEL_FROM_MF
 *	- SEL_FROM_CURRENT_DF
 *
 * - Constants defined for P2-BYTE
 *	- FILEOP_FIRST_OCC
 *	- FILEOP_LAST_OCC
 *	- FILEOP_NEXT_OCC
 *	- FILEOP_PREVIOUS_OCC
 *	- FILEOP_RET_FCI
 *	- FILEOP_RET_FCP
 *	- FILEOP_RET_FMD
 *	- FILEOP_NO_RESPONSE
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
TerminateDFAPDU::TerminateDFAPDU(
	BYTE P1,		///< It signifies the way to select the file. Argument would be one of the constants defined for the 'P1-BYTE'.
	BYTE P2,		///< Argument must be given by OR-ing the different constants defined for 'P2-BYTE'.
	int  Lc,		///< Length of the command data field or Zero if no data is present.
	const BYTE* data,	///< Pointer to the data field which contains file-id or path or DF name or is NULL.
	int Le,			///< Maximum length of data expected in response or Zero(0) for no response.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
	int return_code = this->setAPDU(0, INS_CMD_TERMINATE_DF, P1, P2, Lc, data, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Terminate DF command.
 *
 * - Constants defined for P1-BYTE
 *	- SEL_ANY
 *	- SEL_CHILD_DF
 *	- SEL_CHILD_EF
 *	- SEL_PARENTDF_OF_CURRENTDF
 *	- SEL_DF_NAME
 *	- SEL_FROM_MF
 *	- SEL_FROM_CURRENT_DF
 *
 * - Constants defined for P2-BYTE
 *	- FILEOP_FIRST_OCC
 *	- FILEOP_LAST_OCC
 *	- FILEOP_NEXT_OCC
 *	- FILEOP_PREVIOUS_OCC
 *	- FILEOP_RET_FCI
 *	- FILEOP_RET_FCP
 *	- FILEOP_RET_FMD
 *	- FILEOP_NO_RESPONSE
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
TerminateDFAPDU::TerminateDFAPDU(
	BYTE P1,		///< P1 BYTE. It signifies the way to select the file. Argument would be one of the constants defined for P1-BYTE.
	BYTE P2,		///< P2 BYTE. Argument must be given by OR-ing the different constants defined for P2-BYTE.
	WORD fileid,		///< File-id of the file on which command has to be executed.
	int Le,			///< Maximum length of data expected in response or Zero(0) for no response.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
  	BYTE value[2];
  	value[0] = (BYTE)(fileid >> 8);
  	value[1] = (BYTE)(fileid & 0xFF);
  	int return_code = this->setAPDU(0, INS_CMD_TERMINATE_DF, P1, P2, 2, value, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Terminate EF command.
 *
 * - Constants defined for P1-BYTE
 *	- SEL_ANY
 *	- SEL_CHILD_DF
 *	- SEL_CHILD_EF
 *	- SEL_PARENTDF_OF_CURRENTDF
 *	- SEL_DF_NAME
 *	- SEL_FROM_MF
 *	- SEL_FROM_CURRENT_DF
 *
 * - Constants defined for P2-BYTE
 *	- FILEOP_FIRST_OCC
 *	- FILEOP_LAST_OCC
 *	- FILEOP_NEXT_OCC
 *	- FILEOP_PREVIOUS_OCC
 *	- FILEOP_RET_FCI
 *	- FILEOP_RET_FCP
 *	- FILEOP_RET_FMD
 *	- FILEOP_NO_RESPONSE
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
TerminateEFAPDU::TerminateEFAPDU(
	BYTE P1,		///< It signifies the way to select the file. Argument would be one of the constants defined for the 'P1-BYTE'.
	BYTE P2,		///< Argument must be given by OR-ing the different constants defined for 'P2-BYTE'.
	int  Lc,		///< Length of the command data field or Zero if no data is present.
	const BYTE* data,	///< Pointer to the data field which contains file-id or path or DF name or is NULL.
	int Le,			///< Maximum length of data expected in response or Zero(0) for no response.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
	int return_code = this->setAPDU(0, INS_CMD_TERMINATE_EF, P1, P2, Lc, data, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Terminate EF command.
 *
 * - Constants defined for P1-BYTE
 *	- SEL_ANY
 *	- SEL_CHILD_DF
 *	- SEL_CHILD_EF
 *	- SEL_PARENTDF_OF_CURRENTDF
 *	- SEL_DF_NAME
 *	- SEL_FROM_MF
 *	- SEL_FROM_CURRENT_DF
 *
 * - Constants defined for P2-BYTE
 *	- FILEOP_FIRST_OCC
 *	- FILEOP_LAST_OCC
 *	- FILEOP_NEXT_OCC
 *	- FILEOP_PREVIOUS_OCC
 *	- FILEOP_RET_FCI
 *	- FILEOP_RET_FCP
 *	- FILEOP_RET_FMD
 *	- FILEOP_NO_RESPONSE
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
TerminateEFAPDU::TerminateEFAPDU(
	BYTE P1,		///< P1 BYTE. It signifies the way to select the file. Argument would be one of the constants defined for P1-BYTE.
	BYTE P2,		///< P2 BYTE. Argument must be given by OR-ing the different constants defined for P2-BYTE.
	WORD fileid,		///< File-id of the file on which command has to be executed.
	int Le,			///< Maximum length of data expected in response or Zero(0) for no response.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
  	BYTE value[2];
  	value[0] = (BYTE)(fileid >> 8);
  	value[1] = (BYTE)(fileid & 0xFF);
  	int return_code = this->setAPDU(0, INS_CMD_TERMINATE_EF, P1, P2, 2, value, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the read binary command which reads the binaries with given 
 * short file id "sfid" from the given offset (value between 0 to 255).
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
ReadBinaryAPDU::ReadBinaryAPDU(
    	BYTE sfid,		///< Short EF identifier(bits 5 to 1).
    	BYTE offset,		///< An offset from 0 to 255.
    	int Le,			///< Number of bytes to be read or Zero(0) to read till the end of file.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
    	int return_code = this->setAPDU(0, INS_CMD_READ_BIN, 0x80|sfid, offset, 0, NULL, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the read binary command which reads the binaries from
 * the current file from the given offset (value between 0 to 32767).
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
ReadBinaryAPDU::ReadBinaryAPDU(
    	WORD offset,			///< An offset from 0 to 32767.
    	int Le,				///< Number of bytes to be read or Zero(0) to read till the end of file.
	func_callback func_cb		///< pointer to call back function for logging the apdu
)	{
      	int return_code = this->setAPDU(0, INS_CMD_READ_BIN, offset >> 8, offset & 0x00FF, 0, NULL, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;

}

/**
 * Creates an apdu for the Write Binary command.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */

WriteBinaryAPDU::WriteBinaryAPDU(
    	BYTE sfid,		///< Short EF identifier(bits 5 to 1).
    	BYTE offset,		///< An offset from 0 to 255.
    	int Lc,			///< Length of the command data field or Zero if data field is absent.
    	const BYTE *data,	///< Appropriate data or NULL.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
    	int return_code = this->setAPDU(0, INS_CMD_WRITE_BIN, 0x80|sfid, offset, Lc, data, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Write Binary command.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
WriteBinaryAPDU::WriteBinaryAPDU(
    	WORD offset,		///< An offset from 0 to 32767.
    	int Lc,			///< Length of the command data field or Zero if the data field is absent.
    	const BYTE *data,	///< Appropriate data or NULL.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
	int return_code = this->setAPDU(0, INS_CMD_WRITE_BIN, (0x7F&(offset >> 8)), (offset & 0x00FF), Lc, data, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Update Binary command.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
UpdateBinaryAPDU::UpdateBinaryAPDU(
    	BYTE sfid,		///< Short EF identifier(bits 5 to 1).
    	BYTE offset,		///< An offset from 0 to 255.
    	int Lc,			///< Length of the command data field or Zero if data field is absent.
    	const BYTE *data,	///< Appropriate data or NULL.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
    	int return_code = this->setAPDU(0, INS_CMD_UPDATE_BIN, 0x80|sfid, offset, Lc, data, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Update Binary command.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
UpdateBinaryAPDU::UpdateBinaryAPDU(
    	WORD offset,		///< An offset from 0 to 32767.
    	int Lc,			///< Length of the command data field or Zero if the data field is absent.
    	const BYTE *data,	///< Appropriate data or NULL.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
	int return_code = this->setAPDU(0, INS_CMD_UPDATE_BIN, (0x7F&(offset >> 8)), (offset & 0x00FF), Lc, data, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Erase Binary command.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
EraseBinaryAPDU::EraseBinaryAPDU(
    	BYTE sfid,		///< Short EF identifier(bits 5 to 1).
    	BYTE offset,		///< An offset from 0 to 255.
    	WORD endoffset,		///< An offset from 0 to 32767.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
	BYTE data[2];
	data[0] = (BYTE)(0x0F & (endoffset>>8));
	data[1] = (BYTE)(endoffset & 0x0F);

    	int return_code = this->setAPDU(0, INS_CMD_ERASE_BIN, 0x80|sfid, offset, 2, data, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Erase Binary command.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
EraseBinaryAPDU::EraseBinaryAPDU(
    	BYTE sfid,		///< Short EF identifier(bits 5 to 1).
    	BYTE offset,		///< An offset from 0 to 255.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
    	int return_code = this->setAPDU(0, INS_CMD_ERASE_BIN, 0x80|sfid, offset, 0, NULL, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Erase Binary command.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
EraseBinaryAPDU::EraseBinaryAPDU(
    	WORD offset,		///< An offset from 0 to 32767.
    	WORD endoffset,		///< An offset from 0 to 32767.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
	BYTE data[2];
	data[0] = (BYTE)(0x0F & (endoffset>>8));
	data[1] = (BYTE)(endoffset & 0x0F);

	int return_code = this->setAPDU(0, INS_CMD_ERASE_BIN, (0x7F&(offset >> 8)), (offset & 0x00FF), 2, data, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Erase Binary command.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
EraseBinaryAPDU::EraseBinaryAPDU(
    	WORD offset,		///< An offset from 0 to 32767.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
	int return_code = this->setAPDU(0, INS_CMD_ERASE_BIN, (0x7F&(offset >> 8)), (offset & 0x00FF), 0, NULL, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Constructor for ReadRecordAPDU class. Creates an apdu for the read recordcommand.
 *
 * - Conditions defined for 
 *	- Record identifier in P1
 *		- READ_FIRST
 *		- READ_LAST
 *		- READ_NEXT
 *		- READ_PREVIOUS
 *	- Record number in P1
 *		- READ_RECORD_P1
 *		- READ_ALL_P1_TO_LAST
 *		- READ_ALL_LAST_TO_P1
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
ReadRecordAPDU::ReadRecordAPDU(
    	BYTE recordnum,		///< Record number (Set '0x00' for current record) or record identifier from '01' to 'FE'.
    	BYTE sfid, 		///< Short file id of the EF (Set '0x00' for current EF).
    	BYTE constant,		///< One of the different 'Read condition constants'.
    	int Le,			///< Number of bytes to be read or Zero(0) to read the complete record.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
	int return_code = this->setAPDU(0, INS_CMD_READ_RECORDS, recordnum, (BYTE)(((sfid << 3) & 0xF8) | (( 0x07 & constant))), 0, NULL, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Write Record ISO command.
 *
 * - Different condition constants defined constant BYTE:
 *	- If Record Number set to '00'
 *		- WR_UP_FIRST
 *		- WR_UP_LAST
 *		- WR_UP_NEXT
 *		- WR_UP_PREVIOUS
 *	- If Record number is not equal to '00'(i.e. between 1 and 254)
 *		- WR_UP_REC_NO_P1
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
WriteRecordAPDU::WriteRecordAPDU(
    	BYTE recordnum,			///< Record number(value between 1 to 254) or '0x00' for current record.
    	BYTE sfid, 			///< Short file id of the EF or '0x00' for current EF.
    	BYTE constant,			///< One of the diffierent condition constants defined for constant BYTE.
    	int record_len,			///< Length of the record to be written.
    	const BYTE *record_data,	///< Buffer containing the record to be written.
	func_callback func_cb		///< pointer to call back function for logging the apdu.
)	{
    	int return_code = this->setAPDU(0, INS_CMD_WRITE_RECORD, recordnum, (BYTE)(((sfid << 3) & 0xF8) | ((0x07 & constant))), record_len, record_data, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Update Record ISO command.
 *
 * - Different condition constants defined constant BYTE:
 *	- If Record Number set to '00'
 *		- WR_UP_FIRST
 *		- WR_UP_LAST
 *		- WR_UP_NEXT
 *		- WR_UP_PREVIOUS
 *	- If Record number is not equal to '00'(i.e. between 1 and 254)
 *		- WR_UP_REC_NO_P1
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
UpdateRecordAPDU::UpdateRecordAPDU(
    	BYTE recordnum,			///< Record number(value between 1 to 254) or '0x00' for current record.
    	BYTE sfid, 			///< Short file id of the EF or '0x00' for current EF.
    	BYTE constant,			///< One of the diffierent condition constants defined for constant BYTE.
    	int update_len,			///< Length of the update data.
    	const BYTE *update_data,	///< Buffer containing the update data.
	func_callback func_cb		///< pointer to call back function for logging the apdu.
)	{
    	int return_code = this->setAPDU(0, INS_CMD_UPDATE_RECORD, recordnum, (BYTE)(((sfid << 3) & 0xF8) | ((0x07 & constant))), update_len, update_data, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Append Record ISO command.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
AppendRecordAPDU::AppendRecordAPDU(
    	BYTE sfid, 			///< Short file id of the EF or '0x00' for current EF.
    	int append_data_len,		///< Length of the record to be appended.
    	const BYTE *append_data,	///< buffer containing the record to be appended.
	func_callback func_cb		///< pointer to call back function for logging the apdu
)	{
    	int return_code = this->setAPDU(0, INS_CMD_APPEND_RECORD, 0x00, (BYTE)((sfid << 3) & 0xF8), append_data_len, append_data, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the External Authentication ISO command.
 *
 * Constants defined for the Reference data.
 *	- SEC_GLOBAL
 *	- SEC_SPECIFIC
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
ExternalAuthenticationAPDU::ExternalAuthenticationAPDU(
    	BYTE algo,			///< Cryptographic or Biometric Algorithm to be used.
    	BYTE REF,			///< Reference specifier, argument would be one of the constants defined for the Reference data.
    	BYTE qualifier,			///< Number of refernce data or number of the secret. 
    	int resp_to_chal_len,		///< Length of response to the challenge issued by card.
    	const BYTE *resp_to_chal,	///< Response to the challenge issued by card.
	func_callback func_cb		///< pointer to call back function for logging the apdu
)	{
  	int return_code = this->setAPDU(0, INS_CMD_EXTERNAL_AUTHENTICATE, algo, (REF + (0x1F&qualifier)), resp_to_chal_len, resp_to_chal, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Internal Authentication ISO command.
 *
 * Constants defined for the Reference data.
 *	- SEC_GLOBAL
 *	- SEC_SPECIFIC
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
InternalAuthenticationAPDU::InternalAuthenticationAPDU(
    	BYTE algo,		///< Cryptographic or Biometric Algorithm to be used.
    	BYTE REF,		///< Reference specifier, argument would be one of the constants defined for the Reference data.
    	BYTE qualifier,		///< Number of refernce data or number of the secret. 
    	int chal_len,		///< Length of the challenge to card.
    	const BYTE *chal,	///< Challenege to card.
    	int resp_len,		///< Maximum length of the expected response to challenge.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
  	int return_code = this->setAPDU(0, INS_CMD_INTERNAL_AUTHENTICATE, algo, (REF + (0x1F&qualifier)), chal_len, chal, resp_len, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Mutual Authentication ISO command.
 *
 * Constants defined for the Reference data.
 *	- SEC_GLOBAL
 *	- SEC_SPECIFIC
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
MutualAuthenticationAPDU::MutualAuthenticationAPDU(
    	BYTE algo,		///< Cryptographic or Biometric Algorithm to be used.
    	BYTE REF,		///< Reference specifier, argument would be one of the constants defined for the Reference data.
    	BYTE qualifier,		///< Number of refernce data or number of the secret. 
    	int auth_data_len,	///< Length of the authentication data.
    	const BYTE *auth_data,	///< Authentication data.
    	int exp_len,		///< Maximum length of the response to this command.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
  	int return_code = this->setAPDU(0, INS_CMD_MUTUAL_AUTHENTICATE, algo, (REF + (0x1F&qualifier)), auth_data_len, auth_data, exp_len, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Mutual Authentication command.
 *
 * Mutual authentication command's data consists of a challenge(chal) to authenticate card and a response to the challenge(resp_to_chal) issued by the card. 
 * \note The authentication data for mutual authentication apdu created by this constructor consists of concatenation of resp_to_chal and chal(in the stated order).
 *
 * Constants defined for the Reference data.
 *	- SEC_GLOBAL
 *	- SEC_SPECIFIC
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
MutualAuthenticationAPDU::MutualAuthenticationAPDU(
    	BYTE algo,			///< Cryptographic or Biometric Algorithm to be used.
    	BYTE REF,			///< Reference specifier, argument would be one of the constants defined for the Reference data.
    	BYTE qualifier,			///< Number of refernce data or number of the secret. 
    	int chal_len,			///< Length of the challenge provided by the application.
    	const BYTE *chal,		///< Challenege provided by application.
    	int resp_to_chal_len,		///< Length of the response to the challenge provided by card.
    	const BYTE *resp_to_chal,	///< Response to challenege provided by card.
    	int exp_len,			///< Maximum length of the response to this command.
	func_callback func_cb		///< pointer to call back function for logging the apdu.
)	{
	BYTE * tdata = (BYTE*) malloc(sizeof(BYTE*) * (chal_len + resp_to_chal_len));
	if(tdata == NULL)	throw ERROR_DYNAMIC_MEMORY_ALLOCATION;
	memcpy(tdata, resp_to_chal, resp_to_chal_len);
	memcpy(tdata+resp_to_chal_len, chal, chal_len);

  	int return_code = this->setAPDU(0, INS_CMD_MUTUAL_AUTHENTICATE, algo, (REF + (0x1F&qualifier)), chal_len+resp_to_chal_len, tdata, exp_len, func_cb);
	if(return_code != NOERROR)	{
		free(tdata);
		throw return_code;
	}
	free(tdata);
}

/**
 * Creates an apdu for Get Challenge ISO command.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
GetChallengeAPDU::GetChallengeAPDU(
    	BYTE algo,		///< Cryptographic or Biometric Algorithm to be used.
    	int exp_len,		///< Maximum length of expected challenge.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
  	int return_code = this->setAPDU(0, INS_CMD_GET_CHALLENGE, algo, 0, 0, NULL, exp_len, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for Verify ISO command.
 * The command initiates the comparison in the card of stored reference data with verification data sent from the interface device.
 *
 * Constants defined for the Reference data.
 *	- SEC_GLOBAL
 *	- SEC_SPECIFIC
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
VerifyAPDU::VerifyAPDU(
    	BYTE REF,		///< Reference specifier, argument would be one of the constants defined for the Reference data.
    	BYTE qualifier,		///< Number of the reference data or number of the secret. 
    	int data_len,		///< Length of verification data or Zero(0) for no verification data.
    	const BYTE *data,	///< Verification data or NULL for no verification data.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
  	int return_code = this->setAPDU(0, INS_CMD_VERIFY, 0x00, (REF + qualifier), data_len, data, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for Change Reference Data ISO command.
 *
 * Constants defined for the Reference data.
 *	- SEC_GLOBAL
 *	- SEC_SPECIFIC
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
ChangeReferenceDataAPDU::ChangeReferenceDataAPDU(
    	BYTE REF,		///< Reference specifier, argument would be one of the constants defined for the Reference data.
    	BYTE qualifier,			///< Number of refernce data or number of the secret. 
    	int newrefdata_len,		///< Length of the New Reference data.
    	const BYTE *newrefdata,  	///< New Reference data.
    	int verifydata_len,		///< Length of the Verification data.
    	const BYTE *verifydata,   	///< Verification data or NULL if no verifydata present.
	func_callback func_cb		///< pointer to call back function for logging the apdu
)	{
	if((verifydata == NULL) || (verifydata_len <= 0))	{
		// only new reference data present.
  		int return_code = this->setAPDU(0, INS_CMD_CHANGE_REFERENCE_DATA, 0x01, (REF + qualifier), newrefdata_len, newrefdata, 0, func_cb);
		if(return_code != NOERROR)	throw return_code;
	}
	else	{
		BYTE *tdata = (BYTE*) malloc(sizeof(BYTE) * (newrefdata_len + verifydata_len));
		if(tdata == NULL)	throw ERROR_DYNAMIC_MEMORY_ALLOCATION;
		memcpy(tdata, verifydata, verifydata_len);
		memcpy(tdata+verifydata_len, newrefdata, newrefdata_len);

		int return_code = this->setAPDU(0, INS_CMD_CHANGE_REFERENCE_DATA, 0x00, (REF + qualifier), newrefdata_len+ verifydata_len, tdata, 0, func_cb);
		if(return_code != NOERROR)	{
			free(tdata);
			throw return_code;
		}
		free(tdata);
	}
}

/**
 * Creates an apdu for Enable Verification Requirement ISO command.
 *
 * Constants defined for the Reference data.
 *	- SEC_GLOBAL
 *	- SEC_SPECIFIC
 *
 * \note If verification data is supplied then P1 is set to 0x00 else if no verification data is supplied then P1 is set to 0x01.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
EnableVerificationAPDU::EnableVerificationAPDU(
    	BYTE REF,				///< Reference specifier, argument would be one of the constants defined for the Reference data.
    	BYTE qualifier, 			///< Number of refernce data or number of the secret.
    	int verification_data_len,		///< Length of the Verification Data or Zero(0) if no verification data.
    	const BYTE *verification_data,		///< Verification Data(P1 set to 0x00) or NULL(P1 set to 0x01).
	func_callback func_cb			///< pointer to call back function for logging the apdu.
)	{
	int return_code = NOERROR;
	if((verification_data_len == 0) || (verification_data == NULL))
		return_code = this->setAPDU(0, INS_CMD_ENABLE_VERIFICATION_REQUIREMENT, 0x01, (REF + qualifier), 0, NULL, 0, func_cb);
	else
		return_code = this->setAPDU(0, INS_CMD_ENABLE_VERIFICATION_REQUIREMENT, 0x00, (REF + qualifier), verification_data_len, verification_data, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for the Disable Verification Requirement ISO command.
 *
 * Constants defined for the Reference data.
 *	- SEC_GLOBAL
 *	- SEC_SPECIFIC
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
DisableVerificationAPDU::DisableVerificationAPDU(
    	BYTE REF,				///< Reference specifier, argument would be one of the constants defined for the Reference data.
    	BYTE qualifier, 			///< Number of refernce data or number of the secret.
    	int verification_data_len,		///< Length of the Verification Data or Zero(0) if no verification data.
    	const BYTE *verification_data,		///< Verification Data(P1 set to 0x00) or NULL(P1 set to 0x01).
	func_callback func_cb			///< pointer to call back function for logging the apdu.
)	{
	int return_code = NOERROR;
	if((verification_data_len == 0) || (verification_data == NULL))
		return_code = this->setAPDU(0, INS_CMD_DISABLE_VERIFICATION_REQUIREMENT, 0x01, (REF + qualifier), 0, NULL, 0, func_cb);
	else
		return_code = this->setAPDU(0, INS_CMD_DISABLE_VERIFICATION_REQUIREMENT, 0x00, (REF + qualifier), verification_data_len, verification_data, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}
	
/**
 * Creates an apdu for the Reset Retry Counter ISO command.
 *
 * Constants defined for the Reference data.
 *	- SEC_GLOBAL
 *	- SEC_SPECIFIC
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
ResetRetryCounterAPDU::ResetRetryCounterAPDU(
    	BYTE REF,			///< Reference specifier, argument would be one of the constants defined for the Reference data.
    	BYTE qualifier, 		///< Number of refernce data or number of the secret.
	BYTE resetting_code,		///< Resetting code.
    	int newrefdata_len,		///< Length of the New Reference data.
    	const BYTE *newrefdata,  	///< New Reference data or NULL is no New Reference data.
	func_callback func_cb		///< pointer to call back function for logging the apdu
)	{
	BYTE *tdata = NULL;
	int tdata_len;
	BYTE tP1;

	if((newrefdata_len <= 0) || (newrefdata == NULL))	{
		// only resetting code is present p1 = 0x01.
		tP1 = 0x01;
		tdata = (BYTE*)malloc(sizeof(BYTE));
		if(tdata == NULL)	throw ERROR_DYNAMIC_MEMORY_ALLOCATION;
		tdata[0] = resetting_code;
		tdata_len = 1;
	}
	else	{
		// both resetting code & new reference data are present p1 = 0x00.
		tP1 = 0x00;
		tdata = (BYTE*)malloc(sizeof(BYTE) * (1 + newrefdata_len));
		if(tdata == NULL)	throw ERROR_DYNAMIC_MEMORY_ALLOCATION;
		tdata[0] = resetting_code;
		memcpy(tdata+1, newrefdata, newrefdata_len);
		tdata_len = 1 + newrefdata_len;
	}
 	int return_code = this->setAPDU(0, INS_CMD_RESET_RETRY_COUNTER, tP1, (REF + qualifier), tdata_len, tdata, 0, func_cb);
	if(return_code != NOERROR)	{
		free(tdata);
		throw ERROR_DYNAMIC_MEMORY_ALLOCATION;
	}
	free(tdata);
}

/**
 * Creates an apdu for the Reset Retry Counter ISO command.
 *
 * Constants defined for the Reference data.
 *	- SEC_GLOBAL
 *	- SEC_SPECIFIC
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
ResetRetryCounterAPDU::ResetRetryCounterAPDU(
    	BYTE REF,			///< Reference specifier, argument would be one of the constants defined for the Reference data.
    	BYTE qualifier, 		///< Number of refernce data or number of the secret.
    	int newrefdata_len,		///< Length of the New Reference data.
    	const BYTE *newrefdata,  	///< New Reference data or NULL is no New Reference data.
	func_callback func_cb		///< pointer to call back function for logging the apdu
)	{
	BYTE *tdata = NULL;
	int tdata_len;
	BYTE tP1;

	if((newrefdata_len <= 0) || (newrefdata == NULL))	{
		// neither resetting code nor new reference data present p1 = 0x03.
		tP1 = 0x03;
		tdata_len = 0;
	}
	else	{
		// only new reference data present p1 = 0x02.
		tP1 = 0x02;
		tdata = (BYTE*)newrefdata;
		tdata_len = newrefdata_len;
	}
 	int return_code = this->setAPDU(0, INS_CMD_RESET_RETRY_COUNTER, tP1, (REF + qualifier), tdata_len, tdata, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Creates an apdu for Manage Security Environment ISO command in SET mode.
 * Used for setting or replacing a component of the current SE.
 *
 * - Security constants defined for SET mode of MSE Command
 *	- SEC_SM_COMMAND_FIELD
 *	- SEC_SM_RESPNXE_FIELD
 *	- SEC_COMPUTE_DECIPHER
 *	- SEC_VERIFY_ENCIPHER
 *
 * - Constants defined for the CRT
 *	- CRT_AT
 *	- CRT_KAT
 *	- CRT_HT
 *	- CRT_CCT
 *	- CRT_DST
 *	- CRT_CT
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
MSESetAPDU::MSESetAPDU(
    	BYTE securityOp,	///< Security Operations, argument will be in the format of OR-ing of various security constants defined for SET mode of MSE Command. 
    	BYTE crt,		///< Tag of the CRT present in the data field. Argument must be given in the format of OR-ing of different constants defined for the CRT.
    	int Lc,			///< Length of the command data field or Zero.
    	const BYTE *data,   	///< Concatenation of CRDO.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
  	int return_code = this->setAPDU(0, INS_CMD_MSE, (securityOp + SEC_SET), crt, Lc, data, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Constructor for MSESet class. Creates an apdu for manage security environment command in SET mode.
 * Used for setting or replacing a component of the current SE.
 *
 * - Security constants defined for SET mode of MSE Command
 *	- SEC_SM_COMMAND_FIELD
 *	- SEC_SM_RESPNXE_FIELD
 *	- SEC_COMPUTE_DECIPHER
 *	- SEC_VERIFY_ENCIPHER
 *
 * - Constants defined for the CRT
 *	- CRT_AT
 *	- CRT_KAT
 *	- CRT_HT
 *	- CRT_CCT
 *	- CRT_DST
 *	- CRT_CT
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
MSESetAPDU::MSESetAPDU(
    	BYTE securityOp,	///< Security Operations, argument will be in the format of OR-ing of various security constants defined for SET mode of MSE Command.
    	BYTE crt,		///< Tag of the CRT present in the data field ,Argument must be given in the format of OR-ing of different constants defined for the CRT.
    	const DOList& crdos, 	///< List of CRDOs to be passed as the data.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
	BYTE *tbuffer = NULL;
	int tbuffer_len = 0;

	tbuffer_len = crdos.getConstructedLength();
	if((tbuffer = (BYTE*) malloc(tbuffer_len)) == NULL)
		throw ERROR_DYNAMIC_MEMORY_ALLOCATION;

  	int return_code = this->setAPDU(0, INS_CMD_MSE, (securityOp  + SEC_SET), crt, tbuffer_len, tbuffer, 0, func_cb);
	free(tbuffer);
	if(return_code != NOERROR)	throw return_code;
}
		
/**
 * Constructor for MSEStore class. Creates an apdu for manage security environment command in STORE mode.
 * Used for saving the current SE under the SEID byte.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
MSEStoreAPDU::MSEStoreAPDU(
    	BYTE SEID,		///< Security Environment number.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
  	int return_code = this->setAPDU(0, INS_CMD_MSE, SEC_STORE, SEID, 0, NULL, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}
		
/**
 * Constructor for MSERestore class. Creates an apdu for manage security environment command in RESTORE mode.
 * Used for replacing the current SE by the SE stored in the card.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
MSERestoreAPDU::MSERestoreAPDU(
    	BYTE SEID,		///< Security Environment number.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
  	int return_code = this->setAPDU(0, INS_CMD_MSE, SEC_RESTORE, SEID, 0, NULL, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}
		
/**
 * Constructor for MSEErase class. Creates an apdu for manage security environment command in ERASE mode.
 * Used for erasing a SE stored in the card.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
MSEEraseAPDU::MSEEraseAPDU(
    	BYTE SEID,		///< Security Environment number.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
  	int return_code = this->setAPDU(0, INS_CMD_MSE, SEC_ERASE, SEID, 0, NULL, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}
		
/**
 * Constructor for PSOEncrypt class. Creates an apdu for the PERFORM SECURITY OPERATION(Encipher) command.
 * Used for Encrypting the data given in the "data" field.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
PSOEncryptAPDU::PSOEncryptAPDU(
	int plain_data_len,		///< Length of the Plain Data to be encrypted
	const BYTE *plain_data,		///< Plain Data to be encrypted
	BYTE p1,			///< Encryption tag
	int exp_len,			///< Expected length of the response.
	func_callback func_cb		///< pointer to call back function for logging the apdu
)	{
	int return_code = this->setAPDU(0, INS_CMD_PSO, p1, 0x80, plain_data_len, plain_data, exp_len, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Constructor for PSODecrypt class. Creates an apdu for the PERFORM SECURITY OPERATION(Decipher) command.
 * Used for Decrypting the data given in the "data" field.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
PSODecryptAPDU::PSODecryptAPDU(
    	int enc_data_len,		///< Length of Encrypted Data that has to be decrypted.
    	const BYTE *enc_data,		///< Encrypted Data that has to be decrypted.
    	BYTE p2,			///< Decryption tag.
	int exp_len,			///< Expected length of the response.
	func_callback func_cb		///< pointer to call back function for logging the apdu
)	{
  	int return_code = this->setAPDU(0, INS_CMD_PSO, 0x80, p2, enc_data_len, enc_data, exp_len, func_cb);
	if(return_code != NOERROR)	throw return_code;
}		
		
/**
 * Constructor for PSOComputeCC class. Creates an apdu for the PERFORM SECURITY OPERATION(Compute Cryptographic Checksum) command.
 * Used for Computing Cryptographic Checksum of the plain text data provided in the "data" field.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
PSOComputeCCAPDU::PSOComputeCCAPDU(
    	int plain_data_len,		///< Length of the Plain Data.
    	const BYTE *plain_data,		///< Buffer containing Plain Data for which the cryptographic checksum shall be computed.
    	int exp_cc_len,			///< Expected length of Crytographic checksum.
	func_callback func_cb		///< pointer to call back function for logging the apdu
)	{
  	int return_code = this->setAPDU(0, INS_CMD_PSO, 0x8E, 0x80, plain_data_len, plain_data, exp_cc_len, func_cb);
	if(return_code != NOERROR)	throw return_code;
}
		
/**
 * Constructor for PSOVerifyCC class. Creates an apdu for the PERFORM SECURITY OPERATION(Compute Cryptographic Checksum) command.
 * Used for Verifying Cryptographic Checksum given in the "cc" field with the one calculated from the 
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
PSOVerifyCCAPDU::PSOVerifyCCAPDU(
    	int plain_data_len,		///< Length of the plain text data.
    	const BYTE *plain_data,		///< Plain text data whose Crytographic checksum is generated (basically value field of DO with tag '80')
    	int cc_data_len,		///< Length of the Crytographic checksum.
    	const BYTE *cc_data,		///< Crytographic checksum to be verified (basically value field of DO with tag '8E')
	int exp_len,			///< Expected length of the response.
	func_callback func_cb		///< pointer to call back function for logging the apdu
)	{
	DOList cc_dolist;
	cc_dolist.push_back(DO(0x80, plain_data_len, plain_data));
	cc_dolist.push_back(DO(0x8E, cc_data_len, cc_data));
	int tbuffer_len = cc_dolist.getConstructedLength();
	BYTE *tbuffer = NULL;
	if((tbuffer = (BYTE*) malloc(tbuffer_len)) == NULL)
		throw ERROR_DYNAMIC_MEMORY_ALLOCATION;
	cc_dolist.getConstructedValue(tbuffer);
  	int return_code = this->setAPDU(0, INS_CMD_PSO, 0x00, 0xA2, tbuffer_len, tbuffer, exp_len, func_cb);
	free(tbuffer);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Constructor for PSOVerifyCC class. Creates an apdu for the PERFORM SECURITY OPERATION(Verify Cryptographic Checksum) command.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
PSOVerifyCCAPDU::PSOVerifyCCAPDU(
    	int data_len,		///< Length of the plain text data.
    	const BYTE *data,	///< Data containing both the tags '80' & '8E'. 
	int exp_len,			///< Expected length of the response.
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
	int return_code = this->setAPDU(0, INS_CMD_PSO, 0x00, 0xA2, data_len, data, exp_len, func_cb);
	if(return_code != NOERROR)	throw return_code;
}
		
/**
 * Constructor for PSOComputeDigSig class. Creates an apdu for the PERFORM SECURITY OPERATION(Compute Digital Signature) command.
 * Used for calculating the digital signature
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
PSOComputeDigSigAPDU::PSOComputeDigSigAPDU(
    	int data_len,		///< Length of the data to be signed or integrated in Digital Signatue.
    	const BYTE *data,	///< Data to be signed or integrated in Digital Signature.
	int exp_digsig_len,	///< Expected length of the Digital Signature.
	func_callback func_cb	///< pointer to call back function for logging the apdu.
)	{
  	int return_code = this->setAPDU(0, INS_CMD_PSO, 0x9E, 0x9A, data_len, data, exp_digsig_len, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Constructor for PSOVerifyDigSig class. Creates an apdu for the PERFORM SECURITY OPERATION(Verify Digital Signature) command.
 * Used for verifying the digital signature
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
PSOVerifyDigSigAPDU::PSOVerifyDigSigAPDU(
    	int digsig_data_len,		///< Length of the Digital Singature to be verified.
    	const BYTE *digsig_data,	///< Digital Signature to be verified.
	int exp_len,			///< Expected length of the response.
	func_callback func_cb		///< pointer to call back function for logging the apdu.
)	{
  	int return_code = this->setAPDU(0, INS_CMD_PSO, 0x00, 0xA8, digsig_data_len, digsig_data, exp_len, func_cb);
	if(return_code != NOERROR)	throw return_code;
}
		
/**
 * Constructor for PSOVerifyDigSig class. Creates an apdu for the PERFORM SECURITY OPERATION(Verify Digital Signature) command.
 * Used for verifying the digital signature
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
PSOVerifyCertificateAPDU::PSOVerifyCertificateAPDU(
    	int cert_data_len,		///< Length of the BER encoded certificate to be verified.
    	const BYTE *cert_data,		///< BER encoded certificate to be verified.
	int exp_len,			///< Expected length of the response.
	func_callback func_cb		///< pointer to call back function for logging the apdu
)	{
  	int return_code = this->setAPDU(0, INS_CMD_PSO, 0x00, 0xBE, cert_data_len, cert_data, exp_len, func_cb);
	if(return_code != NOERROR)	throw return_code;
}
		
/**
 * Constructor for PSOHash class. Creates an apdu for the PERFORM SECURITY OPERATION(Hashing) command.
 * Used for calculating the hash of the data given in the "data" field.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
PSOHashAPDU::PSOHashAPDU(
	int dataLen,		///< Length of the data whose hasing is to be done.
	const BYTE *data,	///< Data to hashed.
	int Le,			///< Maximum length of Hashed data expected in response. 
	func_callback func_cb	///< pointer to call back function for logging the apdu
)	{
  	int return_code = this->setAPDU(0, INS_CMD_PSO, 0x90, 0x80, dataLen, data, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Contructor for the GetData class.
 * It constructs an apdu of the Get Data command to retrieve contents of an EF supporting DOs.
 *
 * - Constants defined for Tag type.
 *	- DO_TAG_DUMPING
 *	- DO_TAG_SIMPLE_TLV
 *	- DO_TAG_BER_TLV_ONE
 *	- DO_TAG_BER_TLV_TWO
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
GetDataAPDU::GetDataAPDU(
    	BYTE tag_type,		///< Type of the tag. Argument would be one of the constants defined for tag types.
    	WORD tag,		///< Tag of the DO according to the tag type whose value has to be retreived 
				///< (eg. if tag_type is 'DO_TAG_SIMPLE_TLV' than just pass one byte value).
    	int Le,		///< Maximum length of data expected in response or Zero(0).
	func_callback func_cb	///< pointer to call back function for logging the apdu.
)	{
  	BYTE P1, P2;
  	switch(tag_type) {
    		case DO_TAG_SIMPLE_TLV :
      			P1 = 0x02; P2 = (BYTE)tag;
      			break;
    		case DO_TAG_BER_TLV_ONE :
      			P1 = 0x00; P2 = (BYTE)tag;
      			break;
    		case DO_TAG_BER_TLV_TWO :
      			P1 = tag >> 8; P2 = tag & 0xFF;
      			break;
    		default :
      			P1 = 0; P2 = 0;
  	}
  	int return_code = this->setAPDU(0, INS_CMD_GET_DATA, P1, P2, 0, NULL, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Contructor for the PutData class.
 * It constructs an apdu of the Put Data command to manage the contents of an EF supporting DOs.
 *
 * - Constants defined for Tag type.
 *	- DO_TAG_DUMPING
 *	- DO_TAG_SIMPLE_TLV
 *	- DO_TAG_BER_TLV_ONE
 *	- DO_TAG_BER_TLV_TWO
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
PutDataAPDU::PutDataAPDU(
    	BYTE tag_type,		///< Type of the tag. Argument would be one of the constants defined for tag types.
    	WORD tag,		///< Tag of the DO according to the tag type whose value has to be modified (eg. if tag_type is 'DO_TAG_SIMPLE_TLV' than just pass one byte value).
    	BYTE Lc,		///< Length of the command data field or Zero.
    	BYTE *data,		///< Data Bytes according to tag passed.
	func_callback func_cb	///< pointer to call back function for logging the apdu.
)	{
  	BYTE P1, P2;
  	switch(tag_type) {
    		case DO_TAG_SIMPLE_TLV :
      			P1 = 0x02; P2 = (BYTE)tag;
      			break;
    		case DO_TAG_BER_TLV_ONE :
      			P1 = 0x00; P2 = (BYTE)tag;
      			break;
    		case DO_TAG_BER_TLV_TWO :
      			P1 = tag >> 8; P2 = tag & 0xFF;
      			break;
    		default :
      			P1 = 0; P2 = 0;
  	}
  	int return_code = this->setAPDU(0, INS_CMD_PUT_DATA, P1, P2, Lc, data, 0, func_cb);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * Contructor for the GetResponse class.
 * It constructs an apdu of the Get Response command to transmit [part of] reponse APDUs
 * that otherwise could not be transmitted by the avialable transmission protocol.
 *
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 */
GetResponseAPDU::GetResponseAPDU(
    	int Le,		///< Maximum length of data expected in response or Zero(0).
	func_callback func_cb	///< pointer to call back function for logging the apdu.
)	{
  	int return_code = this->setAPDU(0, INS_CMD_GET_RESPONSE, 0, 0, 0, NULL, Le, func_cb);
	if(return_code != NOERROR)	throw return_code;
}
