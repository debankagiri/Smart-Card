#include "stdafx.h"
#include "Error.h"
#include "SE.h"

using namespace std;
/**
 * Initializes the SEID & LCSI and adds DOs corresponding to them.
 *
 * Constants defined for LCSI:
 *	- LCSI_CREATION : Creation State
 *	- LCSI_INITIALISATION : Initialization State
 *	- LCSI_ACTIVATED : Activated State(optional)
 *	- LCSI_DEACTIVATED : Deactivated State(optional)
 *	- LCSI_TERMINATION : Termination State
 *
 * \return returns one of the following constants:
 *	- NOERROR
 *	- ERROR_WRONG_INPUT_PARAMETERS
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 */
int SE::init(
	BYTE SEID,	///< SEID byte argument.
	BYTE LCSI	///< LCSI byte argument. Argument must be one of the constant defined for LCSI.
)	{
	setTag(SE_TAG);	// set tag of the DO as 0x7B 
	this->SEID = SEID;
	BYTE *value = &SEID;
	int return_code = NOERROR;
	if((return_code = appendDO(SE_SEID, 1, value)) != NOERROR)	return return_code;	// append SEID in value
	this->LCSI = LCSI;
	value = &LCSI;
	return appendDO(SE_LCSI, 1, value);	// append LCSI in value
}

/**
 * Constructor intializes the value of the SEID with the given argument and LCSI to 0x05(Activated).
 *
 * \throw ERROR_WRONG_INPUT_PARAMETERS	exception indicating that wrong parameters were supplied.
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION	exception indicating that a dynamic memory allocation failed.
 */
SE::SE(
	BYTE SEID	///< SEID Byte argument.
)	{
	int return_code  = init(SEID, 0x05);
	if(return_code != NOERROR)	throw return_code;
}

/** 
 * Constructor: Intializes the value of the SEID and LCSI with the given arguments. 
 *
 * Constants defined for LCSI:
 *	- LCSI_CREATION : Creation State
 *	- LCSI_INITIALISATION : Initialization State
 *	- LCSI_ACTIVATED : Activated State(optional)
 *	- LCSI_DEACTIVATED : Deactivated State(optional)
 *	- LCSI_TERMINATION : Termination State
 *
 * \throw ERROR_WRONG_INPUT_PARAMETERS	exception indicating that wrong parameters were supplied.
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION	exception indicating that a dynamic memory allocation failed.
 */
SE::SE(
	BYTE SEID,	///< SEID Byte argument.
	BYTE LCSI	///< LCSI byte argument. Argument must be one of the constant defined for LCSI.
)	{
	int return_code = init(SEID, LCSI);
	if(return_code != NOERROR)	throw return_code;
}

/**
 * \brief Constructor intializes the value of the SEID and LCSI with the given arguments and 
 * appends the list of the CRTs given.
 * 
 * Constants defined for LCSI:
 *	- LCSI_CREATION : Creation State
 *	- LCSI_INITIALISATION : Initialization State
 *	- LCSI_ACTIVATED : Activated State(optional)
 *	- LCSI_DEACTIVATED : Deactivated State(optional)
 *	- LCSI_TERMINATION : Termination State
 *
 * \throw ERROR_WRONG_INPUT_PARAMETERS	exception indicating that wrong parameters were supplied.
 * \throw ERROR_DYNAMIC_MEMORY_ALLOCATION	exception indicating that a dynamic memory allocation failed.
 */
SE::SE(
	BYTE SEID,		///< SEID Byte argument.
	BYTE LCSI,		///< LCSI byte argument. Argument must be one of the constant defined for LCSI.
	const list<CRT> crtlist	///< List of CRTs to be added to Se template.
)	{
	int return_code = init(SEID, LCSI);
	if(return_code == NOERROR)	return_code = addCRT(crtlist);
	if(return_code != NOERROR)	throw return_code;
}

/** 
 * To add the list of CRTs to the SE template.
 *
 * \return returns one of the following constants:
 *	- NOERROR
 *	- ERROR_WRONG_INPUT_PARAMETERS
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 */
int SE::addCRT(
	const list<CRT>& crtlist	///< List of CRTs to be added to Se template.
)	{
	int return_code = NOERROR;
	for(list<CRT>::const_iterator p = crtlist.begin(); p!=crtlist.end(); p++)	{
		return_code = appendDO(*p);
		if(return_code != NOERROR)	break;
	}
	return return_code;
}

/** 
 * To add a CRT to the SE template. 
 *
 * \return returns one of the following constants:
 *	- NOERROR
 *	- ERROR_WRONG_INPUT_PARAMETERS
 *	- ERROR_DYNAMIC_MEMORY_ALLOCATION
 */
int SE::addCRT(
	const CRT& crt		///< CRT to be added to the SE temlate.
)	{
	return appendDO(crt);
}

/** 
 * To get the value of the SEID Byte.
 * \return SEID Byte. 
 */
BYTE SE::getSEID(void) const	{
	return SEID;
}

/** 
 * To get the value of the LCSI byte. 
 * \return LCSI Byte.
 */
BYTE SE::getLCSI(void) const	{
	return LCSI;
}
