#include "stdafx.h"
#include "crypto.h"
#include "Error.h"

/**
 * Constuctor for cryptospec class.
 * Initializes various members of object with supplied arguments.
 */
cryptospec::cryptospec(
	char *algo,	///< string name of the cryptographic library.
	BYTE *key,	///< key to be used by the cryptographic library.
	int keylen,	///< length of the key to be used by the cryptographic library.
	BYTE *iv,	///< iv to be used by the cryptographic library.
	int ivlen	///< length of iv to be used by the cryptographic library.
)	{
	this->algo = algo;
	this->key = key;
	this->keylen = keylen;
	this->iv = iv;
	this->ivlen = ivlen;
}

/**
 * Initializes all the members of Algoentry object to NULL.
 */
void Algoentry::init()	{
	this->algo_name = NULL;
	this->lib_handle = NULL;
	this->getBlkSize = NULL;
	this->encrypt = NULL;
  	this->getEncryptLen = NULL;
  	this->decrypt = NULL;
  	this->getDecryptLen = NULL; 
  	this->cc_compute = NULL;
  	this->getCCLen = NULL;
  	this->cc_verify = NULL;
  	this->hash_compute = NULL;
  	this->getHashLen = NULL;
  	this->hash_verify = NULL;
  	this->dsig_compute = NULL;
  	this->getDsigLen = NULL;
  	this->dsig_verify = NULL;
}

/**
 * Constructor for Algoentry class.
 * It loads the cryptographic library and sets the pointers for various cryptographic operations provided by the cryptographic library. 
 *
 * For loading the cryptographic library it uses dlopen() on linux and LoadLibrary()on Windows.
 * For getting pointers to various functions of the cryptographic library it uses dlsym() on linux and GetProcAddress() on Windows.
 *
 * \throw CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION exception indicating dynamic memory failure.
 * \throw CRYPTO_LIBRARY_NOTFOUND exception indicating the crypto library was not found.
 */
Algoentry::Algoentry(const char* algo_name)	{
	init();
	this->algo_name = (char*) malloc(strlen(algo_name) + 1);
	if(this->algo_name == NULL)	throw CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION;

	strcpy(this->algo_name, algo_name);

	char *libname = NULL;
	if((libname = (char *) malloc(strlen(algo_name) + 5)) == NULL)	throw CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION;
	strcpy(libname, algo_name);
	#ifdef WIN32
  		strcat(libname, ".dll");
  		this->lib_handle = LoadLibrary(libname);
	#else
  		strcat(libname, ".so");
  		this->lib_handle = dlopen(libname, RTLD_LOCAL | RTLD_LAZY);
	#endif
	free(libname);
	if (this->lib_handle == NULL)   throw CRYPTO_LIBRARY_NOTFOUND;
	
	this->getBlkSize = (getBlockSize_Func) WINLIN(this->lib_handle, "getBlkSize");

	this->encrypt = (encrypt_Func) WINLIN(this->lib_handle, "encrypt");
  	this->getEncryptLen = (getEncryptLen_Func) WINLIN(this->lib_handle, "getEncryptLen");

  	this->decrypt = (decrypt_Func) WINLIN(this->lib_handle, "decrypt");
	this->getDecryptLen = (getDecryptLen_Func) WINLIN(this->lib_handle, "getDecryptLen");

	this->cc_compute = (cc_compute_Func) WINLIN(this->lib_handle, "cc_compute");
  	this->getCCLen = (getCCLen_Func) WINLIN(this->lib_handle, "getCCLen");
	this->cc_verify = (cc_verify_Func) WINLIN(this->lib_handle, "cc_verify");
	
  	this->hash_compute = (hash_compute_Func) WINLIN(this->lib_handle, "hash_compute");
	this->getHashLen = (getHashLen_Func) WINLIN(this->lib_handle, "getHashLen");
  	this->hash_verify = (hash_verify_Func) WINLIN(this->lib_handle, "hash_compute");

	this->dsig_compute = (dsig_compute_Func) WINLIN(this->lib_handle, "dsig_compute");
  	this->getDsigLen = (getDsigLen_Func) WINLIN(this->lib_handle, "getDsigLen");
	this->dsig_verify = (dsig_verify_Func) WINLIN(this->lib_handle, "dsig_verify");
}

/**
 * Destructor for Algoentry.
 * Closes the library handle for the dynamically loaded library.
 */
Algoentry::~Algoentry()	{
	if(this->algo_name != NULL)	free(this->algo_name);
	if(this->lib_handle != NULL)	{
#ifdef WIN32
  		FreeLibrary(this->lib_handle);
#else
  		dlclose(this->lib_handle);
#endif
	}
	init();
}

/**
 * This function compares the cryptographic algorithm provided with the cryptographic algorithm corresponding to the Algoentry object.
 *\return Returns true if the input cryptographic algorithm matches the cryptographic algorithm corresponding to Algoentry object else it returns false.
 */
bool Algoentry::isAlgorithm(
	const char* algo_name	///< crypto algorithm name to be matched
)	{
	if(strcmp(this->algo_name, algo_name) == 0)	return true;
	else	return false;
}

/**
 * This function performs the cryptographic operation with the cryptographic algorithm corresponding to the Algoentry object.
 *
 * This input arguments and return values for this function are same as those for CryptoFunc() function. Refer to CryptoFunc() for more details.
 */
int Algoentry::perform_crypto_op(int op, const BYTE *in, int inlen, BYTE *out, int outlen, const BYTE *key, int keylen, BYTE *iv, int ivlen)	{
  	switch(op) {
 	   	case ENCRYPT:
        		if(this->encrypt == NULL)	return CRYPTO_OP_NOT_SUPPORTED;
        		return (this->encrypt) (in, inlen, out, outlen, key, keylen, iv, ivlen);

    		case DECRYPT:
	        	if(this->decrypt== NULL)	return CRYPTO_OP_NOT_SUPPORTED;
        		return (this->decrypt) (in, inlen, out, outlen, key, keylen, iv, ivlen);

	    	case CC_COMPUTE:
        		if(this->cc_compute == NULL)	return CRYPTO_OP_NOT_SUPPORTED;
	        	return (this->cc_compute) (in, inlen, out, outlen, key, keylen, iv, ivlen);

	    	case CC_VERIFY:
        		if(this->cc_verify == NULL)	return CRYPTO_OP_NOT_SUPPORTED;
        		return (this->cc_verify) (in, inlen, out, outlen, key, keylen, iv, ivlen);

    		case HASH_COMPUTE:
        		if(this->hash_compute == NULL)	return CRYPTO_OP_NOT_SUPPORTED;
	        	return (this->hash_compute) (in, inlen, out, outlen, key, keylen, iv, ivlen);

	    	case HASH_VERIFY:
        		if(this->hash_verify == NULL)	return CRYPTO_OP_NOT_SUPPORTED;
	        	return (this->hash_verify) (in, inlen, out, outlen, key, keylen, iv, ivlen);

	    	case DSIG_COMPUTE:
			if(this->dsig_compute == NULL)	return CRYPTO_OP_NOT_SUPPORTED;
			return (this->dsig_compute) (in, inlen, out, outlen, key, keylen, iv, ivlen);

    		case DSIG_VERIFY:
			if(this->dsig_verify == NULL)	return CRYPTO_OP_NOT_SUPPORTED;
			return (this->dsig_verify) (in, inlen, out, outlen, key, keylen, iv, ivlen);

	    	default:
			return CRYPTO_OP_NOT_SUPPORTED;
  	}
}

/**
 * This functions gets an estimate of the length of the output when the input operation is performed on the input buffer.
 *
 * This input arguments and return values for this function are same as those for getOutLen() function. Refer to getOutLen() for more details.
 */
int Algoentry::get_crypto_op_outlen(int op, const BYTE *in, int inlen, const BYTE *key, int keylen, BYTE *iv, int ivlen )	{
	switch(op) {
		case ENCRYPT:
			if(this->getEncryptLen == NULL)	return CRYPTO_OP_NOT_SUPPORTED;
        		return (this->getEncryptLen) (in, inlen, key, keylen, iv, ivlen);

		case DECRYPT:
			if(this->getDecryptLen == NULL)	return CRYPTO_OP_NOT_SUPPORTED;
        		return (this->getDecryptLen) (in, inlen, key, keylen, iv, ivlen);

		case CC_COMPUTE:
			if(this->getCCLen == NULL)	return CRYPTO_OP_NOT_SUPPORTED;
        		return (this->getCCLen) (in, inlen, key, keylen, iv, ivlen);

		case DSIG_COMPUTE:
			if(this->getDsigLen == NULL)	return CRYPTO_OP_NOT_SUPPORTED;
        		return (this->getDsigLen) (in, inlen, key, keylen, iv, ivlen);

		case HASH_COMPUTE:
			if(this->getHashLen == NULL)	return CRYPTO_OP_NOT_SUPPORTED;
			return (this->getHashLen) (in, inlen, key, keylen, iv, ivlen);

		default:
			return CRYPTO_OP_NOT_SUPPORTED;
	}
}

/**
 * This functions gets the Block Size of the cryptographic algorithm correspondidng to the Algoentry object.
 *
 * This input arguments and return values for this function are same as those for getBlockSize() function. Refer to getBlockSize() for more details.
 */
int Algoentry::get_crypto_blocksize(const BYTE *key, int keylen, BYTE *iv, int ivlen)	{
	if(this->getBlkSize == NULL)	return CRYPTO_OP_NOT_SUPPORTED;
	return (this->getBlkSize) (key, keylen, iv, ivlen);
}

/**
 * Destructor for AlgoentryList class. 
 * 
 * It first deletes the Algoentry objects whose pointers are stored in ALgoentryList and then deletes the AlgoentryList.
 */
AlgoentryList::~AlgoentryList()	{
	for(list<Algoentry*>::iterator q = this->algolist.begin(); q != this->algolist.end(); q++)
		delete *q;
}

/**
 * This function returns a pointer of an Algoentry object correspoding to the supplied cryptographic library.
 *
 * If the Algoentry object corresponding to the supplied cryptographic library is not present in AlgoentryList then the Algoentry object is first created.
 *
 * \return Returns one of the following constants:
 *	- CRYPTO_LIBRARY_FOUND
 *	- CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION
 *	- CRYPTO_LIBRARY_NOTFOUND
 */
int AlgoentryList::getAlgoentry(
	const char* algo_name,	///< NULL terminated string containg the name of the crypto library to be loaded.
	Algoentry** algoentry	///< Algoentry pointer corresponding to the crypto library is stored here if the library is found.
)	{
	list<Algoentry*>::const_iterator p = this->algolist.begin();
	for( ; p != this->algolist.end() ; p++)	{
		if((*p)->isAlgorithm(algo_name))	break;
	}
	if(p != this->algolist.end())	{
		*algoentry = *p;
		return CRYPTO_LIBRARY_FOUND;
	}
	
	// algo library not loaded, thus load the library
	Algoentry *talgo = NULL;
	try	{
		talgo = new Algoentry(algo_name);
	}
	catch(bad_alloc &)	{
		return CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION;
	}
	catch(int exp)	{
		delete talgo;
		return exp;
	}

	try	{
		this->algolist.push_back(talgo);
	}
	catch(bad_alloc &)	{
		return CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION;
	}
	*algoentry = talgo;
	return CRYPTO_LIBRARY_FOUND;
}

static AlgoentryList algorecords;	///< Algoentry List object to keep track of the cryptographic libraries that have beeen loaded.

/**
 * This is an overloaded function to get the Block Size of the provided cryptographic algorithm.
 *
 * This function takes following arguments - algo, key, keylen, iv & ivlen. They have the same meaning as defined in CryptoFunc function.
 * Refer to CryptoFunc function for more details.
 *
 * \return
 *	The return value of this function can be a positive integer or one of the constants defined below. 
 * 	If the return value is a positive integer then it is the Block Size for the input cryptographic algorithm.
 * 	The return constants and their meanings:
 *		- CRYPTO_INCONSISTENT_KEY	: Keylength or the key structure is not correct.
 *		- CRYPTO_INCONSISTENT_IV	: IV or IVlength is not consistent with the function.
 *		- CRYPTO_INTERNAL_ERROR		: An error in the crypto library that cannot be recovered.
 *		- CRYPTO_LIBRARY_NOTFOUND	: Error constant indicating that the dynamic library corresponding to cryptographic algorithm(algo) was not found.
 *		- CRYPTO_OP_NOT_SUPPORTED	: Error constant indicating that the cryptographic algorithm(algo) does not support the getBlockSize funtion.
 *		- CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION	: Error constant indicating that a dynamic memory allocation failure occured.
 */
int getBlockSize(const char *algo, const BYTE *key, int keylen, BYTE *iv, int ivlen)	{
	Algoentry* algoptr = NULL;
	int return_code = algorecords.getAlgoentry(algo, &algoptr);
	if(return_code != CRYPTO_LIBRARY_FOUND)	return return_code;
	return algoptr->get_crypto_blocksize(key, keylen, iv, ivlen);
}

/**
 * This is the second form of overloaded function getBlockSize.
 *
 * It takes the following arguments - spec. In this form spec is an reference to an cryptospec object. The members of spec(algo, key, keylen , iv & ivlen) have 
 * the same meaning as defined in CryptoFunc function. Refer to CryptoFunc function for more details.
 *
 * \return The return values of this form are same as the other form of getBlockSize(refer to other form of getBlockSize for details)
 */
int getBlockSize(cryptospec &spec)	{
  	return getBlockSize(spec.algo, spec.key, spec.keylen, spec.iv, spec.ivlen);
}

/** 
 * This is an overloaded function, that returns the maximum possible length of the out buffer for the input operation and cryptographic algorithm.
 *
 * The ENCRYPT, DECRYPT, CC_COMPUTE, HASH_COMPUTE & DSIG_COMPUTE operations of CryptoFunc function return 
 * a result string in the out buffer. The space for out buffer for these operations should be allocated by the caller. 
 * Thus to get an estimate of the space to be allocated for the out buffer for these operations, getOutLen is used.
 *
 * This form of the getOutLen takes the following arguments - op, in, inlen, algo, key, keylen, iv & ivlen.
 *
 * Meaning of the operands of getOutLen is as follows:
 *
 * op: Can be one of the following:
 *	- ENCRYPT : Gives an estimate of the length of the encrypted cipher text obtained from encrypting data in "in" buffer.
 *		- in: Input plaintext to be encrypted.
 *		- inlen: Length of the input.
 *
 *	- DECRYPT : Gives an estimate of the length of the decrypted plaintext obtained from decrypting data in "in" buffer.
 *		- in: Ciphertext to be decrypted.
 *		- inlen: Length of the ciphertext.
 *
 *	- CC_COMPUTE : Gives an estimate of the length of the Cryptographic Checksum of the data in "in" buffer.
 *		- in: Message of which the cryptographic checksum will be computed.
 *		- inlen: Length of the message.
 *
 *	- HASH_COMPUTE : Gives an estimate of the length of the Hash of the data in "in" buffer.
 *		- in: Message whose hash has to be computed.
 *		- inlen: Length of the message.
 *
 *	- DSIG_COMPUTE : Gives an estimate of the length of the Digital Signature of the data in "in" buffer.
 *		- in: Message whose digital signature has to be computed.
 *		- inlen: Length of the message.
 * 
 * algo, key, keylen, iv & ivlen have the same meaning as defined in CryptoFunc function.
 *
 * \return
 *	Return value for getOutLen function can be a positive integer or one of the constants defined below. 
 * 	If the return value is a positive integer then it repesents the maximum possible length of the out buffer.
 * 	The return constants and their meanings:
 *		- CRYPTO_INCONSISTENT_INPUT	: The input length is inconsistent.
 *		- CRYPTO_INCONSISTENT_KEY	: Keylength or the key structure is not correct.
 *		- CRYPTO_INCONSISTENT_IV	: IV or IVlength is not consistent with the function.
 *		- CRYPTO_INTERNAL_ERROR		: An error in the crypto library that cannot be recovered.
 *		- CRYPTO_LIBRARY_NOTFOUND	: Error constant indicating that the dynamic library corresponding to cryptographic algorithm(algo) was not found.
 *		- CRYPTO_OP_NOT_SUPPORTED	: Error constant indicating that the cryptographic algorithm(algo) does not support the mentioned operations.
 *		- CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION	: Error constant indicating that a dynamic memory allocation failure occured.
 */
int getOutLen(int op, const BYTE *in, int inlen, const char *algo, const BYTE *key, int keylen, BYTE *iv, int ivlen)	{
	Algoentry* algoptr = NULL;
	int return_code = algorecords.getAlgoentry(algo, &algoptr);
	if(return_code != CRYPTO_LIBRARY_FOUND)	return return_code;
	return algoptr->get_crypto_op_outlen(op, in, inlen, key, keylen, iv, ivlen);
}

/**
 * This is the second form of overloaded function getOutLen. 
 *
 * It takes the following arguments - op, in, inlen & spec. op, in and inlen are same as defined in the other form of getOutLen.
 * In this form spec is an reference to an cryptospec object. The members of spec(algo, key, keylen , iv & ivlen) have 
 * the same meaning as algo, key, keylen, iv & ivlen of the other form of getOutLen.
 *
 * \return The return values of this form are same as the other form of getOutLen(refer to other form of getOutLen for details)
 */
int getOutLen(int op, const BYTE *in, int inlen, cryptospec &spec)	{
  	return getOutLen(op, in, inlen, spec.algo, spec.key, spec.keylen, spec.iv, spec.ivlen);
}

/**
 * CryptoFunc is an overloaded generic function which provides a single entry for all the cryptographic functions.
 *
 * This form of CryptoFunc takes the following operands - op, in, inlen, out, outlen, algo, key, keylen, iv, ivlen.
 * 
 * The meaning of in, inlen, out & outlen operands depends upon the op code supplied to CryptoFunc. 
 * Whereas the meaning of algo, key, keylen, iv & ivlen operands is independent of op code supplied(it depends 
 * on the cryptographic algorithm).
 *
 * Meaning of the operands of CryptoFunc is as follows:
 *
 * op: Can be one of the following.
 *	- ENCRYPT : Encryption operation. 
 *		- in: Input plaintext to be encrypted.
 *		- inlen: Length of the input.
 *		- out: buffer in which the encrypted ciphertext is stored.
 *		- outlen: Length of the out buffer. To be provided by the caller.
 *
 *	- DECRYPT : Decryption operation.
 *		- in: Ciphertext to be decrypted.
 *		- inlen: Length of the ciphertext.
 *		- out: buffer in which the decrypted plaintext is stored.
 *		- outlen: Length of the out buffer. To be provided by the caller.
 *
 *	- CC_COMPUTE : Cryptographic Checksum Computation operation.
 *		- in: Message of which the cryptographic checksum will be computed.
 *		- inlen: Length of the message.
 *		- out: buffer in which the computed cryptographic checksum is stored.
 *		- outlen: Length of the out buffer. To be provided by the caller.
 *
 *	- CC_VERIFY : Cryptographic Checksum Verification operation.
 *		- in: Message whose cryptographic checksum is to be verified.
 *		- inlen: Length of the message.
 *		- out: Cryptographic checksum to be verified.
 *		- outlen: Length of the cryptgraphic checksum.
 *
 *	- HASH_COMPUTE : Hash Computation operation.
 *		- in: Message whose hash has to be computed.
 *		- inlen: Length of the message.
 *		- out: buffer in which the computed hash is stored.
 *		- outlen: Length of the out buffer. To be provided by the caller.
 *
 *	- HASH_VERIFY : Hash Verification operation.
 *		- in: Message whose hash is to be verified.
 *		- inlen: Length of the message.
 *		- out: Hash to be verified.
 *		- outlen: Length of the hash.
 *
 *	- DSIG_COMPUTE : Digital Signature Computation operation.
 *		- in: Message whose digital signature has to be computed.
 *		- inlen: Length of the message.
 *		- out: buffer in which the computed digital signature is stored.
 *		- outlen: Length of the out buffer. To be provided by the caller.
 *
 *	- DSIG_VERIFY : Digital Signature Verification operation.
 *		- in: Message whose digital signature is to be verified.
 *		- inlen: Length of the message.
 *		- out: Digital signature to be verified.
 *		- outlen: Length of the digital signature.
 * 
 * In operations where out buffer is used to output the resultant data(ENCRYPT, DECRYPT, CC_COMPUTE, HASH_COMPUTE & DSIG_COMPUTE),
 * out buffer is considered to be allocated by the caller. CryptoFunc will ennsure that no overflow takes place while writing in 
 * out buffer in these operations. 
 * Thus first get an estimate on the length out buffer by calling getOutLen() function, and then supply 
 * an out buffer of the estimated length to CryptoFunc().
 *
 * Currently following cryptographic algorithms are supported with the command library:
 *	- tdes-cbc		: This corresponds to Triple DES algorithm. It supports encrytion & decryption operations in CBC mode using the 
 *				  specified iv(8-byte long) and key (16-byte long). If no iv value is supplied(i.e. iv = NULL or ivlen = 0) then
 *				  a default value of zero is used.
 *
 * 	- tdes-mac		: This corresponds to Triple DES algorithm. It supports cryptographic checksum computation & cryptographic cheksum verification 
 *				  operations using the specified iv(8-byte long) and key(16-byte long). If no iv value is supplied(i.e. iv = NULL or ivlen = 0)
 *				  then a default value of zero is used. The basic core of the cryptographic checksum computation operations is
 *				  identical to the tdes-cbc except that it provides only the last block of the ciphertext.
 *
 *	- epp-tdes-mac		: This corresponds to Triple DES algorithm. It supports cryptographic checksum computation & cryptographic cheksum verification
 *				  operations using the specified iv(8-byte long) and key(16-byte long). The value of iv is used as a SSC (Send Sequence Counter).
 *				  The SSC is first incremented prior to the computation of the checksum and hence must be only in a C variable. It would be a 
 *				  run-time error to specify the IV as a constant string.
 *
 *	- epp-tdes-mac-nossc	: This corresponds to Triple DES algorithm. It supports cryptographic checksum computation & cryptographic cheksum verification 
 *				  operations. It is essentially same as the epp-tdes-mac algorithm except that no 
 *				  SSC is used. Accordingly the value specified in the iv is disregarded.
 *
 *	- sha1			: This corresponds to SHA-1 algorithm.
 *				  It upports HASH_COMPUTE & HASH_VERIFY operations. The values of key and iv are disregarded.
 *
 *	- rsa_pkcs1_v1_5	: This corresponds to RSA algorithm defined in PKCS#1 version 2.1. It supports encryption (RSAES-PKCS1-v1_5),
 *				  decryption (RSAES-PKCS1-v1_5), digital signature generation (RSASSA-PKCS1-v1_5) and digital signature 
 *				  verification (RSASSA-PKCS1-v1_5) operations. The value of iv is disreagrded.
 *
 *	- rsa_pkcs1_v2_1	: This corresponds to RSA algorithm defined in PKCS#1 version 2.1. It supports encryption (RSAES-OAEP), decryption (RSAES-OAEP),
 *				  digital signature generation (RSASSA-PSS) and digital signature verification (RSASSA-PSS) operations. The value of iv is disreagrded.
 *
 * \return Return value for this function can be a positive integer or one of the constants defined below. 
 * 	If the return value is a positive integer then it repesents the output length of the out buffer. 
 * 	The return constants and their meaning: 
 *		- CRYPTO_VERIFY_SUCCESS		: The verification was successful.
 * 		- CRYPTO_VERIFY_FAILURE		: The verification was not successful.
 *		- CRYPTO_INCONSISTENT_INPUT	: The input length is inconsistent.
 *		- CRYPTO_INCONSISTENT_OUTPUT	: Output length is inconsistent(Not enough to store the entire output in out buffer).
 *		- CRYPTO_INCONSISTENT_KEY	: Keylength or the key structure is not correct.
 *		- CRYPTO_INCONSISTENT_IV	: IV or IVlength is not consistent with the function.
 *		- CRYPTO_INTERNAL_ERROR		: An error in the crypto library that cannot be recovered.
 *		- CRYPTO_LIBRARY_NOTFOUND	: Error constant indicating that the dynamic library corresponding to cryptographic algorithm(algo) was not found.
 *		- CRYPTO_OP_NOT_SUPPORTED	: Error constant indicating that the cryptographic algorithm(algo) does not support the mentioned operations.
 *		- CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION	: Error constant indicating that a dynamic memory allocation failure occured.
 *
 * 	The return value of CryptoFunc depends on op code supplied to CryptoFunc.
 *	- for ENCRYPT, DECRYPT, CC_COMPUTE, HASH_COMPUTE & DSIG_COMPUTE op codes, the return value 
 *	can be a positive integer representing the length of the data in out buffer or it can be one of 
 * 	the following error constants - CRYPTO_INCONSISTENT_INPUT, CRYPTO_INCONSISTENT_OUTPUT, 
 *	CRYPTO_INCONSISTENT_KEY, CRYPTO_INCONSISTENT_IV, CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION, CRYPTO_LIBRARY_NOTFOUND, 
 *	CRYPTO_OP_NOT_SUPPORTED & CRYPTO_INTERNAL_ERROR.
 *
 *	- for CC_VERIFY, HASH_VERIFY & DSIG_VERIFY the return value can be one of the return constants - 
 *	CRYPTO_SUCCESS, CRYPTO_FAILURE, CRYTO_CRYPTO_INCONSISTENT_INPUT, CRYPTO_INCONSISTENT_OUTPUT, 
 *	CRYPTO_INCONSISTENT_KEY, CRYPTO_INCONSISTENT_IV, CRYPTO_FAILURE_DYNAMIC_MEMORY_ALLOCATION, CRYPTO_LIBRARY_NOTFOUND, 
 *	CRYPTO_OP_NOT_SUPPORTED & CRYPTO_INTERNAL_ERROR.
 */
int CryptoFunc(int op, const BYTE *in, int inlen, BYTE *out, int outlen, const char *algo, const BYTE *key, int keylen, BYTE *iv, int ivlen)	{
	Algoentry* algoptr = NULL;
	int return_code = algorecords.getAlgoentry(algo, &algoptr);
	if(return_code != CRYPTO_LIBRARY_FOUND)	return return_code;
	return algoptr->perform_crypto_op(op, in, inlen, out, outlen, key, keylen, iv, ivlen);
}

/**
 * This is the second form of overloaded function CryptoFunc.
 *
 * It takes the following arguments - op, in, inlen , out, outlen & spec. op, in, inlen, out, outlen are same as defined in the other form of CryptoFunc. 
 * In this form spec is an reference to an cryptospec object. The members of spec(algo, key, keylen , iv & ivlen) have 
 * the same meaning as algo, key, keylen, iv & ivlen of CryptoFunc.
 *
 * \return The return values of this form are same as the other form of CryptoFunc(refer to other form of CryptoFunc for details)
 */
int CryptoFunc(int op, const BYTE *in, int inlen, BYTE *out, int outlen, cryptospec &spec)	{
  	return CryptoFunc(op, in, inlen, out, outlen, spec.algo, spec.key, spec.keylen, spec.iv, spec.ivlen);
}
	
