#include "stdafx.h"
#include "Error.h"
#include "Compact.h"

/**
 * Default constructor. Initializes the Access Mode byte and the corresponding Security Condition byte to Zero(0)
 */
CompactAccessRule::CompactAccessRule(void)	{
	No_Conditions = 0;
	Access_Mode = 0x00;
}

/** 
 * Adds the given Access Mode conditions and corresponding Security Condition byte for each bit(set to 1) of Access Mode Byte.
 *
 * Constants defined for Access Mode Byte.
 *	- AM_DELETE_SELF
 *	- AM_TERMINATE
 *	- AM_ACTIVATE
 *	- AM_DEACTIVATE
 *	- AM_CREATE_DF
 *	- AM_CREATE_EF
 *	- AM_DELETE_CHILD
 *	- AM_WRITE_APPEND
 *	- AM_UPDATE_ERASE
 *	- AM_READ_SEARCH
 *
 * Constants defined for Security Condition Byte.
 *	- SC_COMPACT_NEVER
 *	- SC_NO_REFERENCE
 *	- SC_SE1 to SC_SE14
 *	- SC_ATLEAST_ONE
 *	- SC_ALL
 *	- SC_SM
 *	- SC_EXT_AUTH
 *	- SC_USER_AUTH
 *
 * \return returns one of the following constants:
 *	- NOERROR
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int CompactAccessRule::setCompactAccessRule(
	BYTE AM_op,	///< Access mode conditions. Argument will be in the format of OR-ing of different constants defined for Access Mode Byte.
	BYTE SC_Byte	///< Security condition byte corresponding to the access mode conditions. Argument must be given in the format of OR-ing
			///< of different Security condition constants.
)	{
	if(AM_op >= 0x80) return ERROR_WRONG_INPUT_PARAMETERS;
	for(int i = 6; i >= 0; i--)	{ // Loop over the bits of AM_op
		int position = 0;
		if((AM_op & (1 << i)) == 0) continue; 

		for (int j = 6; j > i; j--) 
			if(Access_Mode & (1 << j)) position++;

		// If the SC_byte is already set for this particular bit then 
		// replace the SC condition.
		if(Access_Mode & (1 << i))	{
			SC_Bytes[position] = SC_Byte;
		} 
		else {
			// Updating the Access mode byte
			Access_Mode |= (1 << i);
			// Calculating the position where new SC byte would be inserted.
			for(int j = 6; j > position; j--)
				SC_Bytes[j] = SC_Bytes[j-1];
			SC_Bytes[position] = SC_Byte;
			No_Conditions++;
		}
	}
	return NOERROR;
}

/**
 * To get the total length of the string which consists of an Access mode byte followed by Security Condition bytes.
 * \return Total length.
 */
int CompactAccessRule::getTotalLength(void) const	{
	return No_Conditions + 1;
}

/**
 * Writes the Access Mode byte followed by the corresponding Security Condition bytes for each bit of Access mode bit in the given buffer.
 *
 * \return returns one of the following constants:
 *	- NOERROR
 *	- ERROR_WRONG_INPUT_PARAMETERS
 */
int CompactAccessRule::getTotalBytes(
	BYTE *buffer	///< Buffer in which total byte stream would be written.
) const	{
	if(buffer == NULL)	return ERROR_WRONG_INPUT_PARAMETERS;
	buffer[0] = Access_Mode;
	memcpy(buffer+1, SC_Bytes, No_Conditions);
	return NOERROR;
}
