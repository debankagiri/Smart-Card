#pragma once

#ifdef WIN32
#include <tchar.h>
#endif

#include <winscard.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ISOTag.h"
#include "Error.h"

#ifdef WIN32
	#define strdup _strdup
#endif 

typedef unsigned char BYTE;		///< unsigned char
typedef unsigned short WORD;		///< unsigned short
typedef unsigned int UINT;		///< unsigned integer
