#pragma once

#include "stdafx.h"
#include "DO.h"

// Constants defined for the Control Reference Template(CRT)'s "Tag" field..
#define CRT_AT	0xA4	///< Constant for Authentication tag in the Control Reference template(CRT) 
#define CRT_KAT	0xA6	///< Constant for Key Agreement tag in the Control Reference template(CRT) 
#define CRT_HT  0xAA	///< Constant for Hash-Code tag in the Control Reference template(CRT) 
#define CRT_CCT	0xB4	///< Constant for Cryptographic Checksum tag in the Control Reference template(CRT) 
#define CRT_DST	0xB6	///< Constant for Digital signature tag in the Control Reference template(CRT) 
#define CRT_CT	0xB8	///< Constant for Confidentiality tag in the Control Reference template(CRT) 

// Constants for CRDO's tag field. These tags have relevance to CCT,DST,CT,HT,AT.
#define CRT_ALGO_REF			0x80	///< Tag of CRDO containing algorithm reference.
#define CRT_KEY_REFERENCE_DATA 		0x83	///< Tag of CRDO containing qualifier of reference data
#define CRT_KEY_DIRECT_SYM		0x83	///< Tag of CRDO containing key reference for direct use in symmetric cases.
#define CRT_KEY_PUBLIC_ASYM		0x83 	///< Tag of CRDO containing key reference for referencing a public key in asymmetric cases.
#define CRT_KEY_SESSION_SYM		0x84	///< Tag of CRDO containing key reference for computing	a session key in symmetric cases.		
#define CRT_KEY_PRIVATE_ASYM		0x84	///< Tag of CRDO containing key reference for referencing a private key in asymmetric cases.	
#define CRT_NULL_BLOCK			0x85	///< Tag of CRDO having "null" Initial check block.					
#define CRT_CHAINING_BLOCK		0x86	///< Tag of CRDO having "chaining" Initial check block.
#define CRT_IV_BLOCK			0x87	///< Tag of CRDO having "initial value(IV)" Initial check block.
#define CRT_CHALLENGE_OR_DATA		0x94	///< Tag of CRDO with challenge or data item for deriving a key.
#define CRT_USAGE_QUALIFIER		0x95	///< Tag of CRDO with usage qualifier.

/**
 * \brief Class representing CRT(Control Reference Template).
 *
 * CRT class objects are constructed DOs. 
 * The 'tag' of the CRT will be one of the following constants:
 *	- CRT_AT : Authentication Template
 *	- CRT_KAT : Key Agreement Template
 *	- CRT_HT : Hash Template
 *	- CRT_CCT : Cryptographic Checksum Template
 *	- CRT_DST : Digital Signature Template
 *	- CRT_CT : Confidentiality Template
 *
 * The "value" field is the concatenation or the list of Control Reference Data objects(CRDO).
 */
class CRT : public DO	{
public:
	CRT(BYTE tag_arg);
	CRT(BYTE tag_arg, WORD length_arg, const BYTE *value_arg);
	CRT(const CRT &do_arg);
	~CRT(void);
	int appendCRDO(BYTE tag_CRDO, WORD length_CRDO, const BYTE *value_CRDO);
};
