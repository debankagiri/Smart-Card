#include "Error.h"

/**
 * This function converts the error code of the PCSClite library to a command library return code.
 * \return Returns the error code corresponding to Command Library for the PCSClite return code.
 */
int return_PCSC_Error(LONG rv)	{
	switch(rv)	{
		case SCARD_E_INVALID_VALUE:		return PCSC_INVALID_VALUE;
		case SCARD_E_INVALID_HANDLE:		return PCSC_INVALID_HANDLE;
		case SCARD_E_INSUFFICIENT_BUFFER:	return PCSC_INSUFFICIENT_BUFFER;
		case SCARD_E_NO_READERS_AVAILABLE:	return PCSC_NO_READERS_AVAILABLE;
		case SCARD_E_READER_UNAVAILABLE:	return PCSC_READER_UNAVAILABLE;
		case SCARD_E_NO_SMARTCARD:		return PCSC_NO_SMARTCARD_PRESENT;
		case SCARD_E_NOT_READY:			return PCSC_READER_NOT_READY;
		case SCARD_E_UNSUPPORTED_FEATURE:	return PCSC_PROTOCOL_NOT_SUPPORTED;
		case SCARD_E_SHARING_VIOLATION:		return PCSC_SHARING_VIOLATION;
		case SCARD_E_NOT_TRANSACTED:		return PCSC_TRANSMISSION_ERROR;
		case SCARD_E_PROTO_MISMATCH:		return PCSC_INVALID_PROTOCOL;
		case SCARD_W_RESET_CARD:		return PCSC_SMARTCARD_RESET;
		case SCARD_E_NO_SERVICE:		return PCSC_NO_SERVICE;
		case SCARD_E_NO_MEMORY:			return PCSC_NO_MEMORY;
		case SCARD_W_REMOVED_CARD:		return PCSC_CARD_REMOVED;
		case SCARD_W_UNPOWERED_CARD:		return PCSC_UNPOWERED_CARD;
		case SCARD_W_UNRESPONSIVE_CARD:		return PCSC_UNRESPONSEIVE_CARD;
		case SCARD_E_UNKNOWN_READER:		return PCSC_UNKNOWN_READER;
		default:				return PCSC_UNKNOWN_ERROR;
	}
}

const char* cmdlib_stringify_error(int err)	{
	switch(err)	{
		case NOERROR:	return NULL;
		case ERROR_DYNAMIC_MEMORY_ALLOCATION:	return "Dynamic Memory Allocation Failure";
		case ERROR_WRONG_INPUT_PARAMETERS:	return "Incorrect Input Arguments Supplied";
		case ERROR_SMRESPONSE_INCORRECT_SMDO_OBTAINED:	return "Wrong SM DOs in SM Response";
		case ERROR_SMRESPONSE_DUPLICATE_SMDOS_OBTAINED:	return "Duplicate SM DOs in same SM Context in SM Response";
		case ERROR_SMRESPONSE_INCORRECT_CC_SMDO_OBTAINED:	return "0x8E SM DO in SM Response is not the last DO";
		case ERROR_SMRESPONSE_INCORRECT_STATUS_SMDO_OBTAINED:	return "0x99 SM DO in SM Response has wrong length";
		case ERROR_SMRESPONSE_CC_TAG_WRONG_PARAM:	return "Incorrect Crypto Specifications/ Crypto Algorithm Not Supported for 0x8E SM Response Tag";
		case ERROR_SMRESPONSE_CC_VERIFICATION_FAILED:	return "Crypto Checksum Verification Failed";
		case ERROR_SMRESPONSE_MULTIPLE_RESPONSE_STATUS_OBTAINED:	return "Response Status obatined in Multiple SM DOs";
		case ERROR_SMRESPONSE_MULTIPLE_RESPONSE_DATA_OBTAINED:	return "Response Data obtained in Multiple SM DOs";
		case ERROR_SMRESPONSE_ENCDATA_AUTH_TAG_WRONG_PARAM:	return "Incorrect Crypto Specifications/ Crypto Algorithm Not Supported for 0x87 SM Response Tag";
		case ERROR_SMRESPONSE_ENCDATA_TAG_WRONG_PARAM:	return "Incorrect Crypto Specifications/ Crypto Algorithm Not Supported for 0x86 SM Response Tag";
		case ERROR_SMRESPONSE_CRYPTODO_AUTH_TAG_WRONG_PARAM:	return "Incorrect Crypto Specifications/ Crypto Algorithm Not Supported for 0x83 SM Response Tag";
		case ERROR_SMRESPONSE_CRYPTODO_TAG_WRONG_PARAM:	return "Incorrect Crypto Specifications/ Crypto Algorithm Not Supported for 0x82 SM Response Tag";
		case ERROR_SMRESPONSE_UNEXPECTED_SMDO_OBTAINED:	return "Unexpected SM DO Found in SM Response";
		case ERROR_SMRESPONSE_NO_SMDO_CORRESPONDING_TO_DO_TAG:	return "No SM DO Found corresponding to 0xDO SM Response Tag";
		case ERROR_SMCOMMAND_CC_TAG_WRONG_PARAM:	return "Incorrect Crypto Specifications/ Crypto Algorithm Not Supported for 0x8E SM Command Tag";
		case ERROR_SMCOMMAND_ENCDATA_TAG_WRONG_PARAM:	return "Incorrect Crypto Specifications/ Crypto Algorithm Not Supported for 0x86 SM Command Tag";
		case ERROR_SMCOMMAND_ENCDATA_AUTH_TAG_WRONG_PARAM:	return "Incorrect Crypto Specifications/ Crypto Algorithm Not Supported for 0x87 SM Command Tag";
		case ERROR_SMCOMMAND_ENVELOPE_TAG_WRONG_PARAM:	return "Incorrect Crypto Specifications/ Crypto Algorithm Not Supported for 0x86 SM Command Tag";
		case ERROR_SMCOMMAND_ENVELOPE_AUTH_TAG_WRONG_PARAM:	return "Incorrect Crypto Specifications/ Crypto Algorithm Not Supported for 0x87 SM Command Tag";
		case ERROR_SMCOMMAND_CRYPTODO_TAG_WRONG_PARAM:	return "Incorrect Crypto Specifications/ Crypto Algorithm Not Supported for 0x82 SM Command Tag";
		case ERROR_SMCOMMAND_CRYPTODO_AUTH_TAG_WRONG_PARAM:	return "Incorrect Crypto Specifications/ Crypto Algorithm Not Supported for 0x83 SM Command Tag";
		case ERROR_SM_TAG_REQUIRES_ALGO_SPECS_AND_SMCONTEXT_SUBLIST:	return "SM Tag requires Crypto Algorithm Spcecifications and SM Tag Sublist";
		case ERROR_SM_TAG_REQUIRES_ALGO_SPECS:	return "SM Tag requires Crypto Algorithm Spcecifications";
		case ERROR_SM_TAG_REQUIRES_SMCONTEXT_SUBLIST:	return "SM Tag requires SM Tag Sublist";
		case ERROR_SM_TAG_REQUIRES_DATA_OBJECT:	return "SM Tag requires Data Object";
		case ERROR_INVALID_SM_TAG:	return "Invalid SM Tag Value";
		case PCSC_INVALID_VALUE:	return "PCSC Error: Invalid value given";
		case PCSC_INVALID_HANDLE:	return "PCSC Error: Invalid handle";
		case PCSC_INSUFFICIENT_BUFFER:	return "PCSC Error: Insufficient buffer";
		case PCSC_NO_READERS_AVAILABLE:	return "PCSC Error: Cannot find a smart card reader";
		case PCSC_READER_UNAVAILABLE:	return "PCSC Error: Reader is unavailable";
		case PCSC_NO_SMARTCARD_PRESENT:	return "PCSC Error: No smart card inserted";
		case PCSC_READER_NOT_READY:	return "PCSC Error: Subsystem not ready";
		case PCSC_PROTOCOL_NOT_SUPPORTED:	return "PCSC Error: Feature not supported";
		case PCSC_SHARING_VIOLATION:	return "PCSC Error: Sharing violation";
		case PCSC_TRANSMISSION_ERROR:	return "PCSC Error: Transaction failed";
		case PCSC_INVALID_PROTOCOL:	return "PCSC Error: Card protocol mismatch";
		case PCSC_SMARTCARD_RESET:	return "PCSC Error: Card was reset";
		case PCSC_NO_SERVICE:	return "PCSC Error: Service not available";
		case PCSC_NO_MEMORY:	return "PCSC Error: Not enough memory";
		case PCSC_CARD_REMOVED:	return "PCSC Error: Card was removed";
		case PCSC_UNPOWERED_CARD:	return "PCSC Error: Card is unpowered";
		case PCSC_UNRESPONSEIVE_CARD:	return "PCSC Error: Card is unresponsive";
		case PCSC_UNKNOWN_READER:	return "PCSC Error: Unknown Reader";
		case PCSC_UNKNOWN_ERROR:	return "PCSC Error: Unknown Error";
		default:	return "Unknown Error";
	}
	
}
