#pragma once

#include <map>
#include "stdafx.h"
#include "SMContext.h"
#include "crypto.h"
#include "Reader.h"

#define VALUECHUNK 16

#define LAST_TAG_NONE 	0
#define LAST_TAG_ODD 	1
#define LAST_TAG_EVEN 	2

typedef std::map<BYTE, const DO*> tag_do_map;

/** 
 * \defgroup apdu Application Protocol Data Unit(APDU)
 */

/*@{*/
class APDU;

/** 
 * \defgroup log Logging Mechanism 
 * \brief This section defines the Logging Mechanism in Command Library.
 *
 * Command Library uses a call back function of type func_callback for logging APDUs. Command Library calls the call back function at for various events during 
 * transmission of APDU.
 * 
 * The call back function takes three inputs. The first argument informs the application whether a command APDU(LOG_CMD) or a response APDU(LOG_RESP) 
 * has to be logged. The second argument informs the application about the event to be logged. 
 * The third argument of the call back function provides a constant pointer to the APDU to be logged. 
 *
 *
 */
/*@{*/
#define LOG_CMD		0	///< Log Command APDU
#define LOG_RESP	1	///< Log Response APDU

/** \name Macros for Logging Events */
/*@{*/
#define LOG_EVENT_TRANSPORT       	0	///< Transport layer apdu.
#define LOG_EVENT_TRANSMIT		1	///< Protected apdu for SM or the APDU when no SM is used.
#define LOG_EVENT_UNPROTECTED          	2	///< Unprotected APDU when SM is used.
#define LOG_EVENT_AUTOGETRESPONSE 	3	///< Auto Get Response APDU for transport layer.
/*@}*/

/** 
 * \brief Function type defined for logging function.
 */
typedef void (*func_callback)(int, int, const APDU*);
/*@}*/

/** 
 * \brief Class representing the Application protocol data unit(APDU)
 * 
 * This class defines some basic operations that can be performed on APDUs. 
 *
 * The command APDU consists of
 * 	- a mandatory header of 4 bytes (CLA INS P1 P2)
 * 	- a conditional body of variable length
 *
 * Body consists of Lc field, Data field and Le field.
 * Lc denotes the number of bytes present in the data field of command APDU
 * Le denotes the number of bytes expected in the data field of respond APDU
 *
 * The response APDU consists of
 * 	- a conditional body of variable length
 * 	- a mandatory trailer of 2 bytes( SW1 SW2 )
 *
 * SW1 and SW2 are the status bytes of the response APDU which denote the processing state in the card
 */
class APDU	{
  BYTE 	CLA;			///< Class byte of command APDU.
  BYTE 	INS;			///< Instruction byte of command APDU.
  BYTE 	P1;			///< First Parameter byte of command APDU.
  BYTE 	P2;			///< Second Parameter byte of command APDU.
  int 	Lc;			///< Length of Data field in command APDU.
  BYTE 	*data;			///< Data field of command APDU.
  int 	Le;			///< Expected length of Response.
  int 	Le_rcv;			///< Actual length of Response.
  BYTE 	*response;		///< Response corresponding to this APDU.
  BYTE 	SW1;			///< First status byte of Response APDU.
  BYTE 	SW2;			///< Second status byte of Response APDU.
  func_callback func_cb; 	///< Call back function pointer for logging the APDU.

  bool 	DoPadding(int *plen, BYTE *buffer, int blksize, int forcepad);
  void 	UndoPadding(BYTE *buffer, int *buflen) const;
  void 	UndoPaddingTLV(BYTE *buffer, int *buflen) const;
  void 	getTAPDU(DWORD protocol, BYTE *tapdu);
  int 	getTAPDUlen(DWORD protocol);

  public:
  APDU(void);
  ~APDU(void);
  APDU(const APDU& APDU_arg);
  
  APDU(BYTE CLA, BYTE INS, BYTE P1, BYTE P2, int Lc, const BYTE *Lc_buffer, int Le, func_callback func_cb = NULL);
  APDU(BYTE CLA, BYTE INS, BYTE P1, BYTE P2, int Le, func_callback func_cb = NULL);
  APDU(BYTE INS, BYTE P1, BYTE P2, int Lc, const BYTE *Lc_buffer, int Le, func_callback func_cb = NULL);
  APDU(BYTE INS, BYTE P1, BYTE P2, int Le, func_callback func_cb = NULL);

  int transmitAPDU(const Reader& reader);
  int sendAPDU(const Reader& reader, const SMContext *ctx = NULL);
  int calContext(const SMContextList *ctx, DOList& SMDO_list);
  int calResponse(const SMContextList *ctx_list, int sm_response_len, const BYTE *sm_response);

  void setCLA(BYTE CLA);
  void setINS(BYTE INS);
  void setP1(BYTE P1);
  void setP2(BYTE P2);
  int setData(int Lc, const BYTE *Lc_buffer);
  int setLe(int Le);
  void setFunc(func_callback func_cb);
  int setAPDU(BYTE CLA, BYTE INS, BYTE P1, BYTE P2, int Lc, const BYTE *Lc_buffer, int Le, func_callback func_cb);

  BYTE 	getCLA(void) const;
  BYTE 	getINS(void) const;
  BYTE 	getP1(void) const;
  BYTE 	getP2(void) const;
  int 	getLc(void) const;
  const BYTE* getData(void) const;
  int 	getLe(void) const;
  int 	getLe_rcv(void) const;
  const BYTE* getResponse(void) const;
  BYTE 	getSW1(void) const;
  BYTE 	getSW2(void) const;
  WORD 	getSW1SW2(void) const;
  func_callback getFunc_cb(void) const;
};
/*@}*/
