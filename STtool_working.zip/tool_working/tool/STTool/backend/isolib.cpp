#include <cstdio>
#include <cstdlib>
#include <string>
#include <ctime>
#ifdef WIN32
	#include <io.h>
#endif
#include <unistd.h>
#include "isolib.h"
#include "cmdlib.h"

BYTE sw1;
BYTE sw2;
BYTE outdata[MAX_BUFFER];
BYTE challenge[MAX_CHALLENGE];
UINT challengelen = 0;
UINT RespLen = 0;

char *SMsw = NULL;
CommandInfo * T_command = NULL;
APDU *apdu = NULL;
SMContext *SM = NULL;
Reader *reader = NULL;
FCP *fcp = NULL;

static WORD smsw;
static struct tm *newTime;
static time_t time_start, time_end;

static struct errordata1	{
	char sw1;
	char sw2;
	char *message;
} errortable[] = {
  {'\x90', '\x00', (char*)"Command is successful"},
  {'\x61', '\x00', (char*)"SW2 indicates the number of response bytes still left"},
  {'\x62', '\x00', (char*)"No information given"},
  {'\x62', '\x81', (char*)"Part of return data may be corrupted"},
  {'\x62', '\x82', (char*)"End of file/record reached before reading le bytes"},
  {'\x62', '\x83', (char*)"Selected file deactivated"},
  {'\x62', '\x84', (char*)"FCI not formatted according to ISO7816"},
  {'\x62', '\x85', (char*)"Selected File in Termination State"},
  {'\x62', '\x86', (char*)"No input data available from a sensor on card"},
  {'\x63', '\x00', (char*)"No information given"},
  {'\x63', '\x81', (char*)"File filled up by the last write"},
  {'\x63', '\xc0', (char*)"Counter provided by the last 4 bits"},
  {'\x64', '\x00', (char*)"Execution Error"},
  {'\x64', '\x01', (char*)"Immediate response required by the card"},
  {'\x65', '\x00', (char*)"No information given"},
  {'\x65', '\x81', (char*)"Memory failure"},
  {'\x66', '\x00', (char*)"Security related error"},
  {'\x67', '\x00', (char*)"Wrong length"},
  {'\x68', '\x00', (char*)"No information given"},
  {'\x68', '\x81', (char*)"Logical channel not supported"},
  {'\x68', '\x82', (char*)"Secure massaging not supported"},
  {'\x68', '\x83', (char*)"Last command of the chain expected"},
  {'\x68', '\x84', (char*)"Command chaining not supported"},
  {'\x69', '\x00', (char*)"No information given"},
  {'\x69', '\x81', (char*)"Command incompatible with file structure"},
  {'\x69', '\x82', (char*)"Security status not satisfied"},
  {'\x69', '\x83', (char*)"Authentication method blocked"},
  {'\x69', '\x84', (char*)"Referenced data not usable"},
  {'\x69', '\x85', (char*)"Conditions of use not satisfied"},
  {'\x69', '\x86', (char*)"Command not allowed (No current EF)"},
  {'\x69', '\x87', (char*)"Expected SM data objects missing"},
  {'\x69', '\x88', (char*)"SM data objects incorrect"},
  {'\x6a', '\x00', (char*)"No information given"},
  {'\x6a', '\x80', (char*)"Incorrect parametres in the data field"},
  {'\x6a', '\x81', (char*)"Function not supported"},
  {'\x6a', '\x82', (char*)"File/application not found"},
  {'\x6a', '\x83', (char*)"Record not found"},
  {'\x6a', '\x84', (char*)"Not enough memory space in the file"},
  {'\x6a', '\x85', (char*)"Nc inconsistent with TLV structure"},
  {'\x6a', '\x86', (char*)"Incorrect parametres P1-P2"},
  {'\x6a', '\x87', (char*)"Nc inconsistent with P1-P2"},
  {'\x6a', '\x88', (char*)"Reference data not found"},
  {'\x6a', '\x89', (char*)"File already exist"},
  {'\x6a', '\x8a', (char*)"DF name already exist"}
};

static struct errordata2	{
	char sw1;
	char *message;
} secondtable[] = {
  {'\x61', (char*)"SW2 indicates the nnumber of response bytes still left"},
  {'\x62', (char*)"State of non-volatile memory unchanged"},
  {'\x63', (char*)"Command failed. SW2 indicates number of retries."},
  {'\x64', (char*)"State of non-volatile memory unchanged"},
  {'\x65', (char*)"State of non-volatile memory changed"},
  {'\x66', (char*)"Reserved for security related issues"},
  {'\x68', (char*)"Functions with CLA not supported"},
  {'\x69', (char*)"Command not allowed"},
  {'\x6a', (char*)"Wrong parametre(s) P1-P2"},
  {'\x6b', (char*)"Wrong parametre(s) P1-P2"},
  {'\x6c', (char*)"Wrong length Le. SW2 indicates the exact length"},
  {'\x6d', (char*)"Instruction code not supported or valid"},
  {'\x6e', (char*)"Class not supported"},
  {'\x6f', (char*)"No precise diagnosis"},
  {'\x63', (char*)"State of non volatile memory changed"}
};

static void logmsg(char sw1, char sw2)	{
	int x;
	for(x=0; x<sizeof(errortable)/sizeof(errortable[0]); x++) {
		if((sw1==errortable[x].sw1)&&(sw2==errortable[x].sw2)) {
      			fprintf(stderr, "%s\n", errortable[x].message);
      			return;
    		}
  	}
  	for(x=0; x<sizeof(secondtable)/sizeof(secondtable[0]); x++) {
    		if(sw1==secondtable[x].sw1) {
      			fprintf(stderr, "%s\n", secondtable[x].message);
      			return;
    		}
  	}
  	fprintf(stderr, "Protocol error\n");
}

static void timereport(void) {
  	time(&time_end);
  	fprintf(stderr, "\nTotal time taken by the scipt: %d seconds\n", (int)(time_end-time_start));
}

static char getOptionValuePair(char *arg_i, char *arg_i_plus1, char *ret_val, char *optionList)	{
	if ((strlen(arg_i) != 2) || (arg_i[0] != '-')) return -1;
	if (strchr(optionList, arg_i[1])==NULL) return -1;
	if (arg_i_plus1 == NULL) ret_val[0] = '\0';
	else strcpy(ret_val, arg_i_plus1);
	return arg_i[1];
}

static BYTE char_to_hex(BYTE char_val)	{
  	if(char_val>='0' && char_val<='9')
    		char_val-='0';
  	else if(char_val>='a' && char_val <='f')
    		char_val = char_val - 'a'+ 10;
  	else 
    		char_val = char_val - 'A' + 10;
  	return(char_val);	
}

static void printCAPDU(const APDU *apdu)	{
  	int i = 0;
	int Lc, Le;
	const BYTE *inbuf;
  	fprintf(stderr, "CLA=0x%02X INS=0x%02X P1=0x%02X P2=0x%02X ",apdu->getCLA(), apdu->getINS(), apdu->getP1(), apdu->getP2());
	Lc = apdu->getLc();
	if(Lc == 0)	fprintf(stderr, "Lc=(EMPTY) ");
  	else	fprintf(stderr, "Lc=0x%X ", Lc);
	Le = apdu->getLe();
	if(Le == 0)	fprintf(stderr, "Le=(EMPTY)\n");
    	else	fprintf(stderr, "Le=0x%X\n", Le);
  	if(Lc > 0)	{
		inbuf = apdu->getData();
    		fprintf(stderr, "\t\tDATA(hex) = ");
		for(i=0; i<Lc; i++)	{
      			if ((i != 0) && (i %16 == 0)) fprintf(stderr,"\n\t\t\t");
      			fprintf(stderr, "%02X ",inbuf[i]);
    		}
    		fprintf(stderr, "\n");
  	}
}

static void printRAPDU(BYTE sw1, BYTE sw2, int le_rcv, const BYTE* response)	{
	int i = 0;
	fprintf(stderr, "SW1=0x%02X SW2=0x%02X\n", sw1, sw2);
	if(le_rcv > 0)	{
		fprintf(stderr, "\t\tRESP(hex) = ");
		for(i = 0; i < le_rcv; i++)	{
			if((i != 0) && (i%16 == 0))	fprintf(stderr, "\n\t\t\t");
			fprintf(stderr, "%02X ", response[i]);
		}
		fprintf(stderr, "\n");
	}
}

static void printRAPDU(const APDU *apdu)	{
	printRAPDU(apdu->getSW1(), apdu->getSW2(), apdu->getLe_rcv(), apdu->getResponse());
}

// the functon exported by backend library are defined here.
void CommandInfo::reportCommand()	{
	fprintf(stderr, "\nLine %d:\t%s\n", this->lineno, this->command);
}

void CommandInfo::log(const char *info)	{
	if(info == NULL)	return;
	fprintf(stderr, "***** FAILURE ***** User Log (line %d): %s\n", this->lineno, info);
}

void CommandInfo::setCommandInfo(unsigned int lineno, const char* command, const char* expsw)	{
	this->lineno = lineno;
	this->command = command;
	this->expsw = expsw;
}

void CommandInfo::checksw(BYTE sw1, BYTE sw2, const char* status_msg, const char* expsw)	{
	int i;
  	char u[10];
	bool T_statusflag = true;
	if(expsw == NULL)	expsw = this->expsw;

  	fprintf(stderr, "Expected (%s) status: ", status_msg);
  	if (strcmp(expsw, "????") == 0) fprintf(stderr, "OK");
  	else if (strcmp(expsw, "@@@@") == 0) fprintf(stderr, "ERROR");
  	else fprintf(stderr, "%s", expsw);
  	fprintf(stderr, "\nReceived (%s) SW1SW2 = %02x%02x ", status_msg, sw1,sw2);
  	
	if((strcmp(expsw, "????") == 0) && ((sw1 != 0x90) & (sw2 != 0x00)))	T_statusflag = false;
  	if((strcmp(expsw, "@@@@") == 0) && ((sw1 == 0x90) & (sw2 == 0x00)))	T_statusflag = false;
  	if((strcmp(expsw, "@@@@") == 0) && (sw1 == 0x61))	T_statusflag = false;
  	if(strcmp(expsw, "????") && strcmp(expsw, "@@@@") && strcmp(expsw, "****")) {
    		sprintf(u, "%02x%02x", sw1,sw2);	// A pattern is to be matched
    		for (i = 0; i<4; i++) {
      			if(expsw[i]=='*')	continue;
      			if(tolower(expsw[i]) != u[i])	{
				T_statusflag=false;
				break;
			}
    		}
  	}
	
  	logmsg(sw1, sw2);
  	if(!T_statusflag) {
    		fprintf(stderr, "***** FAILURE ***** Expected (%s) status not matched in line no. %d\n", status_msg, this->lineno);
  	}
}

void CommandInfo::checkResponse(const void *checkdata, int datalen, int isequal, int type)	{
	if(datalen <= 0)	return;		// if no expected data is provided then do nothing

	unsigned char *t=(unsigned char *)checkdata;
  	int matched = 1;
  	int len = datalen;
  	int i = 0, j = 0;
  	char *s;

  	//type is to distinguish between byte array(CVARIABLE) and string(STRING)
  	if (type == DIRECT)	{
    		s = (char *) malloc (4*len);
    		for(i=0; i<len; i++)	sprintf(s+3*i, " %02X", t[i]);
    		len = (int)strlen(s);
  	} 
	else	{
    		s = (char *)checkdata;
  	}
  	fprintf(stderr, "Expected Data");
  	if(isequal)	fprintf(stderr,"=="); 
  	else 	fprintf(stderr,"!=");
  	fprintf(stderr,"%s\n", s);

  	i=0;
  	for(j = 0; j < 2*RespLen; i++) {
    		char outdatachar;
    		if(s[i] == ' ') continue;

    		if((j % 2) ==0)	outdatachar = (outdata[j/2] >> 4);
    		else	outdatachar = outdata[j/2];

    		outdatachar &= 0x0F;
    		j = j+1;
    		if (s[i] == '*') continue;
    		if ((s[i] == '\0') || (char_to_hex(s[i]) != outdatachar)) {
      			matched = 0;
    		}
  	}
  	while(s[i]==' ') i++;
  	if (s[i] != '\0') matched = 0;
	if(type == DIRECT)	{
		free(s);
	}
  	if (matched != isequal)	{	// Must have been set by the checkresponse
		fprintf(stderr, "***** FAILURE ***** Unexpected Output in line no. %d.\n", this->lineno);
  	}
}

void logCommand(int cmdresp, int logEvent, const APDU* apdu)	{
	if((logEvent == LOG_EVENT_AUTOGETRESPONSE) && (cmdresp == LOG_CMD))	{
		fprintf(stderr, "Issuing Auto Get Response for %d bytes\n", apdu->getLe());
	}
	if(SM != NULL)	{
		if((logEvent == LOG_EVENT_UNPROTECTED) && (cmdresp == LOG_CMD))	{
			fprintf(stderr, "Command APDU: ");
			printCAPDU(apdu);
		}
		
		if((logEvent == LOG_EVENT_TRANSMIT) && (cmdresp == LOG_CMD))	{
			fprintf(stderr, "Creating SM Command APDU\n");
			fprintf(stderr, "Command tAPDU(with SM): ");
			printCAPDU(apdu);
		}

		if((logEvent == LOG_EVENT_TRANSMIT) && (cmdresp == LOG_RESP))	{
			fprintf(stderr, "Response tAPDU(with SM): ");
			printRAPDU(apdu);
			T_command->checksw(apdu->getSW1(), apdu->getSW2(), (char*)"unprotected", SMsw);
			smsw = apdu->getSW1SW2();
			if(strcmp(SMsw, "****") != 0)	{
				if((smsw != 0x9000) && (smsw != 0x6987) && (smsw != 0x6988))	{
					fprintf(stderr, "***** FAILURE ***** SM based status is something other than 0x9000, 0x6988 and 0x6987\n");
				}
			}
		}
		
		if((logEvent == LOG_EVENT_UNPROTECTED) && (cmdresp == LOG_RESP))	{
			if((strcmp(SMsw, "****") != 0) && (smsw != 0x9000))	return; 

			fprintf(stderr, "Response (after SM Processing): ");
			printRAPDU(apdu);
			T_command->checksw(apdu->getSW1(), apdu->getSW2(), (char*)"protected");
			if(strcmp(SMsw, "****") == 0)	{
				if (apdu->getSW1SW2() != smsw)
					fprintf(stderr,"***** FAILURE ***** SM response is not identical to command response\n");
			}
			sw1 = apdu->getSW1();
			sw2 = apdu->getSW2();
			if(apdu->getLe_rcv() > 0)	{
				RespLen = apdu->getLe_rcv();
				memcpy(outdata, apdu->getResponse(), RespLen);
			}
		}
	}
	else	{
		if((logEvent == LOG_EVENT_TRANSMIT) && (cmdresp == LOG_CMD))	{
			fprintf(stderr, "Command APDU: ");
			printCAPDU(apdu);
		}

		if((logEvent == LOG_EVENT_TRANSMIT) && (cmdresp == LOG_RESP))	{
			sw1 = apdu->getSW1();
			sw2 = apdu->getSW2();
			if(apdu->getLe_rcv() > 0)	{
				RespLen = apdu->getLe_rcv();
				memcpy(outdata, apdu->getResponse(), RespLen);
			}
			// if response status is 0x61xx then issue Auto Get Response
			while(sw1 == 0x61)	{
				APDU m(0x00, INS_CMD_GET_RESPONSE, 0, 0, 0, NULL, sw2, logCommand);
				fprintf(stderr, "Issuing Auto Get Response for %d bytes\n", m.getLe());
				process_return_code(m.transmitAPDU(*reader));

				sw1 = m.getSW1();
				sw2 = m.getSW2();
				if(m.getLe_rcv() > 0)	{
					memcpy(outdata + RespLen, m.getResponse(), m.getLe_rcv());
					RespLen = m.getLe_rcv();
				}
			}
			printRAPDU(sw1, sw2, RespLen, outdata);
			T_command->checksw(sw1, sw2, (char*)"response");
		}
	}
}

void process_return_code(int return_code)	{
	if(return_code != NOERROR)	{
		switch(return_code)	{
			case ERROR_SMRESPONSE_INCORRECT_SMDO_OBTAINED:
			case ERROR_SMRESPONSE_DUPLICATE_SMDOS_OBTAINED:
			case ERROR_SMRESPONSE_INCORRECT_CC_SMDO_OBTAINED:
			case ERROR_SMRESPONSE_INCORRECT_STATUS_SMDO_OBTAINED:
			case ERROR_SMRESPONSE_CC_VERIFICATION_FAILED:
			case ERROR_SMRESPONSE_MULTIPLE_RESPONSE_STATUS_OBTAINED:
			case ERROR_SMRESPONSE_MULTIPLE_RESPONSE_DATA_OBTAINED:
				fprintf(stderr, "***** FAILURE ***** %s.\n", cmdlib_stringify_error(return_code));
				break;
			default:
				free_variables();
				fprintf(stderr, "ERROR: %s.\n", cmdlib_stringify_error(return_code));
			  	fprintf(stderr, "Aborting script execution.\n");
			    	exit(return_code);
		}
	}
}

void T_log(char* info)	{
	T_command->log(info);
}

void T_abort(FILE *f)	{
	free_variables();
  	fprintf(f, "Aborting script execution.\n");
    	exit(1);
}

void initialize(int argc, char *argv[])	{
#ifdef WIN32
	#define close _close
	#define dup _dup
#endif
  	FILE *err_file=NULL;
	long rv;
  	int i, reader_num, numReaders = 0;
  	unsigned int protocol=-1;
	unsigned long proto;
  	char temp[100];
	const LPTSTR * readerList;
	LPTSTR reader_name = NULL;
  	DWORD atr_len;
	LPBYTE atr;
	
	try	{
		T_command = new CommandInfo();
	}
	catch(bad_alloc &)	{
		process_return_code(ERROR_DYNAMIC_MEMORY_ALLOCATION);
	}

  	i = 1; rv = 0;
  	while ((i < argc-1) && (rv == 0)) {
    		switch(getOptionValuePair(argv[i], argv[i+1], temp, (char *)"epr")) {
		case 'e':
       			if (err_file != NULL) {
       				rv = 1; // Go out to print Usage
	        	} 
			else {
       		  		err_file=fopen(temp, "w");
       				if(err_file==NULL) {
       					fprintf(stderr,"Unable to open %s\n", temp);
          			}
       			}	
       			break;
      		case 'p':
       			if (protocol != -1) rv = 1; // Go out to print usage
        		else if(strcmp(temp, "T0")==0) 		{protocol=1; proto=SCARD_PROTOCOL_T0;}
       			else if(strcmp(temp, "T1")==0) 		{protocol=2; proto=SCARD_PROTOCOL_T1;}
        		else if(strcmp(temp, "T0T1")==0) 	{protocol=3; proto=(SCARD_PROTOCOL_T0|SCARD_PROTOCOL_T1);}
	        	else if(strcmp(temp, "RAW")==0) 	{protocol=4; proto=SCARD_PROTOCOL_RAW;}
       			else if(strcmp(temp, "T0RAW")==0)	{protocol=5; proto=(SCARD_PROTOCOL_T0 | SCARD_PROTOCOL_RAW);}
       			else if(strcmp(temp, "T1RAW")==0)	{protocol=6; proto=(SCARD_PROTOCOL_T1 | SCARD_PROTOCOL_RAW);}
		        else if(strcmp(temp, "ANY")==0)		{protocol=7; proto=(SCARD_PROTOCOL_T0 | SCARD_PROTOCOL_T1 | SCARD_PROTOCOL_RAW);}
		        else fprintf(stderr, "Unknown Protocol: %s\n", temp);
			break;
	      	case 'r':
       			if (reader_name != NULL) rv = 1; // Print usage
        		else {
				reader_name = (char *)malloc(strlen(temp)+2);
				strcpy(reader_name, temp);
	        	}
       			break;
		default:
       			rv = 1; break;
		}
    	i = i+2;
  	}

  	if ((rv == 1) || (i != argc)) {
	    	fprintf(stderr, "Usage: ./Testtool [-e <error_file>] [-p T0|T1|RAW|T0T1|T0RAW|T1RAW|ANY] [-r <Reader Name>]\n");
    		exit(1);
  	}
  	if(err_file!=NULL) {
	    	int fd=fileno(err_file);
		close(2);
    		dup(fd);
		close(fd);
	}
  	while((protocol<=0) || (protocol > 7)){
    		fprintf(stdout, "Choose one of these protocols to use:\n");
	    	fprintf(stdout, "  1 for 'T0'\n");
    		fprintf(stdout, "  2 for 'T1'\n");
	    	fprintf(stdout, "  3 for 'T0' or 'T1'\n");
    		fprintf(stdout, "  4 for 'RAW'\n");
	    	fprintf(stdout, "  5 for 'T0' or 'RAW'\n");
    		fprintf(stdout, "  6 for 'T1' or 'RAW'\n");
	    	fprintf(stdout, "  7 for 'T0', 'T1' or 'RAW'\n");
    		if (fscanf(stdin, "%d", &protocol)!= 1) {
      			while (getchar()!= '\n');
      			protocol = -1;
    		}
  	}
  	switch(protocol){
    	case 1:
      		proto=SCARD_PROTOCOL_T0;
      		break;
    	case 2:
      		proto=SCARD_PROTOCOL_T1;
      		break;
    	case 3:	
      		proto=(SCARD_PROTOCOL_T0|SCARD_PROTOCOL_T1);
      		break;
    	case 4:	
      		proto=(SCARD_PROTOCOL_RAW); 
      		break;
    	case 5:	
      		proto=(SCARD_PROTOCOL_T0|SCARD_PROTOCOL_RAW);
      		break;
    	case 6:	
      		proto=(SCARD_PROTOCOL_T1|SCARD_PROTOCOL_RAW);
      		break;
    	case 7:	
      		proto=(SCARD_PROTOCOL_T0|SCARD_PROTOCOL_T1|SCARD_PROTOCOL_RAW);
      		break;
  	}

	// creating a reader object to initialize the static members of the Reader class.
	reader = new Reader();
	numReaders = reader->getNumReader();
	if(numReaders == 0)	{
		fprintf(stderr, "ERROR: No Readers connected.\n");
		exit(1);
	}

	readerList = reader->ListReaders();
  	if(reader_name==NULL){
		printf("Choose one of the following readers to use by typing in the corresponding number:\n");
		for(i=0; i<numReaders; i++)	{
			printf("%d %s\n", i, readerList[i]);
		}
    		while((scanf("%d", &i) != 1) || i<0 || i>=numReaders) {
      			while (getchar() != '\n');
      			fprintf(stderr, "Please enter a number between 0 and %d to choose a reader\n", numReaders-1);
    		}
		reader_num = i;
		reader_name = readerList[reader_num];
  	} else	{
		for(i=0; i<numReaders; i++)	{
			if(strcmp(readerList[i], reader_name) == 0)	{
				reader_num = i;
				break;
			}
		}
		if(i >= numReaders)	{
			fprintf(stderr, "ERROR: No reader with name %s found.\n", reader_name);
			exit(1);
		}
	}
	process_return_code(reader->connectReader(reader_name, SCARD_SHARE_SHARED, proto));
 	
	// logging ATR
	atr = (BYTE*) malloc(35);
	atr_len = 35;
	process_return_code(reader->getATR(atr, atr_len));
	if (atr == NULL) {
		fprintf(stderr, "***** FAILURE ***** Error while reading ATR.\n");
    		exit(1);
  	}
  	fprintf(stderr,"ATR: ");
  	for(i =0; i < (int)atr_len; i++)
    		fprintf(stderr, "%02X ",atr[i]);
	
	// logging Protocol
	switch(dwProtocol)	{
		case SCARD_PROTOCOL_T0:
			{
				fprintf(stderr, "   T0 Protocol\n");
				break;
			}
		case SCARD_PROTOCOL_T1:
			{
				fprintf(stderr, "   T1 Protocol\n");
				break;
			}
		case SCARD_PROTOCOL_RAW:
			{
				fprintf(stderr, "   RAW Protocol\n");
				break;
			}
		default:
			{
				fprintf(stderr, "   Unknown Protocol\n");
				break;
			}
	}
	
	// setting the function to log the script end time when the script ends normally
  	atexit(timereport);

  	// Get start time in seconds
  	time(&time_start);
  	fprintf(stderr, "Log start time: %s\n", asctime(localtime( &time_start )));
}

void reset(void)	{
	process_return_code(reader->reconnectReader(SCARD_SHARE_SHARED, reader->getReaderProtocol(), SCARD_RESET_CARD));
}

void freeSMContextList(SMContextList *ctx)	{
	for(SMContextList::iterator p = ctx->begin(); p != ctx->end(); p++)	{
		SMContextEntry *smEntry = (*p);	
		if(smEntry->algo != NULL)	delete smEntry->algo;
		if(smEntry->contextList != NULL)	{
			freeSMContextList((SMContextList *) smEntry->contextList);
			delete smEntry->contextList;
		}
		if(smEntry->generic_do != NULL)	delete smEntry->generic_do;
		delete smEntry;
	}
}

void freeSMContext(SMContext *sm_context)	{
	freeSMContextList(&(sm_context->SMCommandList));
	freeSMContextList(&(sm_context->SMResponseList));
}

void free_variables()	{
 	if(fcp != NULL)	{
		delete fcp;
		fcp = NULL;
	}
	if(apdu != NULL)	{
		delete apdu;
		apdu = NULL;
	}
	if(SM != NULL)	{
		freeSMContext(SM);
		delete SM;
		SM = NULL;
	}
	if(T_command != NULL)	{
		delete T_command;
		T_command = NULL;
	}
	if(reader != NULL)	{
		reader->disconnectReader();
		delete reader;
		reader = NULL;
	}
}
