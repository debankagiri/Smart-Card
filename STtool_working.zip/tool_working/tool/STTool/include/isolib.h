#ifndef _ISOLIB_H 
#define _ISOLIB_H 0

#include "cmdlib.h"

/*
These things are not required if the script files are changed.
These are just included for backward comaptibality
The required changes are:
1) use BYTE for ubyte
2) use WORD for ubyte2
3) use UINT for ubyte4
4) use CC_COMPUTE for COMPUTE
5) use CC_VERFIY for VERIFY
6) use HASH_COMPUTE for HASH
7) CryptoFunc now take strings const BYTE * so typecast then to BYTE*
8) outdata & challenege are of arrays of BYTE
*/
#include "arch.h"
#define COMPUTE CC_COMPUTE
#define VERIFY CC_VERIFY
#define HASH HASH_COMPUTE

#define MAX_BUFFER	2000
#define MAX_CHALLENGE 	300
#define TRUE 		1
#define FALSE 		0
#define WARN 		0
#define ABORT 		1
#define DIRECT 		0
#define INDIRECT 	1
#define EQUAL 		1
#define NOTEQUAL 	0

// wrapper macros
#define dwProtocol (reader->getReaderProtocol())

class CommandInfo	{
	private:
		unsigned int lineno;
		const char* command;
		const char* expsw;

	public:
		void reportCommand();
		void log(const char *info);
		void setCommandInfo(unsigned int lineno, const char* command, const char* expsw);
		void checksw(BYTE sw1, BYTE sw2, const char* status_msg, const char* expsw = NULL);
		void checkResponse(const void *checkdata, int datalen, int isequal, int type);
};

void logCommand(int cmdresp, int logEvent, const APDU* apdu);
void process_return_code(int return_code);
void T_log(char *info);
void T_abort(FILE *f);
void initialize(int argc, char *argv[]);
void reset(void);
void free_variables();
void freeSMContextList(SMContextList *ctx);
void freeSMContext(SMContext* sm);
#endif
