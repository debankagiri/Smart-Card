#ifndef _ARCH_H
#define _ARCH_H 

#define _YYERROR 1
typedef  unsigned char ubyte;
typedef  unsigned short ubyte2;
typedef  unsigned int ubyte4;
typedef  char sbyte;
typedef  short byte2;
typedef  int byte4;

#endif
