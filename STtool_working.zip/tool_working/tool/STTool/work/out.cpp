#include <cstdio>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <winscard.h>
#include <cstring>
#include <cstdlib>
#include "isolib.h"
#include "cmdlib.h"
#include "header.h"

/* Global Variables */
extern BYTE sw1;
extern BYTE sw2;
extern BYTE outdata[MAX_BUFFER];
extern UINT RespLen;
extern BYTE challenge[MAX_CHALLENGE];
extern UINT challengelen;

extern char *SMsw;
extern CommandInfo *T_command;
extern Reader *reader;
extern APDU *apdu;
extern SMContext *SM;
extern FCP *fcp;
BYTE T_error_behavior;
SMContextList *contextList = NULL;
SMContextList *newContextList = NULL;
SMContextList *tempContextList = NULL;
const BYTE* sm_do_str = NULL;
int sm_do_len = 0;
int offset = 0;
char *script_file = (char*)"./Common_Scripts/capacity";

int main(int argc, char *argv[]) {

#line 1 "./Common_Scripts/capacity"
	try	{
#line 1 "./Common_Scripts/capacity"
	initialize(argc, argv);
#line 1 "./Common_Scripts/capacity"
	fprintf(stderr, "\nTesting Script %s\n", script_file);

#line 2 "./Common_Scripts/capacity"
	T_command->setCommandInfo(2, " SF MF FIRST SW?=ANY", "****");
#line 2 "./Common_Scripts/capacity"
	apdu = new SelectFileAPDU(SEL_ANY, FILEOP_FIRST_OCC | FILEOP_NO_RESPONSE, 0x3f00, 0, logCommand);
#line 2 "./Common_Scripts/capacity"
	RespLen = 0;
#line 2 "./Common_Scripts/capacity"
	T_command->reportCommand();
#line 2 "./Common_Scripts/capacity"
	process_return_code(apdu->sendAPDU(*reader, SM));
#line 2 "./Common_Scripts/capacity"
	if(apdu != NULL)	{
#line 2 "./Common_Scripts/capacity"
		delete apdu;
#line 2 "./Common_Scripts/capacity"
		apdu = NULL;
#line 2 "./Common_Scripts/capacity"
	}

#line 3 "./Common_Scripts/capacity"

#line 4 "./Common_Scripts/capacity"
   if ((sw1<<8 | (sw2 & 0xFF)) != 0x9000) {
#line 5 "./Common_Scripts/capacity"

#line 5 "./Common_Scripts/capacity"
#line 6 "./Common_Scripts/capacity"
	T_command->setCommandInfo(6, "     CREATEFILE FILEID=0x3F00 DF ", "????");
#line 6 "./Common_Scripts/capacity"
	fcp = new FCP(0x3F00);
#line 6 "./Common_Scripts/capacity"
	process_return_code(fcp->setFD(FDB_DF));
#line 6 "./Common_Scripts/capacity"
	apdu = new CreateFileAPDU(fcp, logCommand);
#line 6 "./Common_Scripts/capacity"
	delete fcp;
#line 6 "./Common_Scripts/capacity"
	fcp = NULL;
#line 6 "./Common_Scripts/capacity"
	RespLen = 0;
#line 6 "./Common_Scripts/capacity"
	T_command->reportCommand();
#line 6 "./Common_Scripts/capacity"
	process_return_code(apdu->sendAPDU(*reader, SM));
#line 6 "./Common_Scripts/capacity"
	if(apdu != NULL)	{
#line 6 "./Common_Scripts/capacity"
		delete apdu;
#line 6 "./Common_Scripts/capacity"
		apdu = NULL;
#line 6 "./Common_Scripts/capacity"
	}
#line 7 "./Common_Scripts/capacity"
	T_command->setCommandInfo(7, "     SF MF FIRST", "????");
#line 7 "./Common_Scripts/capacity"
	apdu = new SelectFileAPDU(SEL_ANY, FILEOP_FIRST_OCC | FILEOP_NO_RESPONSE, 0x3f00, 0, logCommand);
#line 7 "./Common_Scripts/capacity"
	RespLen = 0;
#line 7 "./Common_Scripts/capacity"
	T_command->reportCommand();
#line 7 "./Common_Scripts/capacity"
	process_return_code(apdu->sendAPDU(*reader, SM));
#line 7 "./Common_Scripts/capacity"
	if(apdu != NULL)	{
#line 7 "./Common_Scripts/capacity"
		delete apdu;
#line 7 "./Common_Scripts/capacity"
		apdu = NULL;
#line 7 "./Common_Scripts/capacity"
	}

#line 8 "./Common_Scripts/capacity"

#line 9 "./Common_Scripts/capacity"
   }
#line 10 "./Common_Scripts/capacity"

#line 10 "./Common_Scripts/capacity"

#line 12 "./Common_Scripts/capacity"

#line 13 "./Common_Scripts/capacity"
/* Algorithm: Create as many files as possible with 4096 bytes in size.
#line 14 "./Common_Scripts/capacity"
   Then create a file with 2048 bytes in size.
#line 15 "./Common_Scripts/capacity"
   Then create a file with 1024, 512, 256, 128, 64. Note down the card size each time the command
#line 16 "./Common_Scripts/capacity"
   is successful. */
#line 17 "./Common_Scripts/capacity"
   {
#line 18 "./Common_Scripts/capacity"
      int capacity = 0;
#line 19 "./Common_Scripts/capacity"
      int fsize = 4096; // Start with 4096 bytes.
#line 20 "./Common_Scripts/capacity"
      int ret;
#line 21 "./Common_Scripts/capacity"
      unsigned short fid=0x3f01;
#line 22 "./Common_Scripts/capacity"
      do {
#line 23 "./Common_Scripts/capacity"

#line 23 "./Common_Scripts/capacity"
#line 24 "./Common_Scripts/capacity"
	T_command->setCommandInfo(24, "              CREATEFILE FILEID=fid WORKING TRANSPARENT FILESIZE=fsize SW?=ANY", "****");
#line 24 "./Common_Scripts/capacity"
	fcp = new FCP(fid);
#line 24 "./Common_Scripts/capacity"
	process_return_code(fcp->setFD(FDB_WORKING_EF | FDB_TRANSPARENT));
#line 24 "./Common_Scripts/capacity"
	process_return_code(fcp->setFileSize(fsize));
#line 24 "./Common_Scripts/capacity"
	apdu = new CreateFileAPDU(fcp, logCommand);
#line 24 "./Common_Scripts/capacity"
	delete fcp;
#line 24 "./Common_Scripts/capacity"
	fcp = NULL;
#line 24 "./Common_Scripts/capacity"
	RespLen = 0;
#line 24 "./Common_Scripts/capacity"
	T_command->reportCommand();
#line 24 "./Common_Scripts/capacity"
	process_return_code(apdu->sendAPDU(*reader, SM));
#line 24 "./Common_Scripts/capacity"
	if(apdu != NULL)	{
#line 24 "./Common_Scripts/capacity"
		delete apdu;
#line 24 "./Common_Scripts/capacity"
		apdu = NULL;
#line 24 "./Common_Scripts/capacity"
	}

#line 25 "./Common_Scripts/capacity"

#line 26 "./Common_Scripts/capacity"
	  ret = (sw1 << 8) | (sw2 & 0xFF);
#line 27 "./Common_Scripts/capacity"
          if (ret == 0x9000) capacity += fsize;
#line 28 "./Common_Scripts/capacity"
	  else fsize = fsize / 2;
#line 29 "./Common_Scripts/capacity"
	  fid = fid + 1;
#line 30 "./Common_Scripts/capacity"
      } while (fsize >= 64);
#line 31 "./Common_Scripts/capacity"
      fprintf(stderr, "Card Capacity found: %d Bytes\n", capacity);
#line 32 "./Common_Scripts/capacity"
   }
#line 33 "./Common_Scripts/capacity"

#line 33 "./Common_Scripts/capacity"
#line 34 "./Common_Scripts/capacity"
	} catch(int exp){
#line 34 "./Common_Scripts/capacity"
		process_return_code(exp);
#line 34 "./Common_Scripts/capacity"
	}
#line 34 "./Common_Scripts/capacity"
	catch(bad_alloc &){
#line 34 "./Common_Scripts/capacity"
		process_return_code(ERROR_DYNAMIC_MEMORY_ALLOCATION);
#line 34 "./Common_Scripts/capacity"
	}
#line 34 "./Common_Scripts/capacity"
free_variables();
}
