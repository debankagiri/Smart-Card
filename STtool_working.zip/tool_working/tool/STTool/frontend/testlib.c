#include "testtool.h"
#include "testtool_y.h" 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

extern FILE *yyout,*yyin;
extern char *header;
extern unsigned int lineno;
extern char command[];
extern char *script_file;

void f_print_line_info(void)	{
	fprintf(yyout, "#line %d \"%s\"\n", lineno, script_file);
}

void f_exception_handle_begin()	{
	f_print_line_info();
	fprintf(yyout, "\ttry\t{\n");	
}

void f_exception_handle_end()	{
	f_print_line_info();
	fprintf(yyout, "\t} catch(int exp){\n");
	f_print_line_info();
	fprintf(yyout, "\t\tprocess_return_code(exp);\n");	
	f_print_line_info();
	fprintf(yyout, "\t}\n");
	
	f_print_line_info();
	fprintf(yyout, "\tcatch(bad_alloc &){\n");
	f_print_line_info();
	fprintf(yyout, "\t\tprocess_return_code(ERROR_DYNAMIC_MEMORY_ALLOCATION);\n");	
	f_print_line_info();
	fprintf(yyout, "\t}\n");
}

void f_print_command_head(char *sw)	{
	int i;
	f_print_line_info();
	fprintf(yyout, "\tT_command->setCommandInfo(%d, \"", lineno);
	
	for(i=0; command[i]!= '\0'; i++)	{
		if((command[i] == '\"') || (command[i] == '\\'))	fprintf(yyout, "\\");
		fprintf(yyout, "%c", command[i]);
	}
	fprintf(yyout, "\", \"%s\");\n", sw);
}

void f_print_command_tail()	{
	f_print_line_info();
	fprintf(yyout, "\tRespLen = 0;\n");
	f_print_line_info();
	fprintf(yyout, "\tT_command->reportCommand();\n");
	f_print_line_info();
	fprintf(yyout, "\tprocess_return_code(apdu->sendAPDU(*reader, SM));\n");
	f_print_line_info();
	fprintf(yyout, "\tif(apdu != NULL)\t{\n");
	f_print_line_info();
	fprintf(yyout, "\t\tdelete apdu;\n");
	f_print_line_info();
	fprintf(yyout, "\t\tapdu = NULL;\n");
	f_print_line_info();
	fprintf(yyout, "\t}\n");
}

void f_print_expected_length(struct intvalue_s *numbytes, struct expectedvalue_s *exp_val)	{
	f_print_line_info();
	fprintf(yyout, "\toffset = ");
	f_print_intvalue(numbytes);
	fprintf(yyout, ";\n");

	if(exp_val != NULL)	{
		f_print_line_info();
		fprintf(yyout, "\tif(offset == 0)\toffset = ");
		f_print_intvalue(&(exp_val->strval.length));
		fprintf(yyout, ";\n");
	}
}

void f_print_check_expected_response(struct expectedvalue_s *exp_val)	{
	if(exp_val != NULL)	{
		f_print_line_info();
		fprintf(yyout, "\tT_command->checkResponse(");
		f_print_stringvalue(&(exp_val->strval));
		fprintf(yyout, ", ");
		f_print_intvalue(&(exp_val->strval.length));
		fprintf(yyout, ", %s", exp_val->is_equal?"EQUAL":"NOTEQUAL");
		fprintf(yyout, ", %s", exp_val->is_cstring? "DIRECT":"INDIRECT");
		fprintf(yyout,");\n");
	}
}

void print_data(struct stringvalue_s *data)	{
	if(data == NULL)	fprintf(yyout, "0, NULL");
	else	{
		f_print_hexvalue(&(data->length));
		fprintf(yyout, ", ");
		fprintf(yyout, "(BYTE*)");
		f_print_stringvalue(data);
	}
}

// prints the inner tag list for the recursive tags
void print_SMList(struct taglist_s *list)
{
	int i;
	int first = 0;
	// adding SMContextTags in the newly created list. 
	// here we do not have to check whether the tags are correct or not.
	// All the checks have already been performed while creating the SMTag lists.
	
	// first print all the recursive sub tags
	for(i=0; i<list->num_tags; i++)	{
		ubyte tag_no = list->tags[i].tag_no;
		if((tag_no == 0x82) || (tag_no == 0x83) || (tag_no == 0xB0) || (tag_no == 0xB1))	{
			if(first == 0)	{
				first = 1;
				print_SMList(list->tags[i].sublist);

				f_print_line_info();
				fprintf(yyout, "\tnewContextList = contextList;\n");

				f_print_line_info();
				fprintf(yyout, "\tcontextList = new SMContextList();\n");
			}
			else	{
				f_print_line_info();
				fprintf(yyout, "\tnewContextList = contextList;\n");

				print_SMList(list->tags[i].sublist);

				f_print_line_info();
				fprintf(yyout, "\ttempContextList = newContextList;\n");
				
				f_print_line_info();
				fprintf(yyout, "\tnewContextList = contextList;\n");
				
				f_print_line_info();
				fprintf(yyout, "\tcontextList = tempContextList;\n");
			}
		
			f_print_line_info();
			fprintf(yyout, "\tcontextList->push_back(SMContextEntry_");
			switch(tag_no)	{
				case 0xB0:
					fprintf(yyout, "PLAINDO(newContextList));\n");
					break;
				case 0xB1:
					fprintf(yyout, "PLAINDO_AUTH(newContextList));\n");
					break;
				case 0x82:
					fprintf(yyout, "CRYPTODO(");
					f_print_cryptospec(&(list->tags[i].crypto));
					fprintf(yyout, ", newContextList));\n");	
					break;
				case 0x83:
					fprintf(yyout, "CRYPTODO_AUTH(");
					f_print_cryptospec(&(list->tags[i].crypto));
					fprintf(yyout, ", newContextList));\n");	
					break;
			}
		}
	}

	for(i=0; i<list->num_tags; i++)	{
		ubyte tag_no = list->tags[i].tag_no;
		if(tag_no == 0x80 || tag_no == 0x81 || tag_no == 0x96 || tag_no == 0x97 || tag_no == 0x89 || tag_no == 0x99 || tag_no == 0x0C)	{
			if(first == 0)	{
				first = 1;
				f_print_line_info();
				fprintf(yyout, "\tcontextList = new SMContextList();\n");
			}
			
			f_print_line_info();
			fprintf(yyout, "\tcontextList->push_back(SMContextEntry_");
			switch(tag_no)	{
				case 0x80:
					fprintf(yyout, "DATA");
					break;
				case 0x81:
					fprintf(yyout, "DATA_AUTH");
					break;
				case 0x96:
					fprintf(yyout, "LE");
					break;
				case 0x97:
					fprintf(yyout, "LE_AUTH");
					break;
				case 0x89:
					fprintf(yyout, "CH_AUTH");
					break;
				case 0x99:
					fprintf(yyout, "STATUS");
					break;
				case 0x0C:
					fprintf(yyout, "CHINCLUDE");
					break;
			}
			fprintf(yyout, "());\n");	
		}
		if(tag_no == 0x86 || tag_no == 0x87 || tag_no == 0x8E)	{
			if(first == 0)	{
				first = 1;
				f_print_line_info();
				fprintf(yyout, "\tcontextList = new SMContextList();\n");
			}

			f_print_line_info();
			fprintf(yyout, "\tcontextList->push_back(SMContextEntry_");
			switch(tag_no)	{
				case 0x86:
					fprintf(yyout, "ENCDATA");
					break;
				case 0x87:
					fprintf(yyout, "ENCDATA_AUTH");
					break;
				case 0x8E:
					fprintf(yyout, "CC");
					break;
			}
			fprintf(yyout, "(");
			f_print_cryptospec(&(list->tags[i].crypto));
			fprintf(yyout, "));\n");	
		}
		if(tag_no == 0xd0)	{
			if(first == 0)	{
				first = 1;
				f_print_line_info();
				fprintf(yyout, "\tcontextList = new SMContextList();\n");
			}
			
			f_print_line_info();
			fprintf(yyout, "\toffset = 0;\n");
			
			f_print_line_info();
			fprintf(yyout, "\tsm_do_str = (const BYTE*)");
			f_print_stringvalue(&(list->tags[i].crypto.key));
			fprintf(yyout, ";\n");
			
			f_print_line_info();
			fprintf(yyout, "\twhile(offset < ");
			f_print_intvalue(&(list->tags[i].crypto.key.length));
			fprintf(yyout, ")\t{\n");
			
			f_print_line_info();
			fprintf(yyout, "\t\tDO *sm_do = new DO(sm_do_str + offset);\n");

			f_print_line_info();
			fprintf(yyout, "\t\tcontextList->push_back(SMContextEntry_DO(sm_do));\n");

			f_print_line_info();
			fprintf(yyout, "\t\toffset += sm_do->getTotalLength();\n");

			f_print_line_info();
			fprintf(yyout, "\t}\n");
		}
	}
}

// prints the SM Command tag list
void f_print_SMCommandTagList(struct taglist_s *list)	{
	int i;
	for(i=0; i<list->num_tags; i++)	{
		ubyte tag_no = list->tags[i].tag_no;
		if(tag_no == 0x80 || tag_no == 0x81 || tag_no == 0x96 || tag_no == 0x97 
			|| tag_no == 0x89 || tag_no == 0x0C)	{
				f_print_line_info();
				fprintf(yyout, "\tSM->SMCommandList.push_back(SMContextEntry_");
				switch(tag_no)	{
					case 0x80:
						fprintf(yyout, "DATA");
						break;
					case 0x81:
						fprintf(yyout, "DATA_AUTH");
						break;
					case 0x89:
						fprintf(yyout, "CH_AUTH");
						break;
					case 0x96:
						fprintf(yyout, "LE");
						break;
					case 0x97:
						fprintf(yyout, "LE_AUTH");
						break;
					case 0x99:
						fprintf(yyout, "STATUS");
						break;
					case 0x0C:
						fprintf(yyout, "CHINCLUDE");
						break;
				}
				fprintf(yyout, "());\n");	
		}
		if(tag_no == 0xB0 || tag_no == 0xB1)	{
			// recursive tags: first print set the innner tag list
			print_SMList(list->tags[i].sublist);

			f_print_line_info();
			fprintf(yyout, "\tSM->SMCommandList.push_back(SMContextEntry_");
			switch(tag_no)	{
				case 0xB0:
					fprintf(yyout, "PLAINDO");
					break;
				case 0xB1:
					fprintf(yyout, "PLAINDO_AUTH");
					break;
			}
			fprintf(yyout, "(contextList));\n");	
		}	
		if(tag_no == 0x82 || tag_no == 0x83)	{	
			// recursive tags: first print set the innner tag list
			print_SMList(list->tags[i].sublist);

			f_print_line_info();
			fprintf(yyout, "\tSM->SMCommandList.push_back(SMContextEntry_");
			switch(tag_no)	{
				case 0x82:
					fprintf(yyout, "CRYPTODO");
					break;
				case 0x83:
					fprintf(yyout, "CRYPTODO_AUTH");
					break;
			}
			fprintf(yyout, "(");
			f_print_cryptospec(&(list->tags[i].crypto));
			fprintf(yyout, ", contextList));\n");	
		}
		if(tag_no == 0x86 || tag_no == 0x87 || tag_no == 0x8E)	{
			f_print_line_info();
			fprintf(yyout, "\tSM->SMCommandList.push_back(SMContextEntry_");
			switch(tag_no)	{
				case 0x86:
					fprintf(yyout, "ENCDATA");
					break;
				case 0x87:
					fprintf(yyout, "ENCDATA_AUTH");
					break;
				case 0x8E:
					fprintf(yyout, "CC");
					break;
			}
			fprintf(yyout, "(");
			f_print_cryptospec(&(list->tags[i].crypto));
			fprintf(yyout, "));\n");	
		}
		if(tag_no == 0xd0)	{
			f_print_line_info();
			fprintf(yyout, "\toffset = 0;\n");
			
			f_print_line_info();
			fprintf(yyout, "\tsm_do_str = (const BYTE*)");
			f_print_stringvalue(&(list->tags[i].crypto.key));
			fprintf(yyout, ";\n");
			
			f_print_line_info();
			fprintf(yyout, "\twhile(offset < ");
			f_print_intvalue(&(list->tags[i].crypto.key.length));
			fprintf(yyout, ")\t{\n");
			
			f_print_line_info();
			fprintf(yyout, "\t\tDO *sm_do = new DO(sm_do_str + offset);\n");

			f_print_line_info();
			fprintf(yyout, "\t\tSM->SMCommandList.push_back(SMContextEntry_DO(sm_do));\n");

			f_print_line_info();
			fprintf(yyout, "\t\toffset += sm_do->getTotalLength();\n");

			f_print_line_info();
			fprintf(yyout, "\t}\n");
		}
	}
}

// prints the SM Response tag list
void f_print_SMResponseTagList(struct taglist_s *list)	{
	int i;
	for(i=0; i<list->num_tags; i++)	{
		ubyte tag_no = list->tags[i].tag_no;
		if(tag_no == 0x80 || tag_no == 0x81 || tag_no == 0x99)	{
				f_print_line_info();
				fprintf(yyout, "\tSM->SMResponseList.push_back(SMContextEntry_");
				switch(tag_no)	{
					case 0x80:
						fprintf(yyout, "DATA");
						break;
					case 0x81:
						fprintf(yyout, "DATA_AUTH");
						break;
					case 0x99:
						fprintf(yyout, "STATUS");
						break;
				}
				fprintf(yyout, "());\n");	
		}
		if(tag_no == 0xB0 || tag_no == 0xB1)	{
			print_SMList(list->tags[i].sublist);
			f_print_line_info();
			fprintf(yyout, "\tSM->SMResponseList.push_back(SMContextEntry_");
			switch(tag_no)	{
				case 0xB0:
					fprintf(yyout, "PLAINDO");
					break;
				case 0xB1:
					fprintf(yyout, "PLAINDO_AUTH");
					break;
			}
			fprintf(yyout, "(contextList));\n");	
		}	

		if(tag_no == 0x82 || tag_no == 0x83)	{	
			print_SMList(list->tags[i].sublist);
			f_print_line_info();
			fprintf(yyout, "\tSM->SMResponseList.push_back(SMContextEntry_");
			switch(tag_no)	{
				case 0x82:
					fprintf(yyout, "CRYPTODO");
					break;
				case 0x83:
					fprintf(yyout, "CRYPTODO_AUTH");
					break;
			}
			fprintf(yyout, "(");
			f_print_cryptospec(&(list->tags[i].crypto));
			fprintf(yyout, ", contextList));\n");	
		}

		if(tag_no == 0x86 || tag_no == 0x87 || tag_no == 0x8E)	{
			f_print_line_info();
			fprintf(yyout, "\tSM->SMResponseList.push_back(SMContextEntry_");
			switch(tag_no)	{
				case 0x86:
					fprintf(yyout, "ENCDATA");
					break;
				case 0x87:
					fprintf(yyout, "ENCDATA_AUTH");
					break;
				case 0x8E:
					fprintf(yyout, "CC");
					break;
			}
			fprintf(yyout, "(");
			f_print_cryptospec(&(list->tags[i].crypto));
			fprintf(yyout, "));\n");	
		}

		if(tag_no == 0xd0)	{
			f_print_line_info();
			fprintf(yyout, "\toffset = 0;\n");
			
			f_print_line_info();
			fprintf(yyout, "\tsm_do_str = (const BYTE*)");
			f_print_stringvalue(&(list->tags[i].crypto.key));
			fprintf(yyout, ";\n");
			
			f_print_line_info();
			fprintf(yyout, "\twhile(offset < ");
			f_print_intvalue(&(list->tags[i].crypto.key.length));
			fprintf(yyout, ")\t{\n");
			
			f_print_line_info();
			fprintf(yyout, "\t\tDO *sm_do = new DO(sm_do_str + offset);\n");

			f_print_line_info();
			fprintf(yyout, "\t\tSM->SMResponseList.push_back(SMContextEntry_DO(sm_do));\n");

			f_print_line_info();
			fprintf(yyout, "\t\toffset += sm_do->getTotalLength();\n");

			f_print_line_info();
			fprintf(yyout, "\t}\n");
		}
	}
}

void f_print_deleteSM(void)	{
	f_print_line_info();
	fprintf(yyout, "\tif(SM != NULL)\t{\n");
	f_print_line_info();
	fprintf(yyout, "\t\tfreeSMContext(SM);\n");
	f_print_line_info();
	fprintf(yyout, "\t\tdelete SM;\n");
	f_print_line_info();
	fprintf(yyout, "\t\tSM = NULL;\n");
	f_print_line_info();
	fprintf(yyout, "\t}\n");
}

void printrecordopt(ubyte4 recordopt)	{
	switch(recordopt)  {
		case FIRST:
			fprintf(yyout, ", WR_UP_FIRST, ");
			break;
		case LAST:
			fprintf(yyout, ", WR_UP_LAST, ");
			break;
		case NEXT:
			fprintf(yyout, ", WR_UP_NEXT, ");
			break;
		case PREVIOUS:
			fprintf(yyout, ", WR_UP_PREVIOUS, ");
			break;
		default:
			fprintf(yyout, ", WR_UP_REC_NO_P1, ");
			break;
	}
}

void print_tag(ubyte4 tagtype, struct intvalue_s *tagvalue)	{
	if(tagtype == BERTLV)	fprintf(yyout, "DO_TAG_BER_TLV_ONE, ");
	if(tagtype == BER2TLV)	fprintf(yyout, "DO_TAG_BER_TLV_TWO, ");
	if(tagtype == STLV)		fprintf(yyout, "DO_TAG_SIMPLE_TLV, ");
	if(tagtype == APPL)		fprintf(yyout, "DO_TAG_DUMPING, ");
	f_print_hexvalue(tagvalue);
}

void print_qualifier(ubyte4 rdtype, struct intvalue_s *rdvalue)	{
	if(rdtype == SRD)	fprintf(yyout, "SEC_SPECIFIC, ");
	else	fprintf(yyout, "SEC_GLOBAL, ");
	f_print_hexvalue(rdvalue);
	fprintf(yyout, ", ");
}

void f_readbinary(struct intvalue_s *sfi, struct intvalue_s *offset, struct intvalue_s *numbytes, struct expectedvalue_s *exp_val, char* sw)	{
	f_print_command_head(sw);

	f_print_expected_length(numbytes, exp_val);

	f_print_line_info();
	fprintf(yyout, "\tapdu = new ReadBinaryAPDU(");
	if(sfi != NULL)	{
		fprintf(yyout, "(BYTE)");
		f_print_hexvalue(sfi);
		fprintf(yyout, ", (BYTE)");
		f_print_hexvalue(offset);
	}
	else	{
		fprintf(yyout, "(WORD)");
		f_print_hexvalue(offset);
	}
	fprintf(yyout, ", offset, logCommand);\n");

	f_print_command_tail();
	f_print_check_expected_response(exp_val);
}

void f_writebinary(struct intvalue_s *sfi,struct intvalue_s *offset,struct stringvalue_s *string, char *sw)	{
	f_print_command_head(sw);
	f_print_line_info();
	fprintf(yyout, "\tapdu = new WriteBinaryAPDU(");
	if(sfi != NULL)	{
		fprintf(yyout, "(BYTE)");
		f_print_hexvalue(sfi);
		fprintf(yyout, ", (BYTE)");
		f_print_hexvalue(offset);
	}	
	else	{
		fprintf(yyout, "(WORD)");
		f_print_hexvalue(offset);
	}
	fprintf(yyout, ", ");
	print_data(string);
	fprintf(yyout, ", logCommand);\n");
	f_print_command_tail();
}

void f_updatebinary(struct intvalue_s *sfi,struct intvalue_s *offset,struct stringvalue_s *string, char* sw)	{
	f_print_command_head(sw);
	f_print_line_info();
	fprintf(yyout, "\tapdu = new UpdateBinaryAPDU(");
	if(sfi != NULL)	{
		fprintf(yyout, "(BYTE)");
		f_print_hexvalue(sfi);
		fprintf(yyout, ", (BYTE)");
		f_print_hexvalue(offset);
	}	
	else	{
		fprintf(yyout, "(WORD)");
		f_print_hexvalue(offset);
	}
	fprintf(yyout, ", ");
	print_data(string);
	fprintf(yyout, ", logCommand);\n");
	f_print_command_tail();
}

void f_erasebinary(struct intvalue_s *sfi, struct intvalue_s *offset, struct intvalue_s *numbytes, char *sw)	{
	f_print_command_head(sw);
	f_print_line_info();
	fprintf(yyout, "\tapdu = new EraseBinaryAPDU(");
	if(sfi != NULL)	{
		fprintf(yyout, "(BYTE)");
		f_print_hexvalue(sfi);
		fprintf(yyout, ", (BYTE)");
		f_print_hexvalue(offset);
	}	
	else	{
		fprintf(yyout, "(WORD)");
		f_print_hexvalue(offset);
	}
	if(numbytes != NULL)	{
		fprintf(yyout, ", (WORD)");
		f_print_hexvalue(numbytes);
	}
	fprintf(yyout, ", logCommand);\n");
	f_print_command_tail();
}

void f_readrecord(struct intvalue_s *sfi, ubyte4 rtype, struct intvalue_s *rvalue, ubyte4 recordopt, struct intvalue_s *numbytes, 
	struct expectedvalue_s *exp_val, char *sw)	{

	f_print_command_head(sw);

	f_print_expected_length(numbytes, exp_val);

	f_print_line_info();
	fprintf(yyout, "\tapdu = new ReadRecordAPDU(");
    	f_print_hexvalue(rvalue);
	fprintf(yyout, ", ");
	if(sfi == NULL)  fprintf(yyout, "0x00");
	else    f_print_hexvalue(sfi);
	fprintf(yyout, ", ");
	if(rtype == RNO)	fprintf(yyout, "READ_RECORD_P1 |");
	switch(recordopt)  {
		case LAST:
			fprintf(yyout, "READ_LAST");
			break;
		case NEXT:
			fprintf(yyout, "READ_NEXT");
			break;
		case PREVIOUS:
			fprintf(yyout, "READ_PREVIOUS");
			break;
		case FROMLAST:
			fprintf(yyout, "READ_ALL_LAST_TO_P1");
			break;
	    	case TOLAST:
			fprintf(yyout, "READ_ALL_P1_TO_LAST");
			break;
	       	case FIRST:
		default:
			fprintf(yyout, "READ_FIRST");
			break;
	}
	fprintf(yyout, ", offset, logCommand);\n");

	f_print_command_tail();
	f_print_check_expected_response(exp_val);
}

void f_writerecord(struct intvalue_s *sfi, struct intvalue_s *rno, ubyte4 recordopt, struct stringvalue_s *record, char *sw)	{
	f_print_command_head(sw);
	f_print_line_info();
	fprintf(yyout, "\tapdu = new WriteRecordAPDU(");
	if(rno == NULL)	fprintf(yyout, "0x00, ");
	else	{
		f_print_hexvalue(rno);
		fprintf(yyout, ", ");
	}
	if(sfi == NULL)  fprintf(yyout, "0x00");
	else    f_print_hexvalue(sfi);
	printrecordopt(recordopt);
	print_data(record);
	fprintf(yyout, ", logCommand);\n");
	f_print_command_tail();
}		

void f_appendrecord(struct intvalue_s *sfi, struct stringvalue_s *record, char *sw)	{
	f_print_command_head(sw);
	f_print_line_info();
	fprintf(yyout, "\tapdu = new AppendRecordAPDU(");
	if(sfi == NULL)  fprintf(yyout, "0x00");
	else    f_print_hexvalue(sfi);
	fprintf(yyout, ", ");
	print_data(record);
	fprintf(yyout, ", logCommand);\n");
	f_print_command_tail();
}

void f_updaterecord(struct intvalue_s *sfi, struct intvalue_s *rno, ubyte4 recordopt, struct stringvalue_s *record, char* sw)	{
	f_print_command_head(sw);
	f_print_line_info();
	fprintf(yyout, "\tapdu = new UpdateRecordAPDU(");
	if(rno == NULL)	fprintf(yyout, "0x00, ");
	else	{
		f_print_hexvalue(rno);
		fprintf(yyout, ", ");
	}
	if(sfi == NULL)  fprintf(yyout, "0x00");
	else    f_print_hexvalue(sfi);
	printrecordopt(recordopt);
	print_data(record);
	fprintf(yyout, ", logCommand);\n");
	f_print_command_tail();
}

void f_getdata(ubyte4 tagtype,struct intvalue_s *tagvalue,struct intvalue_s *numbytes, struct expectedvalue_s *exp_val, char *sw)	{
	f_print_command_head(sw);
	f_print_expected_length(numbytes, exp_val);
	f_print_line_info();
	fprintf(yyout, "\tapdu = new GetDataAPDU(");
	print_tag(tagtype, tagvalue);

	fprintf(yyout, ", offset, logCommand);\n");
	f_print_command_tail();
	f_print_check_expected_response(exp_val);
}

void f_putdata(ubyte4 tagtype,struct intvalue_s *tagvalue,struct stringvalue_s *data, char *sw)	{
	f_print_command_head(sw);
	f_print_line_info();
	fprintf(yyout, "\tapdu = new PutDataAPDU(");
	print_tag(tagtype, tagvalue);
	fprintf(yyout, ", ");
	print_data(data);
	fprintf(yyout, ", logCommand);\n");
	f_print_command_tail();
}

void f_getr(struct intvalue_s *numbytes, struct expectedvalue_s *exp_val, char *sw)	{
	f_print_command_head(sw);
	f_print_expected_length(numbytes, exp_val);
	f_print_line_info();
	fprintf(yyout, "\tapdu = new GetResponseAPDU(offset, logCommand);\n");
	f_print_command_tail();
	f_print_check_expected_response(exp_val);
}

void f_verify(ubyte4 rdtype, struct intvalue_s *rdvalue, struct stringvalue_s *data, char *sw)	{
	f_print_command_head(sw);
	f_print_line_info();
	fprintf(yyout, "\tapdu = new VerifyAPDU(");
	print_qualifier(rdtype, rdvalue);
	print_data(data);
	fprintf(yyout, ", logCommand);\n");
	f_print_command_tail();
}

void f_iauth(struct intvalue_s *algo, ubyte4 rdtype, struct intvalue_s *rdvalue, struct stringvalue_s *challenge, struct intvalue_s *numbytes,
	struct expectedvalue_s *exp_val, char *sw)	{
	f_print_command_head(sw);
	
	f_print_expected_length(numbytes, exp_val);

	f_print_line_info();
	fprintf(yyout, "\tapdu = new InternalAuthenticationAPDU(");
	f_print_hexvalue(algo);
	fprintf(yyout, ", ");
	print_qualifier(rdtype, rdvalue);
	print_data(challenge);
	
	fprintf(yyout, ", offset, logCommand);\n");
	f_print_command_tail();
	f_print_check_expected_response(exp_val);
}

void f_eauth(struct intvalue_s *algo, ubyte4 rdtype, struct intvalue_s *rdvalue, struct stringvalue_s *enc_challenge, char *sw)	{
	f_print_command_head(sw);
	f_print_line_info();
	fprintf(yyout, "\tapdu = new ExternalAuthenticationAPDU(");
	f_print_hexvalue(algo);
	fprintf(yyout, ", ");
	print_qualifier(rdtype, rdvalue);
	print_data(enc_challenge);
	fprintf(yyout, ", logCommand);\n");
	f_print_command_tail();
}

void f_mauth(struct intvalue_s *algo, ubyte4 rdtype, struct intvalue_s *rdvalue, struct stringvalue_s *challenge, struct stringvalue_s *enc_challenge,
	struct intvalue_s *numbytes, struct expectedvalue_s *exp_val, char *sw)	{

	f_print_command_head(sw);
	
	f_print_expected_length(numbytes, exp_val);

	f_print_line_info();
	fprintf(yyout, "\tapdu = new MutualAuthenticationAPDU(");
	f_print_hexvalue(algo);
	fprintf(yyout, ", ");
	print_qualifier(rdtype, rdvalue);
	print_data(challenge);
	if(enc_challenge != NULL)	{
		fprintf(yyout, ", ");
		print_data(enc_challenge);
	}
	
	fprintf(yyout, ", offset, logCommand);\n");
	
	f_print_command_tail();
	f_print_check_expected_response(exp_val);
}

void f_getc(struct intvalue_s *algo, struct intvalue_s *numbytes, struct expectedvalue_s *exp_val, char *sw)	{
	f_print_command_head(sw);
	f_print_expected_length(numbytes, exp_val);
	
	f_print_line_info();
	fprintf(yyout, "\tapdu = new GetChallengeAPDU(");
	if(algo == NULL)	fprintf(yyout, "0x00");
	else	f_print_hexvalue(algo);
	fprintf(yyout, ", offset, logCommand);\n");

	f_print_command_tail();
	f_print_line_info();
	fprintf(yyout, "\tif(RespLen > 0)\t{\n");
	f_print_line_info();
	fprintf(yyout, "\t\tmemcpy(challenge, outdata, RespLen);\n");
	f_print_line_info();
	fprintf(yyout, "\t\tchallengelen = RespLen;\n");
	f_print_line_info();
	fprintf(yyout, "\t}\n");
	f_print_check_expected_response(exp_val);
}

void f_command_value(sbyte *cmd,struct intvalue_s *value, char *sw)	{
	f_print_command_head(sw);
	f_print_line_info();
	fprintf(yyout, "\tapdu = new %sAPDU(", cmd);
	f_print_intvalue(value);
	fprintf(yyout, ", logCommand);\n");
	f_print_command_tail();
}

void f_mseset(ubyte4 mseopt,struct intvalue_s *value,struct stringvalue_s *CRTvalue, char *sw)	{
	f_print_command_head(sw);
	f_print_line_info();
	fprintf(yyout, "\tapdu = new MSESetAPDU(");
	if(mseopt == CDA)	fprintf(yyout, "SEC_COMPUTE_DECIPHER, ");
	if(mseopt == VEA)	fprintf(yyout, "SEC_VERIFY_ENCIPHER, ");
	if(mseopt == CDAVEA)	fprintf(yyout, "SEC_COMPUTE_DECIPHER|SEC_VERIFY_ENCIPHER, ");

	f_print_intvalue(value);
	fprintf(yyout, ", ");
	print_data(CRTvalue);
	fprintf(yyout, ", logCommand);\n");
	f_print_command_tail();
}

void f_pso(struct pso_s *psoop, struct intvalue_s *numbytes, struct expectedvalue_s *exp_val, char *sw)	{
	f_print_command_head(sw);
	
	f_print_expected_length(numbytes, exp_val);

	f_print_line_info();
	fprintf(yyout, "\tapdu = new PSO");
	switch(psoop->op)	{
		case CCC:
			{
				fprintf(yyout, "ComputeCCAPDU(");
				print_data(&psoop->in_data);
				break;
			}
		case VCC:
			{
				fprintf(yyout, "VerifyCCAPDU(");
				print_data(&psoop->in_data);
				break;
			}
		case ENCIPHER:
			{
				fprintf(yyout, "EncryptAPDU(");
				print_data(&psoop->in_data);
				fprintf(yyout, ", (BYTE)(");
				f_print_hexvalue(psoop->tag);
				fprintf(yyout, " & 0x000000FF)");
				break;
			}
		case DECIPHER:
			{
				fprintf(yyout, "DecryptAPDU(");
				print_data(&psoop->in_data);
				fprintf(yyout, ", (BYTE)(");
				f_print_hexvalue(psoop->tag);
				fprintf(yyout, " & 0x000000FF)");
				break;
			}
		case HASH:
			{
				fprintf(yyout, "HashAPDU(");
				print_data(&psoop->in_data);
				break;
			}
		case COMPUTE_DIG_SIG:
			{
				fprintf(yyout, "ComputeDigSigAPDU(");
				print_data(&psoop->in_data);
				break;
			}
		case VERIFY_DIG_SIG:
			{
				fprintf(yyout, "VerifyDigSigAPDU(");
				print_data(&psoop->in_data);
				break;
			}
		case VERIFY_CERT:
			{
				fprintf(yyout, "VerifyCertificateAPDU(");
				print_data(&psoop->in_data);
				break;
			}
	}
	fprintf(yyout, ", offset, logCommand);\n");
	f_print_command_tail();
	f_print_check_expected_response(exp_val);
}

void exchangeRefData(struct crd_s *crd)	{
	f_print_line_info();
	fprintf(yyout, "\tapdu = new ChangeReferenceDataAPDU(");
	print_qualifier(crd->rdtype, &(crd->rdvalue));
	print_data(&(crd->newdata));
	fprintf(yyout, ", ");
	print_data(crd->olddata);
	fprintf(yyout, ", logCommand);\n");
}

void changeRefData(struct crd_s *crd)	{
	f_print_line_info();
	fprintf(yyout, "\tapdu = new ChangeReferenceDataAPDU(");
	print_qualifier(crd->rdtype, &(crd->rdvalue));
	print_data(&(crd->newdata));
	fprintf(yyout, ", 0, NULL, logCommand);\n");
}

void f_crd_call(struct crd_s *crd, char *sw)	{	
	f_print_command_head(sw);
	switch(crd->crdopt)	{
		case C:
			changeRefData(crd);
			break;
		case X:
			exchangeRefData(crd);
			break;
	}
	f_print_command_tail();
}

void f_vr(ubyte4 cmd,ubyte4 rdtype,struct intvalue_s *rdvalue,struct stringvalue_s *data, char *sw)	{
	f_print_command_head(sw);
	f_print_line_info();
	switch(cmd)	{
		case EVR:
			fprintf(yyout, "\tapdu = new EnableVerificationAPDU(");
			break;
		case DVR:
			fprintf(yyout, "\tapdu = new DisableVerificationAPDU(");
			break;
	}
	
	print_qualifier(rdtype, rdvalue);
	print_data(data);
	fprintf(yyout, ", logCommand);\n");
	f_print_command_tail();
}

void f_rrc(struct rrc_s *rrc, char *sw)	{	//resetting code assumed not to be more than one byte
	f_print_command_head(sw);
	f_print_line_info();
	fprintf(yyout, "\tapdu = new ResetRetryCounterAPDU(");
	print_qualifier(rrc->rdtype, &(rrc->rdval));
	if(rrc->rcode != NULL)	{
		f_print_intvalue(rrc->rcode);
		fprintf(yyout, ", ");
	}
	print_data(rrc->nrd);
	fprintf(yyout, ", logCommand);\n");
	f_print_command_tail();
}

void f_file_cmds(ubyte4 cmd,struct int_string_s *file,ubyte4 recordopt, ubyte4 finfo, struct intvalue_s *numbytes, struct expectedvalue_s *exp_val, char *sw)	{
	f_print_command_head(sw);
	
	switch(finfo)	{
		case FCP:
		case FCI:
			f_print_expected_length(numbytes, exp_val);
			break;
		case FMD:
			if(cmd == SF)	f_print_expected_length(numbytes, exp_val);
			break;
	}

	f_print_line_info();
	switch(cmd)	{
		case SF:
			fprintf(yyout, "\tapdu = new SelectFileAPDU(");
			break;
		case DF:
			fprintf(yyout, "\tapdu = new DeleteFileAPDU(");
			break;
		case DAF:
			fprintf(yyout, "\tapdu = new DeActivateFileAPDU(");
			break;
		case AF:
			fprintf(yyout, "\tapdu = new ActivateFileAPDU(");
			break;
		case TERMDF:
			fprintf(yyout, "\tapdu = new TerminateDFAPDU(");
			break;
		case TERMEF:
			fprintf(yyout, "\tapdu = new TerminateEFAPDU(");
			break;
	}
	
	switch(file->reftype)	{
		case    DFNAME:
			fprintf(yyout, "SEL_DF_NAME, ");
			break;
		case    CDF:
			fprintf(yyout, "SEL_CHILD_DF, ");
			break;
		case    CEF:
			fprintf(yyout, "SEL_CHILD_EF, ");
			break;
		case    PDF:
			fprintf(yyout, "SEL_PARENTDF_OF_CURRENTDF, ");
			break;
		case    MF:
			fprintf(yyout, "SEL_ANY, ");
			break;
		case    MFPATH:
			fprintf(yyout, "SEL_FROM_MF, ");
			break;
		case    CDFPATH:
			fprintf(yyout, "SEL_FROM_CURRENT_DF, ");
			break;
	}
	switch(recordopt)	{
		case LAST:
			fprintf(yyout, "FILEOP_LAST_OCC");
			break;
		case NEXT:
			fprintf(yyout, "FILEOP_NEXT_OCC");
			break;
		case PREVIOUS:
			fprintf(yyout, "FILEOP_PREVIOUS_OCC");
			break;
		case FIRST:
		default:
			fprintf(yyout, "FILEOP_FIRST_OCC");
			break;
	}
	switch(finfo)	{
		case FCP:	
			fprintf(yyout, " | FILEOP_RET_FCP");
			break;
		case FCI:
			fprintf(yyout, " | FILEOP_RET_FCI");
			break;
		case FMD:
			if(cmd == SF)	fprintf(yyout, " | FILEOP_RET_FMD");
			break;
		default:
			if(cmd == SF)	fprintf(yyout, " | FILEOP_NO_RESPONSE");
			break;
	}
	fprintf(yyout, ", ");
	switch(file->reftype)	{
		case    DFNAME:
			{
				f_print_intvalue(&(file->value.stringvalue.length));
				fprintf(yyout, ", (const BYTE*)");
				f_print_stringvalue(&(file->value.stringvalue));
				break;
			}
		case    CDF:
			{
				f_print_intvalue(&(file->value.intvalue));
				break;
			}
		case    CEF:
			{
				f_print_intvalue(&(file->value.intvalue));
				break;
			}
		case    PDF:
			{
				fprintf(yyout, "0, NULL");
				break;
			}
		case    MF:
			{
				fprintf(yyout, "0x3f00");
				break;
			}
		case    MFPATH:
			{
				f_print_intvalue(&(file->value.stringvalue.length));
				fprintf(yyout, ", (const BYTE*)");
				f_print_stringvalue(&(file->value.stringvalue));
				break;
			}
		case    CDFPATH:
			{
				f_print_intvalue(&(file->value.stringvalue.length));
				fprintf(yyout, ", (const BYTE*)");
				f_print_stringvalue(&(file->value.stringvalue));
				break;
			}
	}
	fprintf(yyout, ", ");
	switch(finfo)	{
		case FCP:
			fprintf(yyout, "offset");
			break;
		case FCI:
			fprintf(yyout, "offset");
			break;
		case FMD:
			if(cmd == SF)	fprintf(yyout, "offset");
			else	fprintf(yyout, "0");
			break;
		default:
			fprintf(yyout, "0");
			break;
	}
	fprintf(yyout, ", logCommand);\n");
	f_print_command_tail();
	f_print_check_expected_response(exp_val);
}

void printFCP_DF(struct df_s *df)	{
	// set file discriptor BYTE
	f_print_line_info();
	fprintf(yyout, "\tprocess_return_code(fcp->setFD(FDB_DF));\n");

	// set DF name
	if(df->name != NULL)	{
		f_print_line_info();
		fprintf(yyout, "\tprocess_return_code(fcp->setDFname(");
		print_data(df->name);
		fprintf(yyout, "));\n");
	}

	// set SE 
	if(df->se != NULL)	{
		f_print_line_info();
		fprintf(yyout, "\tprocess_return_code(fcp->addDOtoFCP(DO(0x7B, ");
		print_data(df->se);
		fprintf(yyout, ")));\n");
	}

	// set SE File
	if(df->sefile != NULL)	{
		f_print_line_info();	
		fprintf(yyout,"\tprocess_return_code(fcp->setSE(");
		f_print_hexvalue(df->sefile);
		fprintf(yyout, "));\n");
	}
}

void printFCP_EF(struct ef_s *ef)	{
	// set file descriptor byte and data coding byte
	f_print_line_info();
	fprintf(yyout, "\tprocess_return_code(fcp->setFD(");
	
	if(ef->eftype == WORKING)	fprintf(yyout, "FDB_WORKING_EF");
	else fprintf(yyout, "FDB_INTERNAL_EF");

	if(ef->efstructure == TRANSPARENT)	{
		fprintf(yyout, " | FDB_TRANSPARENT");
		if(ef->datacode != T_DEFAULT)	{
			fprintf(yyout, ", ");
			switch(ef->datacode)	{
				case WRITE_AND:
					fprintf(yyout, "DCB_WRITE_AND");
					break;
				case WRITE_ONCE:
					fprintf(yyout ,"DCB_WRITE_ONCE");
					break;
				case WRITE_OR:
				default:
					fprintf(yyout ,"DCB_WRITE_OR");
					break;
			}
		}
		fprintf(yyout, "));\n");
		
		// set filesize for TRANSPARENT EFs.
		f_print_line_info();
		fprintf(yyout, "\tprocess_return_code(fcp->setFileSize(");
		f_print_hexvalue(ef->efinfo.filesize);
		fprintf(yyout, "));\n");
	}
	else	{
		switch(ef->efstructure)	{
			case FIXEDLENGTH:
				if(ef->efinfo.recinfo.stlvflag != SIMPLETLV)	fprintf(yyout, " | FDB_LINEAR_FIXED");
				else	fprintf(yyout, " | FDB_LINEAR_FIXED_TLV");
				break;
			case VARLENGTH:
				if(ef->efinfo.recinfo.stlvflag != SIMPLETLV)	fprintf(yyout, " | FDB_LINEAR_VARIABLE");
				else	fprintf(yyout, " | FDB_LINEAR_VARIABLE_TLV");
				break;
			case CYCLIC:
				if(ef->efinfo.recinfo.stlvflag != SIMPLETLV)	fprintf(yyout, " | FDB_CYCLIC");
				else	fprintf(yyout, " | FDB_CYCLIC_TLV");
				break;
		}
		
		fprintf(yyout, ", ");
		switch(ef->datacode)	{
			case WRITE_AND:
				fprintf(yyout, "DCB_WRITE_AND");
				break;
			case WRITE_ONCE:
				fprintf(yyout ,"DCB_WRITE_ONCE");
				break;
			case WRITE_OR:
			default:
				fprintf(yyout ,"DCB_WRITE_OR");
				break;
		}
		
		fprintf(yyout, ", ");
		f_print_intvalue(ef->efinfo.recinfo.mrl);
		fprintf(yyout, ", ");
		f_print_intvalue(ef->efinfo.recinfo.mnr);
		fprintf(yyout, "));\n");
	}
	
	// set Short File Id.
	if(ef->sfi != NULL)	{
		f_print_line_info();
		fprintf(yyout, "\tprocess_return_code(fcp->setShortfid((BYTE)");
		f_print_intvalue(ef->sfi);
		fprintf(yyout, "));\n");
	}
}

void f_createfile(struct cf_s *cf, char *sw)	{
	f_print_command_head(sw);

	// create FCP object
	f_print_line_info();
	fprintf(yyout, "\tfcp = new FCP(");
	f_print_hexvalue(&(cf->fileid));
	fprintf(yyout, ");\n");

	// set FCP parameters depending upon file type (EF or DF)
	if(cf->filetype == DF)	printFCP_DF(cf->file.df);
	else	printFCP_EF(cf->file.ef);
			
	// set LCSI
	if(cf->lcsi != NULL)	{
		f_print_line_info();
		fprintf(yyout, "\tprocess_return_code(fcp->setLCSI(");
		f_print_intvalue(cf->lcsi);
		fprintf(yyout, "));\n");
	}
			
	// set compact access rule
	if(cf->compact_attr != NULL)	{
		f_print_line_info();
		fprintf(yyout, "\tprocess_return_code(fcp->addDOtoFCP(DO(0x8C, ");
		print_data(cf->compact_attr);
		fprintf(yyout, ")));\n");
	}
	
	// set expanded access rule
	if(cf->expanded_attr != NULL)	{
		f_print_line_info();
		fprintf(yyout, "\tprocess_return_code(fcp->addDOtoFCP(DO(0xAB, ");
		print_data(cf->expanded_attr);
		fprintf(yyout, ")));\n");
	}

	// create create file apdu
	f_print_line_info();
	fprintf(yyout, "\tapdu = new CreateFileAPDU(fcp, logCommand);\n");

	// apdu is created and initialized, now free the fcp object created.
	f_print_line_info();
	fprintf(yyout, "\tdelete fcp;\n");
	f_print_line_info();
	fprintf(yyout, "\tfcp = NULL;\n");
	f_print_command_tail();
}

void f_send_apdu(struct apdu_s *apdu_val, struct expectedvalue_s *exp_val, char *sw)	{
	f_print_command_head(sw);
	
	f_print_line_info();
	fprintf(yyout, "\tapdu = new APDU();\n");

	// set CLA
	if(apdu_val->cla.tag!=T_NOTSET)	{
  		f_print_line_info();
    		fprintf(yyout, "\tapdu->setCLA(");
		f_print_hexvalue(&apdu_val->cla);
		fprintf(yyout, ");\n");
	}
  	
	// set INS
	if(apdu_val->ins.tag!=T_NOTSET)	{
  		f_print_line_info();
    		fprintf(yyout, "\tapdu->setINS(");
	    	f_print_hexvalue(&apdu_val->ins);
		fprintf(yyout, ");\n");
	}
	
	// set P1
  	if(apdu_val->p1.tag!=T_NOTSET)	{
  		f_print_line_info();
    		fprintf(yyout, "\tapdu->setP1(");
	    	f_print_hexvalue(&apdu_val->p1);
		fprintf(yyout, ");\n");
	}
	
	// set P2
  	if(apdu_val->p2.tag!=T_NOTSET)	{
  		f_print_line_info();
    		fprintf(yyout, "\tapdu->setP2(");
    		f_print_hexvalue(&apdu_val->p2);
		fprintf(yyout, ");\n");
	}
	
	// set Lc & Lc_buffer
  	if(apdu_val->lc.tag!=T_NOTSET && apdu_val->indata.tag!=T_NOTSET)	{
  		f_print_line_info();
    		fprintf(yyout, "\tprocess_return_code(apdu->setData(");
	    	f_print_hexvalue(&apdu_val->lc);
		fprintf(yyout, ", (const BYTE*)");
		f_print_stringvalue(&apdu_val->indata);
		fprintf(yyout, "));\n");
	}
  
  	// set Le
 	if(apdu_val->le.tag!=T_NOTSET)	{
  		f_print_line_info();
    		fprintf(yyout, "\tprocess_return_code(apdu->setLe(");
		f_print_intvalue(&apdu_val->le);
		fprintf(yyout, "));\n");
	}
  	
	// set the log function
	f_print_line_info();
    	fprintf(yyout, "\tapdu->setFunc(logCommand);\n");
	f_print_command_tail();
	f_print_check_expected_response(exp_val);
}

void f_reset(void)	{
  	f_print_line_info();
  	fprintf(yyout,"\treset();\n");	// calls function reset
}

void f_print_sm_status(char *sw)	{
	f_print_line_info();
	fprintf(yyout,"\tSMsw = \"%s\";\n", sw);
}

void print_header()	{
	extern FILE *global;
	extern int gid;
}

void print_code()	{
	int i;
	fprintf(yyout, "#include <cstdio>\n#include <sys/types.h>\n#include <sys/stat.h>\n#include <fcntl.h>\n");
	fprintf(yyout, "#include <winscard.h>\n");
	fprintf(yyout, "#include <cstring>\n");
	fprintf(yyout, "#include <cstdlib>\n");
	fprintf(yyout, "#include \"isolib.h\"\n");
	fprintf(yyout, "#include \"cmdlib.h\"\n");
	fprintf(yyout, "#include \"%s\"\n",header);
	fprintf(yyout, "\n");
	fprintf(yyout, "/* Global Variables */\n");
	fprintf(yyout, "extern BYTE sw1;\n");
	fprintf(yyout, "extern BYTE sw2;\n");
	fprintf(yyout, "extern BYTE outdata[MAX_BUFFER];\n");
	fprintf(yyout, "extern UINT RespLen;\n");
	fprintf(yyout, "extern BYTE challenge[MAX_CHALLENGE];\n");
	fprintf(yyout, "extern UINT challengelen;\n\n");
	fprintf(yyout, "extern char *SMsw;\n");
	fprintf(yyout, "extern CommandInfo *T_command;\n");
	fprintf(yyout, "extern Reader *reader;\n");
	fprintf(yyout, "extern APDU *apdu;\n");
	fprintf(yyout, "extern SMContext *SM;\n");
	fprintf(yyout, "extern FCP *fcp;\n");
	fprintf(yyout, "BYTE T_error_behavior;\n");
	fprintf(yyout, "SMContextList *contextList = NULL;\n");
	fprintf(yyout, "SMContextList *newContextList = NULL;\n");
	fprintf(yyout, "SMContextList *tempContextList = NULL;\n");
	fprintf(yyout, "const BYTE* sm_do_str = NULL;\n");
	fprintf(yyout, "int sm_do_len = 0;\n");
	fprintf(yyout, "int offset = 0;\n");

	fprintf(yyout,"char *script_file = (char*)\"");
	if (script_file == NULL) fprintf(yyout, "StdInput");
	else {
		for (i=0; script_file[i]; i++)
			if(script_file[i]=='\\') script_file[i]='/';
		fprintf(yyout, "%s", script_file);
	}
	fprintf(yyout, "\";\n");

	fprintf(yyout,"\nint main(int argc, char *argv[]) {\n\n");

	// printing code, the exception handler is for handelling the exceptions generated by command library.
	f_exception_handle_begin();

	f_print_line_info();
	fprintf(yyout,"\tinitialize(argc, argv);\n");
	f_print_line_info();
	fprintf(yyout, "\tfprintf(stderr, \"\\nTesting Script %%s\\n\", script_file);\n\n");

	yyparse();

	f_exception_handle_end();

	// freeing memory
	f_print_line_info();
	fprintf(yyout, "free_variables();\n");

	fprintf(yyout,"}\n");
	print_header();
}

void f_print_hexvalue(struct intvalue_s *hexvalue)	{
	if  (hexvalue==NULL)	{ 
		fprintf(yyout,"0x00");
		return;
	}
	if (hexvalue->tag == CVARIABLE)	fprintf(yyout,"%s", hexvalue->intvalue_u.stringvalue);
	else	fprintf(yyout,"0x%X", hexvalue->intvalue_u.intvalue);
}
 
void f_print_intvalue(struct intvalue_s *intvalue)	{
	if(intvalue == NULL)	{ 
		fprintf(yyout,"0");
		return;
	}
	if (intvalue->tag == CVARIABLE)	fprintf(yyout,"%s", intvalue->intvalue_u.stringvalue);
	else	fprintf(yyout,"%d", intvalue->intvalue_u.intvalue);
}

void f_print_stringvalue(struct stringvalue_s *stringvalue)	{
	if((stringvalue == NULL) || (stringvalue->stringvalue == NULL))	{
		fprintf(yyout,"NULL");
		return;
	}
	if(stringvalue->tag == CVARIABLE)	fprintf(yyout,"%s", stringvalue->stringvalue);
	else	fprintf(yyout,"%s", stringvalue->stringvalue);
}

void f_print_cryptospec(struct cryptospec_s *crypto)	{
	if(crypto == NULL)	{
		fprintf(yyout, "NULL ");
		return;
	}
	else	{
		fprintf(yyout, "new cryptospec(");
		if(crypto->algo == NULL)
			fprintf(yyout, "\"tdes-cbc\", ");
		else	
			fprintf(yyout, "%s, ", crypto->algo);
		if(isEmpty(crypto->key))	{
			fprintf(yyout, "NULL");
		}
		else	{
			f_print_stringvalue(&(crypto->key));
			fprintf(yyout, ", ");
			f_print_intvalue(&(crypto->key.length));
		}
		fprintf(yyout, ", ");
		if(isEmpty(crypto->key))	{
			fprintf(yyout, "NULL");
		}
		else	{
			f_print_stringvalue(&(crypto->iv));
			fprintf(yyout, ", ");
			f_print_intvalue(&(crypto->iv.length));
		}
		fprintf(yyout, ") ");
	}
}
