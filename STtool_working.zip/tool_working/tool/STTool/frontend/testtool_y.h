/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_TESTTOOL_Y_H_INCLUDED
# define YY_YY_TESTTOOL_Y_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    STRING = 258,                  /* STRING  */
    CVARIABLE = 259,               /* CVARIABLE  */
    HEXSTR = 260,                  /* HEXSTR  */
    VALUE = 261,                   /* VALUE  */
    X = 262,                       /* X  */
    C = 263,                       /* C  */
    ISEQUAL = 264,                 /* ISEQUAL  */
    ISNOTEQUAL = 265,              /* ISNOTEQUAL  */
    OK = 266,                      /* OK  */
    SW = 267,                      /* SW  */
    ERR = 268,                     /* ERR  */
    ANY = 269,                     /* ANY  */
    WB = 270,                      /* WB  */
    UB = 271,                      /* UB  */
    EB = 272,                      /* EB  */
    RR = 273,                      /* RR  */
    RNO = 274,                     /* RNO  */
    RID = 275,                     /* RID  */
    FIRST = 276,                   /* FIRST  */
    LAST = 277,                    /* LAST  */
    NEXT = 278,                    /* NEXT  */
    PREVIOUS = 279,                /* PREVIOUS  */
    TOLAST = 280,                  /* TOLAST  */
    FROMLAST = 281,                /* FROMLAST  */
    WR = 282,                      /* WR  */
    AR = 283,                      /* AR  */
    UR = 284,                      /* UR  */
    SEMICOLON = 285,               /* SEMICOLON  */
    BERTLV = 286,                  /* BERTLV  */
    APPL = 287,                    /* APPL  */
    STLV = 288,                    /* STLV  */
    BER2TLV = 289,                 /* BER2TLV  */
    GD = 290,                      /* GD  */
    PD = 291,                      /* PD  */
    GRD = 292,                     /* GRD  */
    SRD = 293,                     /* SRD  */
    VERIFY = 294,                  /* VERIFY  */
    IAUTH = 295,                   /* IAUTH  */
    CHALLENGE = 296,               /* CHALLENGE  */
    EAUTH = 297,                   /* EAUTH  */
    CHALLRESP = 298,               /* CHALLRESP  */
    GETC = 299,                    /* GETC  */
    GETR = 300,                    /* GETR  */
    MSESET = 301,                  /* MSESET  */
    MSESTORE = 302,                /* MSESTORE  */
    MSERESTORE = 303,              /* MSERESTORE  */
    MSEERASE = 304,                /* MSEERASE  */
    PSO = 305,                     /* PSO  */
    CCC = 306,                     /* CCC  */
    ENCIPHER = 307,                /* ENCIPHER  */
    DECIPHER = 308,                /* DECIPHER  */
    HASH = 309,                    /* HASH  */
    COMPUTE_DIG_SIG = 310,         /* COMPUTE_DIG_SIG  */
    VERIFY_DIG_SIG = 311,          /* VERIFY_DIG_SIG  */
    VERIFY_CERT = 312,             /* VERIFY_CERT  */
    EVR = 313,                     /* EVR  */
    DATA = 314,                    /* DATA  */
    DVR = 315,                     /* DVR  */
    RRC = 316,                     /* RRC  */
    RCODE = 317,                   /* RCODE  */
    DFNAME = 318,                  /* DFNAME  */
    CDF = 319,                     /* CDF  */
    CEF = 320,                     /* CEF  */
    PDF = 321,                     /* PDF  */
    MF = 322,                      /* MF  */
    MFPATH = 323,                  /* MFPATH  */
    FCP = 324,                     /* FCP  */
    FCI = 325,                     /* FCI  */
    FMD = 326,                     /* FMD  */
    SF = 327,                      /* SF  */
    DF = 328,                      /* DF  */
    DAF = 329,                     /* DAF  */
    AF = 330,                      /* AF  */
    TERMDF = 331,                  /* TERMDF  */
    TERMEF = 332,                  /* TERMEF  */
    VCC = 333,                     /* VCC  */
    CRD = 334,                     /* CRD  */
    OLDDATA = 335,                 /* OLDDATA  */
    NEWDATA = 336,                 /* NEWDATA  */
    NRD = 337,                     /* NRD  */
    CDFPATH = 338,                 /* CDFPATH  */
    MAUTH = 339,                   /* MAUTH  */
    CREATEFILE = 340,              /* CREATEFILE  */
    SE = 341,                      /* SE  */
    SEFILE = 342,                  /* SEFILE  */
    INTERNAL = 343,                /* INTERNAL  */
    WORKING = 344,                 /* WORKING  */
    TRANSPARENT = 345,             /* TRANSPARENT  */
    FILESIZE = 346,                /* FILESIZE  */
    FIXEDLENGTH = 347,             /* FIXEDLENGTH  */
    VARLENGTH = 348,               /* VARLENGTH  */
    CYCLIC = 349,                  /* CYCLIC  */
    MNR = 350,                     /* MNR  */
    MRL = 351,                     /* MRL  */
    SIMPLETLV = 352,               /* SIMPLETLV  */
    DATACODING = 353,              /* DATACODING  */
    FILEID = 354,                  /* FILEID  */
    WRITE_OR = 355,                /* WRITE_OR  */
    WRITE_ONCE = 356,              /* WRITE_ONCE  */
    WRITE_AND = 357,               /* WRITE_AND  */
    LCSI = 358,                    /* LCSI  */
    CDA = 359,                     /* CDA  */
    VEA = 360,                     /* VEA  */
    COMPACT_ATTR = 361,            /* COMPACT_ATTR  */
    EXPANDED_ATTR = 362,           /* EXPANDED_ATTR  */
    CAPDU = 363,                   /* CAPDU  */
    CLA = 364,                     /* CLA  */
    INS = 365,                     /* INS  */
    P1 = 366,                      /* P1  */
    P2 = 367,                      /* P2  */
    Lc = 368,                      /* Lc  */
    Le = 369,                      /* Le  */
    INDATA = 370,                  /* INDATA  */
    RB = 371,                      /* RB  */
    SFI = 372,                     /* SFI  */
    CDAVEA = 373,                  /* CDAVEA  */
    RESET = 374,                   /* RESET  */
    EXPVAL = 375,                  /* EXPVAL  */
    SM = 376,                      /* SM  */
    RESPONSE = 377,                /* RESPONSE  */
    KEYVAL = 378,                  /* KEYVAL  */
    ALGO = 379,                    /* ALGO  */
    IV = 380,                      /* IV  */
    SM_NULL = 381,                 /* SM_NULL  */
    CHINCLUDE = 382,               /* CHINCLUDE  */
    CDATA = 383,                   /* CDATA  */
    CDATA_AUTH = 384,              /* CDATA_AUTH  */
    PLAINDO = 385,                 /* PLAINDO  */
    PLAINDO_AUTH = 386,            /* PLAINDO_AUTH  */
    CRYPTODO = 387,                /* CRYPTODO  */
    CRYPTODO_AUTH = 388,           /* CRYPTODO_AUTH  */
    ENCDATA = 389,                 /* ENCDATA  */
    ENCDATA_AUTH = 390,            /* ENCDATA_AUTH  */
    CH_AUTH = 391,                 /* CH_AUTH  */
    LE = 392,                      /* LE  */
    LE_AUTH = 393,                 /* LE_AUTH  */
    STATUS = 394,                  /* STATUS  */
    HASH_AUTH = 395,               /* HASH_AUTH  */
    CC = 396,                      /* CC  */
    DO = 397                       /* DO  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 63 "testtool.y"

	unsigned int intval;
	char *stringval;
	struct intvalue_s intval_s;
	struct intvalue_s *intval_s_ptr;
	struct stringvalue_s stringval_s;
	struct int_string_s int_string_val_s;
	struct rrc_s rrcval_s;
	struct df_s dfval_s;
	struct ef_s efval_s;
	struct cf_s cfval_s;
	struct taglist_s *tagList;
	struct taglistItem_s tagListItemval_s;
	struct cryptospec_s cryptoSpecval_s;

#line 222 "testtool_y.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_TESTTOOL_Y_H_INCLUDED  */
