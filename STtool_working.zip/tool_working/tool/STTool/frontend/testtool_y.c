/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "testtool.y"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "testtool.h"
#include "arch.h"

extern char *yytext;
extern FILE *yyin,*yyout;

FILE *global;
char *header;
char command[MAX_BUFFER];
unsigned int lineno;
char sw[10];
void free_intvalue(struct intvalue_s *);
void free_stringvalue(struct stringvalue_s *);
void free_expectedvalue(struct expectedvalue_s *);
void free_cf(struct cf_s *);
void free_df(struct df_s *);
void free_ef(struct ef_s *);
void free_rrc(struct rrc_s *);
void free_crd(struct crd_s *);
void free_pso(struct pso_s *psoop);
void free_int_string(struct int_string_s *);
void free_apdu(struct apdu_s *);
int estringlen(sbyte *);
void setEmpty(struct stringvalue_s *s);
int isEmpty(struct stringvalue_s s);
char *strsave(char *);
void intval_save(struct intvalue_s *dst,struct intvalue_s *src);
void strval_save(struct stringvalue_s *dst,struct stringvalue_s *src);
char *check_tags(int , struct taglist_s *, int); 

struct stringvalue_s dfname;
struct stringvalue_s df_se;
struct intvalue_s df_sefile;
struct intvalue_s lcsi;
struct stringvalue_s compact_attr;
struct stringvalue_s expanded_attr;
struct intvalue_s total_size;
struct intvalue_s sfi;
struct intvalue_s mnr;
struct intvalue_s mrl;
struct intvalue_s filesize;
struct intvalue_s cf_fileid;
struct df_s df;
struct ef_s ef;
struct cf_s cf;
struct rrc_s rrcval;
struct intvalue_s rcode;
struct stringvalue_s nrd;
struct stringvalue_s olddata,newdata;
struct crd_s crd;
struct pso_s psoop;
struct apdu_s apdu_val;
struct expectedvalue_s command_exp_val;
struct intvalue_s tag;

FILE *errfile;

#line 133 "testtool_y.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "testtool_y.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_STRING = 3,                     /* STRING  */
  YYSYMBOL_CVARIABLE = 4,                  /* CVARIABLE  */
  YYSYMBOL_HEXSTR = 5,                     /* HEXSTR  */
  YYSYMBOL_VALUE = 6,                      /* VALUE  */
  YYSYMBOL_X = 7,                          /* X  */
  YYSYMBOL_C = 8,                          /* C  */
  YYSYMBOL_ISEQUAL = 9,                    /* ISEQUAL  */
  YYSYMBOL_ISNOTEQUAL = 10,                /* ISNOTEQUAL  */
  YYSYMBOL_OK = 11,                        /* OK  */
  YYSYMBOL_SW = 12,                        /* SW  */
  YYSYMBOL_ERR = 13,                       /* ERR  */
  YYSYMBOL_ANY = 14,                       /* ANY  */
  YYSYMBOL_WB = 15,                        /* WB  */
  YYSYMBOL_UB = 16,                        /* UB  */
  YYSYMBOL_EB = 17,                        /* EB  */
  YYSYMBOL_RR = 18,                        /* RR  */
  YYSYMBOL_RNO = 19,                       /* RNO  */
  YYSYMBOL_RID = 20,                       /* RID  */
  YYSYMBOL_FIRST = 21,                     /* FIRST  */
  YYSYMBOL_LAST = 22,                      /* LAST  */
  YYSYMBOL_NEXT = 23,                      /* NEXT  */
  YYSYMBOL_PREVIOUS = 24,                  /* PREVIOUS  */
  YYSYMBOL_TOLAST = 25,                    /* TOLAST  */
  YYSYMBOL_FROMLAST = 26,                  /* FROMLAST  */
  YYSYMBOL_WR = 27,                        /* WR  */
  YYSYMBOL_AR = 28,                        /* AR  */
  YYSYMBOL_UR = 29,                        /* UR  */
  YYSYMBOL_SEMICOLON = 30,                 /* SEMICOLON  */
  YYSYMBOL_BERTLV = 31,                    /* BERTLV  */
  YYSYMBOL_APPL = 32,                      /* APPL  */
  YYSYMBOL_STLV = 33,                      /* STLV  */
  YYSYMBOL_BER2TLV = 34,                   /* BER2TLV  */
  YYSYMBOL_GD = 35,                        /* GD  */
  YYSYMBOL_PD = 36,                        /* PD  */
  YYSYMBOL_GRD = 37,                       /* GRD  */
  YYSYMBOL_SRD = 38,                       /* SRD  */
  YYSYMBOL_VERIFY = 39,                    /* VERIFY  */
  YYSYMBOL_IAUTH = 40,                     /* IAUTH  */
  YYSYMBOL_CHALLENGE = 41,                 /* CHALLENGE  */
  YYSYMBOL_EAUTH = 42,                     /* EAUTH  */
  YYSYMBOL_CHALLRESP = 43,                 /* CHALLRESP  */
  YYSYMBOL_GETC = 44,                      /* GETC  */
  YYSYMBOL_GETR = 45,                      /* GETR  */
  YYSYMBOL_MSESET = 46,                    /* MSESET  */
  YYSYMBOL_MSESTORE = 47,                  /* MSESTORE  */
  YYSYMBOL_MSERESTORE = 48,                /* MSERESTORE  */
  YYSYMBOL_MSEERASE = 49,                  /* MSEERASE  */
  YYSYMBOL_PSO = 50,                       /* PSO  */
  YYSYMBOL_CCC = 51,                       /* CCC  */
  YYSYMBOL_ENCIPHER = 52,                  /* ENCIPHER  */
  YYSYMBOL_DECIPHER = 53,                  /* DECIPHER  */
  YYSYMBOL_HASH = 54,                      /* HASH  */
  YYSYMBOL_COMPUTE_DIG_SIG = 55,           /* COMPUTE_DIG_SIG  */
  YYSYMBOL_VERIFY_DIG_SIG = 56,            /* VERIFY_DIG_SIG  */
  YYSYMBOL_VERIFY_CERT = 57,               /* VERIFY_CERT  */
  YYSYMBOL_EVR = 58,                       /* EVR  */
  YYSYMBOL_DATA = 59,                      /* DATA  */
  YYSYMBOL_DVR = 60,                       /* DVR  */
  YYSYMBOL_RRC = 61,                       /* RRC  */
  YYSYMBOL_RCODE = 62,                     /* RCODE  */
  YYSYMBOL_DFNAME = 63,                    /* DFNAME  */
  YYSYMBOL_CDF = 64,                       /* CDF  */
  YYSYMBOL_CEF = 65,                       /* CEF  */
  YYSYMBOL_PDF = 66,                       /* PDF  */
  YYSYMBOL_MF = 67,                        /* MF  */
  YYSYMBOL_MFPATH = 68,                    /* MFPATH  */
  YYSYMBOL_FCP = 69,                       /* FCP  */
  YYSYMBOL_FCI = 70,                       /* FCI  */
  YYSYMBOL_FMD = 71,                       /* FMD  */
  YYSYMBOL_SF = 72,                        /* SF  */
  YYSYMBOL_DF = 73,                        /* DF  */
  YYSYMBOL_DAF = 74,                       /* DAF  */
  YYSYMBOL_AF = 75,                        /* AF  */
  YYSYMBOL_TERMDF = 76,                    /* TERMDF  */
  YYSYMBOL_TERMEF = 77,                    /* TERMEF  */
  YYSYMBOL_VCC = 78,                       /* VCC  */
  YYSYMBOL_CRD = 79,                       /* CRD  */
  YYSYMBOL_OLDDATA = 80,                   /* OLDDATA  */
  YYSYMBOL_NEWDATA = 81,                   /* NEWDATA  */
  YYSYMBOL_NRD = 82,                       /* NRD  */
  YYSYMBOL_CDFPATH = 83,                   /* CDFPATH  */
  YYSYMBOL_MAUTH = 84,                     /* MAUTH  */
  YYSYMBOL_CREATEFILE = 85,                /* CREATEFILE  */
  YYSYMBOL_SE = 86,                        /* SE  */
  YYSYMBOL_SEFILE = 87,                    /* SEFILE  */
  YYSYMBOL_INTERNAL = 88,                  /* INTERNAL  */
  YYSYMBOL_WORKING = 89,                   /* WORKING  */
  YYSYMBOL_TRANSPARENT = 90,               /* TRANSPARENT  */
  YYSYMBOL_FILESIZE = 91,                  /* FILESIZE  */
  YYSYMBOL_FIXEDLENGTH = 92,               /* FIXEDLENGTH  */
  YYSYMBOL_VARLENGTH = 93,                 /* VARLENGTH  */
  YYSYMBOL_CYCLIC = 94,                    /* CYCLIC  */
  YYSYMBOL_MNR = 95,                       /* MNR  */
  YYSYMBOL_MRL = 96,                       /* MRL  */
  YYSYMBOL_SIMPLETLV = 97,                 /* SIMPLETLV  */
  YYSYMBOL_DATACODING = 98,                /* DATACODING  */
  YYSYMBOL_FILEID = 99,                    /* FILEID  */
  YYSYMBOL_WRITE_OR = 100,                 /* WRITE_OR  */
  YYSYMBOL_WRITE_ONCE = 101,               /* WRITE_ONCE  */
  YYSYMBOL_WRITE_AND = 102,                /* WRITE_AND  */
  YYSYMBOL_LCSI = 103,                     /* LCSI  */
  YYSYMBOL_CDA = 104,                      /* CDA  */
  YYSYMBOL_VEA = 105,                      /* VEA  */
  YYSYMBOL_COMPACT_ATTR = 106,             /* COMPACT_ATTR  */
  YYSYMBOL_EXPANDED_ATTR = 107,            /* EXPANDED_ATTR  */
  YYSYMBOL_CAPDU = 108,                    /* CAPDU  */
  YYSYMBOL_CLA = 109,                      /* CLA  */
  YYSYMBOL_INS = 110,                      /* INS  */
  YYSYMBOL_P1 = 111,                       /* P1  */
  YYSYMBOL_P2 = 112,                       /* P2  */
  YYSYMBOL_Lc = 113,                       /* Lc  */
  YYSYMBOL_Le = 114,                       /* Le  */
  YYSYMBOL_INDATA = 115,                   /* INDATA  */
  YYSYMBOL_RB = 116,                       /* RB  */
  YYSYMBOL_SFI = 117,                      /* SFI  */
  YYSYMBOL_CDAVEA = 118,                   /* CDAVEA  */
  YYSYMBOL_RESET = 119,                    /* RESET  */
  YYSYMBOL_EXPVAL = 120,                   /* EXPVAL  */
  YYSYMBOL_SM = 121,                       /* SM  */
  YYSYMBOL_RESPONSE = 122,                 /* RESPONSE  */
  YYSYMBOL_KEYVAL = 123,                   /* KEYVAL  */
  YYSYMBOL_ALGO = 124,                     /* ALGO  */
  YYSYMBOL_IV = 125,                       /* IV  */
  YYSYMBOL_SM_NULL = 126,                  /* SM_NULL  */
  YYSYMBOL_CHINCLUDE = 127,                /* CHINCLUDE  */
  YYSYMBOL_CDATA = 128,                    /* CDATA  */
  YYSYMBOL_CDATA_AUTH = 129,               /* CDATA_AUTH  */
  YYSYMBOL_PLAINDO = 130,                  /* PLAINDO  */
  YYSYMBOL_PLAINDO_AUTH = 131,             /* PLAINDO_AUTH  */
  YYSYMBOL_CRYPTODO = 132,                 /* CRYPTODO  */
  YYSYMBOL_CRYPTODO_AUTH = 133,            /* CRYPTODO_AUTH  */
  YYSYMBOL_ENCDATA = 134,                  /* ENCDATA  */
  YYSYMBOL_ENCDATA_AUTH = 135,             /* ENCDATA_AUTH  */
  YYSYMBOL_CH_AUTH = 136,                  /* CH_AUTH  */
  YYSYMBOL_LE = 137,                       /* LE  */
  YYSYMBOL_LE_AUTH = 138,                  /* LE_AUTH  */
  YYSYMBOL_STATUS = 139,                   /* STATUS  */
  YYSYMBOL_HASH_AUTH = 140,                /* HASH_AUTH  */
  YYSYMBOL_CC = 141,                       /* CC  */
  YYSYMBOL_DO = 142,                       /* DO  */
  YYSYMBOL_143_ = 143,                     /* '('  */
  YYSYMBOL_144_ = 144,                     /* ')'  */
  YYSYMBOL_145_ = 145,                     /* '='  */
  YYSYMBOL_YYACCEPT = 146,                 /* $accept  */
  YYSYMBOL_testsuite = 147,                /* testsuite  */
  YYSYMBOL_command = 148,                  /* command  */
  YYSYMBOL_isocommand = 149,               /* isocommand  */
  YYSYMBOL_statusenq = 150,                /* statusenq  */
  YYSYMBOL_expval = 151,                   /* expval  */
  YYSYMBOL_value = 152,                    /* value  */
  YYSYMBOL_string = 153,                   /* string  */
  YYSYMBOL_readbinary = 154,               /* readbinary  */
  YYSYMBOL_writebinary = 155,              /* writebinary  */
  YYSYMBOL_updatebinary = 156,             /* updatebinary  */
  YYSYMBOL_eb = 157,                       /* eb  */
  YYSYMBOL_erasebinary = 158,              /* erasebinary  */
  YYSYMBOL_rr = 159,                       /* rr  */
  YYSYMBOL_rtype = 160,                    /* rtype  */
  YYSYMBOL_recordopt = 161,                /* recordopt  */
  YYSYMBOL_readrecord = 162,               /* readrecord  */
  YYSYMBOL_wr = 163,                       /* wr  */
  YYSYMBOL_writerecord = 164,              /* writerecord  */
  YYSYMBOL_appendrecord = 165,             /* appendrecord  */
  YYSYMBOL_ur = 166,                       /* ur  */
  YYSYMBOL_updaterecord = 167,             /* updaterecord  */
  YYSYMBOL_tagtype = 168,                  /* tagtype  */
  YYSYMBOL_getdata = 169,                  /* getdata  */
  YYSYMBOL_putdata = 170,                  /* putdata  */
  YYSYMBOL_rdtype = 171,                   /* rdtype  */
  YYSYMBOL_verify = 172,                   /* verify  */
  YYSYMBOL_iauth = 173,                    /* iauth  */
  YYSYMBOL_eauth = 174,                    /* eauth  */
  YYSYMBOL_mauth = 175,                    /* mauth  */
  YYSYMBOL_getc = 176,                     /* getc  */
  YYSYMBOL_getr = 177,                     /* getr  */
  YYSYMBOL_mseopt = 178,                   /* mseopt  */
  YYSYMBOL_mseset = 179,                   /* mseset  */
  YYSYMBOL_msestore = 180,                 /* msestore  */
  YYSYMBOL_mserestore = 181,               /* mserestore  */
  YYSYMBOL_mseerase = 182,                 /* mseerase  */
  YYSYMBOL_psoop = 183,                    /* psoop  */
  YYSYMBOL_pso = 184,                      /* pso  */
  YYSYMBOL_crdopt = 185,                   /* crdopt  */
  YYSYMBOL_crd = 186,                      /* crd  */
  YYSYMBOL_evr = 187,                      /* evr  */
  YYSYMBOL_dvr = 188,                      /* dvr  */
  YYSYMBOL_rrc = 189,                      /* rrc  */
  YYSYMBOL_file = 190,                     /* file  */
  YYSYMBOL_finfo = 191,                    /* finfo  */
  YYSYMBOL_selectfile = 192,               /* selectfile  */
  YYSYMBOL_deletefile = 193,               /* deletefile  */
  YYSYMBOL_daf = 194,                      /* daf  */
  YYSYMBOL_af = 195,                       /* af  */
  YYSYMBOL_termdf = 196,                   /* termdf  */
  YYSYMBOL_termef = 197,                   /* termef  */
  YYSYMBOL_cfprefix = 198,                 /* cfprefix  */
  YYSYMBOL_createfile = 199,               /* createfile  */
  YYSYMBOL_df = 200,                       /* df  */
  YYSYMBOL_eftype = 201,                   /* eftype  */
  YYSYMBOL_record = 202,                   /* record  */
  YYSYMBOL_ef = 203,                       /* ef  */
  YYSYMBOL_datacode = 204,                 /* datacode  */
  YYSYMBOL_apdu = 205,                     /* apdu  */
  YYSYMBOL_reset = 206,                    /* reset  */
  YYSYMBOL_smspec = 207,                   /* smspec  */
  YYSYMBOL_taglist = 208,                  /* taglist  */
  YYSYMBOL_tag = 209,                      /* tag  */
  YYSYMBOL_cryptospec = 210,               /* cryptospec  */
  YYSYMBOL_cryptoitemlist = 211,           /* cryptoitemlist  */
  YYSYMBOL_cryptoitem = 212                /* cryptoitem  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  166
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1007

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  146
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  67
/* YYNRULES -- Number of rules.  */
#define YYNRULES  221
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  569

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   397


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     143,   144,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,   145,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,   136,   137,   138,   139,   140,   141,   142
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   115,   115,   116,   119,   125,   126,   127,   128,   129,
     130,   131,   132,   133,   134,   135,   140,   141,   142,   143,
     144,   145,   146,   147,   148,   149,   150,   151,   152,   153,
     158,   159,   160,   165,   166,   167,   168,   169,   175,   176,
     180,   183,   199,   203,   207,   213,   223,   229,   235,   244,
     258,   259,   263,   269,   281,   291,   302,   310,   320,   328,
     338,   342,   350,   355,   364,   368,   375,   379,   386,   390,
     394,   398,   402,   406,   413,   421,   432,   436,   444,   451,
     461,   468,   476,   480,   488,   495,   503,   507,   511,   515,
     522,   532,   541,   545,   552,   558,   567,   575,   587,   594,
     605,   614,   624,   633,   643,   651,   663,   670,   681,   689,
     693,   697,   703,   712,   720,   728,   736,   742,   748,   754,
     760,   766,   772,   779,   789,   795,   804,   808,   814,   822,
     829,   834,   842,   847,   855,   863,   869,   877,   882,   887,
     892,   896,   900,   906,   913,   917,   921,   928,   933,   939,
     949,   957,   962,   968,   978,   983,   989,   999,  1004,  1010,
    1020,  1025,  1031,  1041,  1049,  1058,  1067,  1072,  1077,  1085,
    1091,  1096,  1101,  1109,  1113,  1121,  1125,  1129,  1136,  1145,
    1157,  1169,  1174,  1181,  1185,  1189,  1196,  1206,  1215,  1224,
    1233,  1242,  1251,  1260,  1272,  1281,  1320,  1328,  1344,  1352,
    1360,  1368,  1376,  1384,  1392,  1399,  1406,  1413,  1420,  1428,
    1436,  1444,  1452,  1460,  1467,  1475,  1486,  1497,  1501,  1518,
    1524,  1530
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "STRING", "CVARIABLE",
  "HEXSTR", "VALUE", "X", "C", "ISEQUAL", "ISNOTEQUAL", "OK", "SW", "ERR",
  "ANY", "WB", "UB", "EB", "RR", "RNO", "RID", "FIRST", "LAST", "NEXT",
  "PREVIOUS", "TOLAST", "FROMLAST", "WR", "AR", "UR", "SEMICOLON",
  "BERTLV", "APPL", "STLV", "BER2TLV", "GD", "PD", "GRD", "SRD", "VERIFY",
  "IAUTH", "CHALLENGE", "EAUTH", "CHALLRESP", "GETC", "GETR", "MSESET",
  "MSESTORE", "MSERESTORE", "MSEERASE", "PSO", "CCC", "ENCIPHER",
  "DECIPHER", "HASH", "COMPUTE_DIG_SIG", "VERIFY_DIG_SIG", "VERIFY_CERT",
  "EVR", "DATA", "DVR", "RRC", "RCODE", "DFNAME", "CDF", "CEF", "PDF",
  "MF", "MFPATH", "FCP", "FCI", "FMD", "SF", "DF", "DAF", "AF", "TERMDF",
  "TERMEF", "VCC", "CRD", "OLDDATA", "NEWDATA", "NRD", "CDFPATH", "MAUTH",
  "CREATEFILE", "SE", "SEFILE", "INTERNAL", "WORKING", "TRANSPARENT",
  "FILESIZE", "FIXEDLENGTH", "VARLENGTH", "CYCLIC", "MNR", "MRL",
  "SIMPLETLV", "DATACODING", "FILEID", "WRITE_OR", "WRITE_ONCE",
  "WRITE_AND", "LCSI", "CDA", "VEA", "COMPACT_ATTR", "EXPANDED_ATTR",
  "CAPDU", "CLA", "INS", "P1", "P2", "Lc", "Le", "INDATA", "RB", "SFI",
  "CDAVEA", "RESET", "EXPVAL", "SM", "RESPONSE", "KEYVAL", "ALGO", "IV",
  "SM_NULL", "CHINCLUDE", "CDATA", "CDATA_AUTH", "PLAINDO", "PLAINDO_AUTH",
  "CRYPTODO", "CRYPTODO_AUTH", "ENCDATA", "ENCDATA_AUTH", "CH_AUTH", "LE",
  "LE_AUTH", "STATUS", "HASH_AUTH", "CC", "DO", "'('", "')'", "'='",
  "$accept", "testsuite", "command", "isocommand", "statusenq", "expval",
  "value", "string", "readbinary", "writebinary", "updatebinary", "eb",
  "erasebinary", "rr", "rtype", "recordopt", "readrecord", "wr",
  "writerecord", "appendrecord", "ur", "updaterecord", "tagtype",
  "getdata", "putdata", "rdtype", "verify", "iauth", "eauth", "mauth",
  "getc", "getr", "mseopt", "mseset", "msestore", "mserestore", "mseerase",
  "psoop", "pso", "crdopt", "crd", "evr", "dvr", "rrc", "file", "finfo",
  "selectfile", "deletefile", "daf", "af", "termdf", "termef", "cfprefix",
  "createfile", "df", "eftype", "record", "ef", "datacode", "apdu",
  "reset", "smspec", "taglist", "tag", "cryptospec", "cryptoitemlist",
  "cryptoitem", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-215)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-1)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     886,     0,    24,  -107,   -67,   -62,    29,   -37,   201,   201,
      73,   -39,   -17,    16,    62,   -35,    62,    62,    62,     8,
      73,    73,    73,    93,    93,    93,    93,    93,    93,    31,
      -9,   -11,  -215,    30,  -215,   851,   119,   886,   124,  -215,
    -215,  -215,    62,  -215,    84,  -215,   173,  -215,  -215,   226,
    -215,  -215,  -215,  -215,  -215,  -215,  -215,  -215,  -215,  -215,
    -215,  -215,  -215,  -215,     9,  -215,  -215,     5,  -215,  -215,
    -215,  -215,  -215,  -215,   -31,     6,    71,  -215,  -215,  -215,
    -215,    18,   146,    42,   146,    48,    55,    64,  -215,    26,
      97,   206,   108,  -215,  -215,  -215,  -215,    62,    62,  -215,
    -215,   114,   115,   120,   121,   109,   109,  -215,  -215,  -215,
      62,   206,   206,   206,   146,   146,   146,   146,   146,   146,
     146,   146,     1,   122,   123,   125,   126,   129,   131,  -215,
    -215,   132,   133,   202,   202,   202,   202,   202,   202,  -215,
    -215,    73,   135,   137,   138,    62,   142,  -215,  -215,  -215,
    -215,   147,   150,   162,   164,   165,   166,  -215,  -215,  -215,
    -215,   167,   168,   169,   709,  -215,  -215,  -215,  -215,    37,
    -215,  -215,   170,   172,  -215,  -215,  -215,  -215,  -215,  -215,
     146,   175,   146,   260,   176,  -215,   177,   178,  -215,  -215,
    -215,  -215,   -34,    72,   -63,   179,   180,   187,  -215,   189,
     190,   193,   195,   196,   198,   200,   248,   206,    62,   206,
      62,   206,    62,    62,    62,    62,    62,  -215,    62,    62,
     146,    62,    62,    62,    62,   206,   206,   146,  -215,  -215,
    -215,  -215,    62,    62,  -215,  -215,  -215,  -215,  -215,   206,
     109,    62,    62,    62,   146,    62,    62,   146,   146,     7,
     206,     7,     7,     7,     7,   209,    62,    62,    62,   109,
     157,   851,   851,   -79,   -79,   -79,   -79,   194,   -79,   146,
     851,  -215,  -215,   206,    62,    62,   206,    62,   206,    68,
     146,    62,   146,   211,   212,   213,   222,  -215,  -215,  -215,
     197,   214,   215,    62,   146,   146,    62,    62,    62,    62,
      62,    62,   146,    70,   174,  -215,    62,  -215,    62,  -215,
    -215,  -215,  -215,   203,   146,  -215,   109,   206,   102,    73,
      73,    62,  -215,  -215,   206,  -215,  -215,  -215,   206,    13,
      25,  -215,  -215,  -215,  -215,  -215,  -215,  -215,  -215,  -215,
    -215,     1,  -215,  -215,     1,  -215,     1,  -215,     1,  -215,
       1,    62,    73,  -215,    62,   206,   216,   282,   383,   217,
     218,   219,   851,  -215,   -79,   851,   207,   221,   223,   225,
     228,    -3,  -215,   149,   146,  -215,   146,  -215,  -215,  -215,
    -215,  -215,  -215,  -215,  -215,   146,   146,    62,   229,   230,
     136,    62,  -215,  -215,  -215,  -215,  -215,  -215,  -215,  -215,
    -215,  -215,  -215,  -215,  -215,  -215,   146,   146,  -215,   206,
     206,  -215,  -215,   206,   231,   232,   109,  -215,  -215,   233,
    -215,   234,  -215,   206,   109,   206,   109,   206,   109,   206,
     109,   206,   109,   285,   235,    62,  -215,   311,  -215,  -215,
     146,   364,   146,   555,  -215,   576,  -215,  -215,   367,  -215,
    -215,  -215,   109,    62,   206,   206,  -215,  -215,  -215,    62,
      62,  -215,  -215,  -215,  -215,  -215,   206,   206,  -215,  -215,
    -215,    62,    62,   206,   146,   146,  -215,   206,  -215,   206,
    -215,   206,  -215,   206,  -215,   206,   236,    62,   109,   238,
    -215,  -215,  -215,  -215,  -215,   239,   206,   109,  -215,  -215,
    -215,   277,  -215,  -215,   343,    20,  -215,   206,   206,  -215,
    -215,  -215,  -215,  -215,   146,    75,   206,  -215,  -215,  -215,
     206,   241,   242,   243,   206,  -215,  -215,  -215,   245,   246,
    -215,  -215,    62,   146,   146,  -215,   146,   146,   295,     1,
     206,    23,     1,  -215,   206,   109,  -215,   251,     1,   206,
     109,  -215,   206,   146,   206,   109,  -215,   206,  -215,     1,
    -215,   206,  -215,   206,   109,  -215,  -215,   206,  -215
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       2,     0,     0,    60,    64,    76,     0,    82,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   186,     0,   194,     0,     0,     2,     0,     5,
       6,     7,     0,     8,     0,    10,     0,     9,    11,     0,
      12,    34,    35,    20,    21,    22,    23,    33,    36,    24,
      25,    26,    27,    28,    40,    30,    31,    40,    13,    14,
      19,    18,    16,    17,     0,    40,    45,    39,    38,    51,
      50,     0,     0,     0,     0,     0,     0,     0,    52,     0,
       0,    40,     0,    86,    87,    88,    89,     0,     0,    92,
      93,     0,     0,     0,     0,    45,    45,   109,   110,   111,
       0,    40,    40,    40,     0,     0,     0,     0,     0,     0,
       0,     0,    45,     0,     0,     0,     0,     0,     0,   140,
     141,     0,     0,     0,     0,     0,     0,     0,     0,   126,
     127,     0,     0,     0,     0,     0,     0,   198,   199,   200,
     201,     0,     0,     0,     0,     0,     0,   208,   209,   210,
     215,     0,     0,     0,     0,   196,     1,     3,     4,    40,
      66,    67,     0,     0,    68,    69,    70,    71,    72,    73,
       0,     0,     0,     0,     0,    29,     0,     0,    32,   169,
     173,   174,   164,     0,   165,     0,     0,     0,    15,     0,
       0,     0,     0,     0,     0,     0,     0,    40,     0,    40,
       0,    40,     0,     0,     0,     0,     0,    81,     0,     0,
       0,     0,     0,     0,     0,    40,    40,     0,   113,   114,
     115,   116,     0,     0,   118,   119,   120,   121,   117,    40,
      45,     0,     0,     0,     0,     0,     0,     0,     0,    40,
      40,    40,    40,    40,    40,     0,     0,     0,     0,    45,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   197,    62,    40,     0,     0,    40,     0,    40,     0,
       0,     0,     0,     0,     0,     0,     0,   175,   176,   177,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    37,     0,    57,     0,    59,
      61,    65,    77,     0,     0,    83,    45,    40,    40,     0,
       0,     0,   106,   108,    40,   122,   123,   124,    40,    40,
      40,   134,   137,   138,   139,   142,   143,   144,   145,   146,
     147,    45,   150,   151,    45,   154,    45,   157,    45,   160,
      45,     0,     0,   163,     0,    40,     0,     0,     0,     0,
       0,     0,     0,   216,   217,     0,     0,     0,     0,     0,
       0,    40,    63,     0,     0,    79,     0,    85,    41,    43,
      42,    44,   129,   135,   136,     0,     0,     0,     0,     0,
       0,     0,   166,   167,   168,   187,   188,   189,   190,   191,
     192,   193,    48,    46,    49,    47,     0,     0,    53,    40,
      40,    91,    94,    40,     0,     0,    45,   112,   125,     0,
     130,     0,   132,    40,    45,    40,    45,    40,    45,    40,
      45,    40,    45,     0,     0,     0,    55,     0,   202,   203,
       0,     0,     0,     0,   218,     0,   206,   207,     0,   213,
     214,   195,    45,     0,    40,    40,   170,   171,   172,     0,
       0,   183,   185,   184,   182,   181,    40,    40,    80,    90,
      95,     0,     0,    40,     0,     0,   148,    40,   152,    40,
     155,    40,   158,    40,   161,    40,     0,     0,    45,     0,
     219,   221,   220,   204,   205,     0,    40,    45,    78,    84,
     178,     0,    56,    58,     0,     0,   107,    40,    40,   149,
     153,   156,   159,   162,     0,     0,    40,   211,   212,    74,
      40,     0,     0,     0,    40,   131,   133,   128,     0,     0,
      54,    75,     0,     0,     0,    98,     0,     0,   179,    45,
      40,     0,    45,   180,    40,    45,    99,     0,    45,    40,
      45,    96,    40,     0,    40,    45,   104,    40,    97,    45,
     100,    40,   105,    40,    45,   101,   102,    40,   103
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -215,   356,  -215,  -215,    77,   330,    -2,   359,  -215,  -215,
    -215,  -215,  -215,  -215,  -215,   -36,  -215,  -215,  -215,  -215,
    -215,  -215,   388,  -215,  -215,   -19,  -215,  -215,  -215,  -215,
    -215,  -215,  -215,  -215,  -215,  -215,  -215,  -215,  -215,  -215,
    -215,  -215,  -215,  -215,    66,    10,  -215,  -215,  -215,  -215,
    -215,  -215,  -215,  -215,  -215,  -215,  -215,  -215,  -215,  -215,
    -215,  -215,  -214,  -156,   -61,    34,  -215
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,    36,    37,    38,   185,   207,    82,    91,    39,    40,
      41,    42,    43,    44,   172,   180,    45,    46,    47,    48,
      49,    50,    97,    51,    52,   101,    53,    54,    55,    56,
      57,    58,   110,    59,    60,    61,    62,   122,    63,   141,
      64,    65,    66,    67,   133,   341,    68,    69,    70,    71,
      72,    73,    74,    75,   192,   193,   290,   194,   464,    76,
      77,    78,   164,   165,   362,   363,   364
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      84,   123,   124,   125,    79,    79,    80,    80,   271,   183,
      85,   105,   106,   182,   111,   112,   113,   183,   183,   183,
      79,   183,    80,    88,    89,   183,    88,    89,    79,   283,
      80,   145,    88,    89,    79,   291,    80,   183,   139,   140,
     169,    79,   189,    80,   359,   360,   361,   357,   358,   183,
      86,   146,   284,   285,   292,    87,   371,   190,   191,   114,
     115,   116,   117,   118,   119,   120,    79,   186,    80,   107,
     108,   378,   419,    88,    89,   402,   337,   338,   339,   379,
      92,   380,   381,   109,   421,   102,   121,   187,   143,   184,
     134,   135,   136,   137,   138,   219,   220,   249,   250,   251,
     252,   253,   254,   170,   171,    88,    89,   103,   227,   195,
      99,   100,   196,   197,   183,   142,   528,    81,   529,   166,
     240,   206,   255,   147,   148,   149,   150,   151,   152,   153,
     154,   155,   156,   157,   158,   159,   160,   161,   162,   163,
     104,    83,   523,   259,   188,   547,    90,   144,   443,    88,
      89,   445,   198,    79,   168,    80,   126,   127,   128,   129,
     130,   131,   286,   208,   287,   288,   289,   273,   217,   215,
     174,   175,   176,   177,   178,   179,   132,    88,    89,   404,
     199,   200,   201,   202,   203,   204,   205,   210,   228,   229,
     230,   206,   173,   212,   174,   175,   176,   177,   178,   179,
     213,   271,   271,   365,   366,   367,   306,   369,   308,   214,
     310,   311,   312,   313,   314,   271,   315,   316,   183,   318,
     319,   320,   321,   174,   175,   176,   177,   178,   179,   206,
     325,   326,    93,    94,    95,    96,   461,   462,   463,   329,
     330,   331,   216,   333,   334,   181,   272,   174,   175,   176,
     177,   178,   179,   218,   352,   353,   354,   303,   304,   221,
     222,   344,   346,   348,   350,   223,   224,   241,   242,   279,
     243,   244,   373,   374,   245,   376,   246,   247,   248,   383,
     256,   356,   257,   258,   305,   260,   307,   271,   309,   271,
     261,   392,   389,   262,   395,   396,   397,   398,   399,   400,
     414,   415,   322,   323,   406,   263,   407,   264,   265,   266,
     267,   268,   269,   388,   489,   274,   327,   275,   368,   416,
     277,   280,   281,   282,   293,   294,   340,   342,   343,   345,
     347,   349,   295,   434,   296,   297,   146,   453,   298,   424,
     299,   300,   426,   301,   428,   302,   430,   408,   432,   433,
     372,   446,   435,   375,   351,   377,   385,   386,   387,   390,
     391,   437,   440,   441,   442,   447,   486,   491,   448,   449,
     495,   452,   450,   521,   459,   460,   471,   472,   474,   475,
     487,   514,   517,   518,   522,   458,   532,   533,   534,   465,
     536,   537,   543,   167,   411,   412,   553,    98,   444,     0,
       0,   417,     0,     0,     0,   418,   420,   422,   147,   148,
     149,   150,   151,   152,   153,   154,   155,   156,   157,   158,
     159,   160,   161,   162,   163,     0,   438,     0,     0,     0,
       0,     0,   436,   488,     0,   225,   226,   146,     0,     0,
       0,   209,     0,   211,     0,     0,     0,     0,   451,     0,
       0,   497,   239,     0,     0,     0,     0,   500,   501,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   504,
     505,     0,     0,   231,   232,   233,   234,   235,   236,   237,
     238,     0,     0,     0,     0,   515,   468,   469,     0,     0,
     470,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     476,     0,   478,     0,   480,     0,   482,     0,   484,   147,
     148,   149,   150,   151,   152,   153,   154,   155,   156,   157,
     158,   159,   160,   161,   162,   163,     0,   439,     0,     0,
     538,   498,   499,     0,     0,     0,     0,   545,     0,   276,
     550,   278,     0,   502,   503,     0,   555,     0,     0,     0,
     506,     0,     0,     0,   509,     0,   510,   564,   511,     0,
     512,     0,   513,     0,     0,     0,     0,     0,     0,     0,
     328,     0,     0,   519,     0,     0,     0,     0,     0,   317,
       0,     0,     0,     0,   525,   526,   324,     0,     0,   355,
       0,     0,     0,   530,     0,     0,     0,   531,     0,     0,
       0,   535,     0,   332,     0,     0,   335,   336,     0,   146,
       0,     0,     0,     0,     0,     0,     0,   546,     0,     0,
       0,   551,     0,     0,     0,     0,   556,     0,   370,   558,
     146,   560,     0,     0,   562,     0,     0,     0,   565,   382,
     566,   384,     0,     0,   568,     0,   410,     0,     0,     0,
       0,     0,     0,   393,   394,     0,     0,     0,     0,     0,
       0,   401,   403,   405,     0,     0,     0,     0,     0,     0,
       0,   423,     0,   409,   425,     0,   427,   413,   429,     0,
     431,   147,   148,   149,   150,   151,   152,   153,   154,   155,
     156,   157,   158,   159,   160,   161,   162,   163,     0,   493,
       0,     0,   147,   148,   149,   150,   151,   152,   153,   154,
     155,   156,   157,   158,   159,   160,   161,   162,   163,     0,
     494,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   454,     0,   455,     0,     0,     0,     0,
       0,     0,     0,     0,   456,   457,   473,     0,     0,     0,
       0,     0,     0,     0,   477,     0,   479,     0,   481,     0,
     483,     0,   485,   146,     0,   466,   467,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   496,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   490,
       0,   492,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   516,     0,
       0,     0,     0,     0,     0,     0,     0,   520,     0,     0,
       0,   270,     0,   507,   508,   147,   148,   149,   150,   151,
     152,   153,   154,   155,   156,   157,   158,   159,   160,   161,
     162,   163,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   524,     0,     0,     0,     0,   544,
       0,     0,   549,   527,     0,   552,     0,     0,   554,     0,
     557,     0,     0,     0,     0,   561,     0,     0,     0,   563,
       0,     0,   539,   540,   567,   541,   542,     0,     0,     0,
     548,     1,     2,     3,     4,   146,     0,     0,     0,     0,
       0,     0,   559,     5,     6,     7,     0,     0,     0,     0,
       0,     8,     9,     0,     0,    10,    11,     0,    12,     0,
      13,    14,    15,    16,    17,    18,    19,     0,     0,     0,
       0,     0,     0,     0,    20,     0,    21,    22,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    23,    24,
      25,    26,    27,    28,     0,    29,     0,     0,     0,     0,
      30,    31,     0,     0,     0,     0,     0,   147,   148,   149,
     150,   151,   152,   153,   154,   155,   156,   157,   158,   159,
     160,   161,   162,   163,    32,     0,     0,     0,     0,     0,
       0,     0,    33,     0,     0,    34,     0,    35
};

static const yytype_int16 yycheck[] =
{
       2,    20,    21,    22,     4,     4,     6,     6,   164,    12,
     117,    13,    14,    49,    16,    17,    18,    12,    12,    12,
       4,    12,     6,     3,     4,    12,     3,     4,     4,    63,
       6,    33,     3,     4,     4,    98,     6,    12,     7,     8,
      42,     4,    73,     6,   123,   124,   125,   261,   262,    12,
     117,    54,    86,    87,   117,   117,   270,    88,    89,    51,
      52,    53,    54,    55,    56,    57,     4,    62,     6,   104,
     105,     3,    59,     3,     4,     5,    69,    70,    71,    11,
     117,    13,    14,   118,    59,   124,    78,    82,    99,    80,
      24,    25,    26,    27,    28,    97,    98,   133,   134,   135,
     136,   137,   138,    19,    20,     3,     4,   124,   110,   103,
      37,    38,   106,   107,    12,   124,    41,   117,    43,     0,
     122,   120,   141,   126,   127,   128,   129,   130,   131,   132,
     133,   134,   135,   136,   137,   138,   139,   140,   141,   142,
     124,   117,   122,   145,    67,   122,   117,   117,   362,     3,
       4,   365,    75,     4,    30,     6,    63,    64,    65,    66,
      67,    68,    90,   145,    92,    93,    94,   169,    91,   143,
      21,    22,    23,    24,    25,    26,    83,     3,     4,     5,
     109,   110,   111,   112,   113,   114,   115,   145,   111,   112,
     113,   120,    19,   145,    21,    22,    23,    24,    25,    26,
     145,   357,   358,   264,   265,   266,   208,   268,   210,   145,
     212,   213,   214,   215,   216,   371,   218,   219,    12,   221,
     222,   223,   224,    21,    22,    23,    24,    25,    26,   120,
     232,   233,    31,    32,    33,    34,   100,   101,   102,   241,
     242,   243,   145,   245,   246,    19,   169,    21,    22,    23,
      24,    25,    26,   145,   256,   257,   258,     9,    10,   145,
     145,   251,   252,   253,   254,   145,   145,   145,   145,     9,
     145,   145,   274,   275,   145,   277,   145,   145,   145,   281,
     145,   124,   145,   145,   207,   143,   209,   443,   211,   445,
     143,   293,    95,   143,   296,   297,   298,   299,   300,   301,
     319,   320,   225,   226,   306,   143,   308,   143,   143,   143,
     143,   143,   143,    91,     3,   145,   239,   145,   124,   321,
     145,   145,   145,   145,   145,   145,   249,   250,   251,   252,
     253,   254,   145,   352,   145,   145,    54,   373,   145,   341,
     145,   145,   344,   145,   346,   145,   348,   144,   350,   351,
     273,   144,   354,   276,   145,   278,   145,   145,   145,   145,
     145,   145,   145,   145,   145,   144,    81,     3,   145,   144,
       3,   373,   144,    96,   145,   145,   145,   145,   145,   145,
     145,   145,   144,   144,    41,   387,   145,   145,   145,   391,
     145,   145,    97,    37,   317,   318,   145,     9,   364,    -1,
      -1,   324,    -1,    -1,    -1,   328,   329,   330,   126,   127,
     128,   129,   130,   131,   132,   133,   134,   135,   136,   137,
     138,   139,   140,   141,   142,    -1,   144,    -1,    -1,    -1,
      -1,    -1,   355,   435,    -1,   105,   106,    54,    -1,    -1,
      -1,    82,    -1,    84,    -1,    -1,    -1,    -1,   371,    -1,
      -1,   453,   122,    -1,    -1,    -1,    -1,   459,   460,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   471,
     472,    -1,    -1,   114,   115,   116,   117,   118,   119,   120,
     121,    -1,    -1,    -1,    -1,   487,   409,   410,    -1,    -1,
     413,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     423,    -1,   425,    -1,   427,    -1,   429,    -1,   431,   126,
     127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
     137,   138,   139,   140,   141,   142,    -1,   144,    -1,    -1,
     532,   454,   455,    -1,    -1,    -1,    -1,   539,    -1,   180,
     542,   182,    -1,   466,   467,    -1,   548,    -1,    -1,    -1,
     473,    -1,    -1,    -1,   477,    -1,   479,   559,   481,    -1,
     483,    -1,   485,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     240,    -1,    -1,   496,    -1,    -1,    -1,    -1,    -1,   220,
      -1,    -1,    -1,    -1,   507,   508,   227,    -1,    -1,   259,
      -1,    -1,    -1,   516,    -1,    -1,    -1,   520,    -1,    -1,
      -1,   524,    -1,   244,    -1,    -1,   247,   248,    -1,    54,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   540,    -1,    -1,
      -1,   544,    -1,    -1,    -1,    -1,   549,    -1,   269,   552,
      54,   554,    -1,    -1,   557,    -1,    -1,    -1,   561,   280,
     563,   282,    -1,    -1,   567,    -1,   316,    -1,    -1,    -1,
      -1,    -1,    -1,   294,   295,    -1,    -1,    -1,    -1,    -1,
      -1,   302,   303,   304,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   341,    -1,   314,   344,    -1,   346,   318,   348,    -1,
     350,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,   136,   137,   138,   139,   140,   141,   142,    -1,   144,
      -1,    -1,   126,   127,   128,   129,   130,   131,   132,   133,
     134,   135,   136,   137,   138,   139,   140,   141,   142,    -1,
     144,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   374,    -1,   376,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   385,   386,   416,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   424,    -1,   426,    -1,   428,    -1,
     430,    -1,   432,    54,    -1,   406,   407,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   452,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   440,
      -1,   442,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   488,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   497,    -1,    -1,
      -1,   122,    -1,   474,   475,   126,   127,   128,   129,   130,
     131,   132,   133,   134,   135,   136,   137,   138,   139,   140,
     141,   142,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   505,    -1,    -1,    -1,    -1,   539,
      -1,    -1,   542,   514,    -1,   545,    -1,    -1,   548,    -1,
     550,    -1,    -1,    -1,    -1,   555,    -1,    -1,    -1,   559,
      -1,    -1,   533,   534,   564,   536,   537,    -1,    -1,    -1,
     541,    15,    16,    17,    18,    54,    -1,    -1,    -1,    -1,
      -1,    -1,   553,    27,    28,    29,    -1,    -1,    -1,    -1,
      -1,    35,    36,    -1,    -1,    39,    40,    -1,    42,    -1,
      44,    45,    46,    47,    48,    49,    50,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    58,    -1,    60,    61,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    72,    73,
      74,    75,    76,    77,    -1,    79,    -1,    -1,    -1,    -1,
      84,    85,    -1,    -1,    -1,    -1,    -1,   126,   127,   128,
     129,   130,   131,   132,   133,   134,   135,   136,   137,   138,
     139,   140,   141,   142,   108,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   116,    -1,    -1,   119,    -1,   121
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    15,    16,    17,    18,    27,    28,    29,    35,    36,
      39,    40,    42,    44,    45,    46,    47,    48,    49,    50,
      58,    60,    61,    72,    73,    74,    75,    76,    77,    79,
      84,    85,   108,   116,   119,   121,   147,   148,   149,   154,
     155,   156,   157,   158,   159,   162,   163,   164,   165,   166,
     167,   169,   170,   172,   173,   174,   175,   176,   177,   179,
     180,   181,   182,   184,   186,   187,   188,   189,   192,   193,
     194,   195,   196,   197,   198,   199,   205,   206,   207,     4,
       6,   117,   152,   117,   152,   117,   117,   117,     3,     4,
     117,   153,   117,    31,    32,    33,    34,   168,   168,    37,
      38,   171,   124,   124,   124,   152,   152,   104,   105,   118,
     178,   152,   152,   152,    51,    52,    53,    54,    55,    56,
      57,    78,   183,   171,   171,   171,    63,    64,    65,    66,
      67,    68,    83,   190,   190,   190,   190,   190,   190,     7,
       8,   185,   124,    99,   117,   152,    54,   126,   127,   128,
     129,   130,   131,   132,   133,   134,   135,   136,   137,   138,
     139,   140,   141,   142,   208,   209,     0,   147,    30,   152,
      19,    20,   160,    19,    21,    22,    23,    24,    25,    26,
     161,    19,   161,    12,    80,   150,    62,    82,   150,    73,
      88,    89,   200,   201,   203,   103,   106,   107,   150,   109,
     110,   111,   112,   113,   114,   115,   120,   151,   145,   153,
     145,   153,   145,   145,   145,   143,   145,   150,   145,   152,
     152,   145,   145,   145,   145,   151,   151,   152,   150,   150,
     150,   153,   153,   153,   153,   153,   153,   153,   153,   151,
     152,   145,   145,   145,   145,   145,   145,   145,   145,   161,
     161,   161,   161,   161,   161,   171,   145,   145,   145,   152,
     143,   143,   143,   143,   143,   143,   143,   143,   143,   143,
     122,   209,   150,   152,   145,   145,   153,   145,   153,     9,
     145,   145,   145,    63,    86,    87,    90,    92,    93,    94,
     202,    98,   117,   145,   145,   145,   145,   145,   145,   145,
     145,   145,   145,     9,    10,   150,   152,   150,   152,   150,
     152,   152,   152,   152,   152,   152,   152,   153,   152,   152,
     152,   152,   150,   150,   153,   152,   152,   150,   151,   152,
     152,   152,   153,   152,   152,   153,   153,    69,    70,    71,
     150,   191,   150,   150,   191,   150,   191,   150,   191,   150,
     191,   145,   152,   152,   152,   151,   124,   208,   208,   123,
     124,   125,   210,   211,   212,   210,   210,   210,   124,   210,
     153,   208,   150,   152,   152,   150,   152,   150,     3,    11,
      13,    14,   153,   152,   153,   145,   145,   145,    91,    95,
     145,   145,   152,   153,   153,   152,   152,   152,   152,   152,
     152,   153,     5,   153,     5,   153,   152,   152,   144,   153,
     151,   150,   150,   153,   171,   171,   152,   150,   150,    59,
     150,    59,   150,   151,   152,   151,   152,   151,   152,   151,
     152,   151,   152,   152,   171,   152,   150,   145,   144,   144,
     145,   145,   145,   208,   211,   208,   144,   144,   145,   144,
     144,   150,   152,   161,   153,   153,   153,   153,   152,   145,
     145,   100,   101,   102,   204,   152,   153,   153,   150,   150,
     150,   145,   145,   151,   145,   145,   150,   151,   150,   151,
     150,   151,   150,   151,   150,   151,    81,   145,   152,     3,
     153,     3,   153,   144,   144,     3,   151,   152,   150,   150,
     152,   152,   150,   150,   152,   152,   150,   153,   153,   150,
     150,   150,   150,   150,   145,   152,   151,   144,   144,   150,
     151,    96,    41,   122,   153,   150,   150,   153,    41,    43,
     150,   150,   145,   145,   145,   150,   145,   145,   152,   153,
     153,   153,   153,    97,   151,   152,   150,   122,   153,   151,
     152,   150,   151,   145,   151,   152,   150,   151,   150,   153,
     150,   151,   150,   151,   152,   150,   150,   151,   150
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_uint8 yyr1[] =
{
       0,   146,   147,   147,   148,   149,   149,   149,   149,   149,
     149,   149,   149,   149,   149,   149,   149,   149,   149,   149,
     149,   149,   149,   149,   149,   149,   149,   149,   149,   149,
     149,   149,   149,   149,   149,   149,   149,   149,   149,   149,
     150,   150,   150,   150,   150,   151,   151,   151,   151,   151,
     152,   152,   153,   153,   154,   154,   155,   155,   156,   156,
     157,   157,   158,   158,   159,   159,   160,   160,   161,   161,
     161,   161,   161,   161,   162,   162,   163,   163,   164,   164,
     165,   165,   166,   166,   167,   167,   168,   168,   168,   168,
     169,   170,   171,   171,   172,   172,   173,   173,   174,   174,
     175,   175,   175,   175,   175,   175,   176,   176,   177,   178,
     178,   178,   179,   180,   181,   182,   183,   183,   183,   183,
     183,   183,   183,   183,   184,   184,   185,   185,   186,   186,
     187,   187,   188,   188,   189,   189,   189,   190,   190,   190,
     190,   190,   190,   190,   191,   191,   191,   192,   192,   192,
     193,   194,   194,   194,   195,   195,   195,   196,   196,   196,
     197,   197,   197,   198,   199,   199,   199,   199,   199,   200,
     200,   200,   200,   201,   201,   202,   202,   202,   203,   203,
     203,   203,   203,   204,   204,   204,   205,   205,   205,   205,
     205,   205,   205,   205,   206,   207,   208,   208,   209,   209,
     209,   209,   209,   209,   209,   209,   209,   209,   209,   209,
     209,   209,   209,   209,   209,   209,   210,   211,   211,   212,
     212,   212
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     0,     2,     2,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     2,
       1,     1,     2,     1,     1,     1,     1,     3,     1,     1,
       0,     3,     3,     3,     3,     0,     3,     3,     3,     3,
       1,     1,     1,     4,     8,     5,     7,     4,     7,     4,
       1,     4,     3,     4,     1,     4,     1,     1,     1,     1,
       1,     1,     1,     1,     7,     8,     1,     4,     6,     4,
       6,     3,     1,     4,     6,     4,     1,     1,     1,     1,
       6,     5,     1,     1,     5,     6,    12,    13,     9,    11,
      13,    14,    15,    16,    12,    13,     4,     7,     4,     1,
       1,     1,     5,     3,     3,     3,     2,     2,     2,     2,
       2,     2,     3,     3,     4,     5,     1,     1,     8,     4,
       5,     8,     5,     8,     4,     4,     4,     3,     3,     3,
       1,     1,     3,     3,     1,     1,     1,     4,     6,     7,
       4,     4,     6,     7,     4,     6,     7,     4,     6,     7,
       4,     6,     7,     4,     2,     2,     4,     4,     4,     1,
       4,     4,     4,     1,     1,     1,     1,     1,     5,     8,
       9,     4,     4,     1,     1,     1,     1,     4,     4,     4,
       4,     4,     4,     4,     1,     5,     1,     2,     1,     1,
       1,     1,     4,     4,     5,     5,     4,     4,     1,     1,
       1,     6,     6,     4,     4,     1,     1,     1,     2,     3,
       3,     3
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 4: /* command: isocommand SEMICOLON  */
#line 120 "testtool.y"
                {
			command[0] = 0;
		}
#line 1809 "testtool_y.c"
    break;

  case 15: /* isocommand: createfile statusenq  */
#line 136 "testtool.y"
                {	
			f_createfile(&cf, sw);
			free_cf(&cf);
		}
#line 1818 "testtool_y.c"
    break;

  case 29: /* isocommand: crd statusenq  */
#line 154 "testtool.y"
                {
			f_crd_call(&crd, sw);
			free_crd(&crd);
		}
#line 1827 "testtool_y.c"
    break;

  case 32: /* isocommand: rrc statusenq  */
#line 161 "testtool.y"
                {
			f_rrc(&rrcval, sw);
			free_rrc(&rrcval);
		}
#line 1836 "testtool_y.c"
    break;

  case 37: /* isocommand: apdu expval statusenq  */
#line 170 "testtool.y"
                {
			f_send_apdu(&apdu_val, &command_exp_val, sw);
			free_apdu(&apdu_val);
			free_expectedvalue(&command_exp_val);
		}
#line 1846 "testtool_y.c"
    break;

  case 40: /* statusenq: %empty  */
#line 180 "testtool.y"
                {
			strcpy(sw, "????");
		}
#line 1854 "testtool_y.c"
    break;

  case 41: /* statusenq: SW ISEQUAL STRING  */
#line 184 "testtool.y"
                {
			int i;
			if ((strlen((yyvsp[0].stringval)) != 8) || (strncmp((yyvsp[0].stringval), "\"0x", 3) !=0) || ((yyvsp[0].stringval)[7]!='"')) {
				yyerror("Incorrect Format for SW");
				exit(1);
			}
			for (i= 3; i < 7; i++) {
				if ((!isxdigit((yyvsp[0].stringval)[i])) && ((yyvsp[0].stringval)[i] != '*')) {
					yyerror("Incorrect Format for SW");
					exit(1);
				}
			}
			strncpy(sw, (yyvsp[0].stringval)+3, 4);
			sw[4]='\0';
		}
#line 1874 "testtool_y.c"
    break;

  case 42: /* statusenq: SW ISEQUAL ERR  */
#line 200 "testtool.y"
                {
			strcpy(sw, "@@@@");
		}
#line 1882 "testtool_y.c"
    break;

  case 43: /* statusenq: SW ISEQUAL OK  */
#line 204 "testtool.y"
                {
			strcpy(sw, "????");
		}
#line 1890 "testtool_y.c"
    break;

  case 44: /* statusenq: SW ISEQUAL ANY  */
#line 208 "testtool.y"
                {
			strcpy(sw, "****");
		}
#line 1898 "testtool_y.c"
    break;

  case 45: /* expval: %empty  */
#line 213 "testtool.y"
                { 
			struct stringvalue_s e;
			e.tag = STRING;
			e.stringvalue=NULL;
			e.length.tag = VALUE;
			e.length.intvalue_u.intvalue = 0;
			command_exp_val.is_equal=1;
			command_exp_val.is_cstring=1;
			strval_save(&(command_exp_val.strval),&e);
		}
#line 1913 "testtool_y.c"
    break;

  case 46: /* expval: EXPVAL ISEQUAL string  */
#line 224 "testtool.y"
                {
			command_exp_val.is_equal=1; 
			command_exp_val.is_cstring=1;
			strval_save(&(command_exp_val.strval),&(yyvsp[0].stringval_s));
		}
#line 1923 "testtool_y.c"
    break;

  case 47: /* expval: EXPVAL ISNOTEQUAL string  */
#line 230 "testtool.y"
                {
			command_exp_val.is_equal=0; 
			command_exp_val.is_cstring=1;
			strval_save(&(command_exp_val.strval), &(yyvsp[0].stringval_s));
		}
#line 1933 "testtool_y.c"
    break;

  case 48: /* expval: EXPVAL ISEQUAL HEXSTR  */
#line 236 "testtool.y"
                {
			command_exp_val.is_equal=1; 
			command_exp_val.is_cstring=0;
			command_exp_val.strval.tag = STRING;
			command_exp_val.strval.stringvalue = (yyvsp[0].stringval);
			command_exp_val.strval.length.tag = VALUE;
			command_exp_val.strval.length.intvalue_u.intvalue = estringlen((yyvsp[0].stringval));
		}
#line 1946 "testtool_y.c"
    break;

  case 49: /* expval: EXPVAL ISNOTEQUAL HEXSTR  */
#line 245 "testtool.y"
                {
			command_exp_val.is_equal=0; 
			command_exp_val.is_cstring=0;
			command_exp_val.strval.tag = STRING;
			command_exp_val.strval.stringvalue = (yyvsp[0].stringval);
			command_exp_val.strval.length.tag = VALUE;
			command_exp_val.strval.length.intvalue_u.intvalue = estringlen((yyvsp[0].stringval));
		}
#line 1959 "testtool_y.c"
    break;

  case 50: /* value: VALUE  */
#line 258 "testtool.y"
                {(yyval.intval_s).tag = VALUE; (yyval.intval_s).intvalue_u.intvalue = (yyvsp[0].intval);}
#line 1965 "testtool_y.c"
    break;

  case 51: /* value: CVARIABLE  */
#line 259 "testtool.y"
                    {(yyval.intval_s).tag = CVARIABLE; (yyval.intval_s).intvalue_u.stringvalue = (yyvsp[0].stringval);}
#line 1971 "testtool_y.c"
    break;

  case 52: /* string: STRING  */
#line 263 "testtool.y"
                 {
		(yyval.stringval_s).tag = STRING; 
		(yyval.stringval_s).stringvalue = (yyvsp[0].stringval); 
		(yyval.stringval_s).length.tag = VALUE;
		(yyval.stringval_s).length.intvalue_u.intvalue = estringlen((yyvsp[0].stringval));
	}
#line 1982 "testtool_y.c"
    break;

  case 53: /* string: CVARIABLE '(' value ')'  */
#line 269 "testtool.y"
                                  {
		(yyval.stringval_s).tag = CVARIABLE; 
		(yyval.stringval_s).stringvalue = (yyvsp[-3].stringval);
		(yyval.stringval_s).length.tag = (yyvsp[-1].intval_s).tag;
		if ((yyvsp[-1].intval_s).tag == VALUE)
			(yyval.stringval_s).length.intvalue_u.intvalue = (yyvsp[-1].intval_s).intvalue_u.intvalue;
		else
			(yyval.stringval_s).length.intvalue_u.stringvalue = (yyvsp[-1].intval_s).intvalue_u.stringvalue;
	}
#line 1996 "testtool_y.c"
    break;

  case 54: /* readbinary: RB SFI '=' value value value expval statusenq  */
#line 282 "testtool.y"
                {
			f_readbinary(&(yyvsp[-4].intval_s), &(yyvsp[-3].intval_s), &(yyvsp[-2].intval_s), &command_exp_val, sw);

			free_intvalue(&(yyvsp[-4].intval_s));
			free_intvalue(&(yyvsp[-3].intval_s));
			free_intvalue(&(yyvsp[-2].intval_s));
			free_expectedvalue(&command_exp_val);
			
		}
#line 2010 "testtool_y.c"
    break;

  case 55: /* readbinary: RB value value expval statusenq  */
#line 292 "testtool.y"
                {
			f_readbinary(NULL, &(yyvsp[-3].intval_s), &(yyvsp[-2].intval_s), &command_exp_val, sw);

			free_intvalue(&(yyvsp[-3].intval_s));
			free_intvalue(&(yyvsp[-2].intval_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2022 "testtool_y.c"
    break;

  case 56: /* writebinary: WB SFI '=' value value string statusenq  */
#line 303 "testtool.y"
                {
			f_writebinary(&(yyvsp[-3].intval_s), &(yyvsp[-2].intval_s), &(yyvsp[-1].stringval_s), sw);

			free_intvalue(&(yyvsp[-3].intval_s));
			free_intvalue(&(yyvsp[-2].intval_s));
			free_stringvalue(&(yyvsp[-1].stringval_s));
		}
#line 2034 "testtool_y.c"
    break;

  case 57: /* writebinary: WB value string statusenq  */
#line 311 "testtool.y"
                {	
 			f_writebinary(NULL, &(yyvsp[-2].intval_s), &(yyvsp[-1].stringval_s), sw);

			free_intvalue(&(yyvsp[-2].intval_s));
			free_stringvalue(&(yyvsp[-1].stringval_s));
		}
#line 2045 "testtool_y.c"
    break;

  case 58: /* updatebinary: UB SFI '=' value value string statusenq  */
#line 321 "testtool.y"
                {
			f_updatebinary(&(yyvsp[-3].intval_s), &(yyvsp[-2].intval_s), &(yyvsp[-1].stringval_s), sw);

			free_intvalue(&(yyvsp[-3].intval_s));
			free_intvalue(&(yyvsp[-2].intval_s));
			free_stringvalue(&(yyvsp[-1].stringval_s));
		}
#line 2057 "testtool_y.c"
    break;

  case 59: /* updatebinary: UB value string statusenq  */
#line 329 "testtool.y"
                {	
			f_updatebinary(NULL, &(yyvsp[-2].intval_s), &(yyvsp[-1].stringval_s), sw);

			free_intvalue(&(yyvsp[-2].intval_s));
			free_stringvalue(&(yyvsp[-1].stringval_s));
		}
#line 2068 "testtool_y.c"
    break;

  case 60: /* eb: EB  */
#line 339 "testtool.y"
                {
			(yyval.intval_s_ptr)=NULL;
		}
#line 2076 "testtool_y.c"
    break;

  case 61: /* eb: EB SFI '=' value  */
#line 343 "testtool.y"
                {
			intval_save(&sfi,&(yyvsp[0].intval_s));
			(yyval.intval_s_ptr)=&sfi;
		}
#line 2085 "testtool_y.c"
    break;

  case 62: /* erasebinary: eb value statusenq  */
#line 351 "testtool.y"
                {
			f_erasebinary((yyvsp[-2].intval_s_ptr), &(yyvsp[-1].intval_s), NULL, sw);
			free_intvalue(&(yyvsp[-1].intval_s));
		}
#line 2094 "testtool_y.c"
    break;

  case 63: /* erasebinary: eb value value statusenq  */
#line 356 "testtool.y"
                {
			f_erasebinary((yyvsp[-3].intval_s_ptr), &(yyvsp[-2].intval_s), &(yyvsp[-1].intval_s), sw);
			free_intvalue(&(yyvsp[-2].intval_s));
			free_intvalue(&(yyvsp[-1].intval_s));
		}
#line 2104 "testtool_y.c"
    break;

  case 64: /* rr: RR  */
#line 365 "testtool.y"
                {
			(yyval.intval_s_ptr)=NULL;
		}
#line 2112 "testtool_y.c"
    break;

  case 65: /* rr: RR SFI '=' value  */
#line 369 "testtool.y"
                {
			intval_save(&sfi,&(yyvsp[0].intval_s));
			(yyval.intval_s_ptr)=&sfi;
		}
#line 2121 "testtool_y.c"
    break;

  case 66: /* rtype: RNO  */
#line 376 "testtool.y"
                {
			(yyval.intval)=RNO;
		}
#line 2129 "testtool_y.c"
    break;

  case 67: /* rtype: RID  */
#line 380 "testtool.y"
                {
			(yyval.intval)=RID;
		}
#line 2137 "testtool_y.c"
    break;

  case 68: /* recordopt: FIRST  */
#line 387 "testtool.y"
                {
			(yyval.intval)=FIRST;
		}
#line 2145 "testtool_y.c"
    break;

  case 69: /* recordopt: LAST  */
#line 391 "testtool.y"
                {
			(yyval.intval)=LAST;
		}
#line 2153 "testtool_y.c"
    break;

  case 70: /* recordopt: NEXT  */
#line 395 "testtool.y"
                {
			(yyval.intval)=NEXT;
		}
#line 2161 "testtool_y.c"
    break;

  case 71: /* recordopt: PREVIOUS  */
#line 399 "testtool.y"
                {
			(yyval.intval)=PREVIOUS;
		}
#line 2169 "testtool_y.c"
    break;

  case 72: /* recordopt: TOLAST  */
#line 403 "testtool.y"
                {	
			(yyval.intval)=TOLAST;
		}
#line 2177 "testtool_y.c"
    break;

  case 73: /* recordopt: FROMLAST  */
#line 407 "testtool.y"
                {
			(yyval.intval)=FROMLAST;
		}
#line 2185 "testtool_y.c"
    break;

  case 74: /* readrecord: rr rtype '=' value value expval statusenq  */
#line 414 "testtool.y"
                {
			f_readrecord((yyvsp[-6].intval_s_ptr), (yyvsp[-5].intval), &(yyvsp[-3].intval_s), T_DEFAULT, &(yyvsp[-2].intval_s), &command_exp_val, sw);
			free_intvalue((yyvsp[-6].intval_s_ptr));
			free_intvalue(&(yyvsp[-3].intval_s));
			free_intvalue(&(yyvsp[-2].intval_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2197 "testtool_y.c"
    break;

  case 75: /* readrecord: rr rtype '=' value recordopt value expval statusenq  */
#line 422 "testtool.y"
                {
			f_readrecord((yyvsp[-7].intval_s_ptr), (yyvsp[-6].intval), &(yyvsp[-4].intval_s), (yyvsp[-3].intval), &(yyvsp[-2].intval_s), &command_exp_val, sw);
			free_intvalue((yyvsp[-7].intval_s_ptr));
			free_intvalue(&(yyvsp[-4].intval_s));
			free_intvalue(&(yyvsp[-2].intval_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2209 "testtool_y.c"
    break;

  case 76: /* wr: WR  */
#line 433 "testtool.y"
                {
			(yyval.intval_s_ptr)=NULL;
		}
#line 2217 "testtool_y.c"
    break;

  case 77: /* wr: WR SFI '=' value  */
#line 437 "testtool.y"
                {
			intval_save(&sfi,&(yyvsp[0].intval_s));
			(yyval.intval_s_ptr)=&sfi;
		}
#line 2226 "testtool_y.c"
    break;

  case 78: /* writerecord: wr RNO '=' value string statusenq  */
#line 445 "testtool.y"
                {
			f_writerecord((yyvsp[-5].intval_s_ptr), &(yyvsp[-2].intval_s), T_DEFAULT, &(yyvsp[-1].stringval_s), sw);
			free_intvalue((yyvsp[-5].intval_s_ptr));
			free_intvalue(&(yyvsp[-2].intval_s));
			free_stringvalue(&(yyvsp[-1].stringval_s));
		}
#line 2237 "testtool_y.c"
    break;

  case 79: /* writerecord: wr recordopt string statusenq  */
#line 452 "testtool.y"
                {
			f_writerecord((yyvsp[-3].intval_s_ptr), NULL, (yyvsp[-2].intval), &(yyvsp[-1].stringval_s), sw);
			free_intvalue((yyvsp[-3].intval_s_ptr));
			free_stringvalue(&(yyvsp[-1].stringval_s));
		
		}
#line 2248 "testtool_y.c"
    break;

  case 80: /* appendrecord: AR SFI '=' value string statusenq  */
#line 462 "testtool.y"
                {
			f_appendrecord(&(yyvsp[-2].intval_s),&(yyvsp[-1].stringval_s), sw);
			free_intvalue(&(yyvsp[-2].intval_s));
			free_stringvalue(&(yyvsp[-1].stringval_s));
		}
#line 2258 "testtool_y.c"
    break;

  case 81: /* appendrecord: AR string statusenq  */
#line 469 "testtool.y"
                {
			f_appendrecord(NULL,&(yyvsp[-1].stringval_s), sw);
			free_stringvalue(&(yyvsp[-1].stringval_s));
		}
#line 2267 "testtool_y.c"
    break;

  case 82: /* ur: UR  */
#line 477 "testtool.y"
                {
			(yyval.intval_s_ptr)=NULL;
		}
#line 2275 "testtool_y.c"
    break;

  case 83: /* ur: UR SFI '=' value  */
#line 481 "testtool.y"
                {
			intval_save(&sfi,&(yyvsp[0].intval_s));
			(yyval.intval_s_ptr)=&sfi;
		}
#line 2284 "testtool_y.c"
    break;

  case 84: /* updaterecord: ur RNO '=' value string statusenq  */
#line 489 "testtool.y"
                {
			f_updaterecord((yyvsp[-5].intval_s_ptr), &(yyvsp[-2].intval_s), T_DEFAULT, &(yyvsp[-1].stringval_s), sw);
			free_intvalue((yyvsp[-5].intval_s_ptr));
			free_intvalue(&(yyvsp[-2].intval_s));
			free_stringvalue(&(yyvsp[-1].stringval_s));
		}
#line 2295 "testtool_y.c"
    break;

  case 85: /* updaterecord: ur recordopt string statusenq  */
#line 496 "testtool.y"
                {
			f_updaterecord((yyvsp[-3].intval_s_ptr), NULL, (yyvsp[-2].intval), &(yyvsp[-1].stringval_s), sw);
			free_stringvalue(&(yyvsp[-1].stringval_s));
		}
#line 2304 "testtool_y.c"
    break;

  case 86: /* tagtype: BERTLV  */
#line 504 "testtool.y"
                {
			(yyval.intval)=BERTLV;
		}
#line 2312 "testtool_y.c"
    break;

  case 87: /* tagtype: APPL  */
#line 508 "testtool.y"
                {
			(yyval.intval)=APPL;
		}
#line 2320 "testtool_y.c"
    break;

  case 88: /* tagtype: STLV  */
#line 512 "testtool.y"
                {
			(yyval.intval)=STLV;
		}
#line 2328 "testtool_y.c"
    break;

  case 89: /* tagtype: BER2TLV  */
#line 516 "testtool.y"
                {
			(yyval.intval)=BER2TLV;
		}
#line 2336 "testtool_y.c"
    break;

  case 90: /* getdata: GD tagtype value value expval statusenq  */
#line 523 "testtool.y"
                {
			f_getdata((yyvsp[-4].intval),&(yyvsp[-3].intval_s),&(yyvsp[-2].intval_s), &command_exp_val, sw);
			free_intvalue(&(yyvsp[-3].intval_s));
			free_intvalue(&(yyvsp[-2].intval_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2347 "testtool_y.c"
    break;

  case 91: /* putdata: PD tagtype value string statusenq  */
#line 533 "testtool.y"
                {
			f_putdata((yyvsp[-3].intval),&(yyvsp[-2].intval_s),&(yyvsp[-1].stringval_s), sw);
			free_intvalue(&(yyvsp[-2].intval_s));
			free_stringvalue(&(yyvsp[-1].stringval_s));
		}
#line 2357 "testtool_y.c"
    break;

  case 92: /* rdtype: GRD  */
#line 542 "testtool.y"
                {
			(yyval.intval)=GRD;
		}
#line 2365 "testtool_y.c"
    break;

  case 93: /* rdtype: SRD  */
#line 546 "testtool.y"
                {
			(yyval.intval)=SRD;
		}
#line 2373 "testtool_y.c"
    break;

  case 94: /* verify: VERIFY rdtype '=' value statusenq  */
#line 553 "testtool.y"
                {
			f_verify((yyvsp[-3].intval), &(yyvsp[-1].intval_s), NULL, sw);
			free_intvalue(&(yyvsp[-1].intval_s));
	
		}
#line 2383 "testtool_y.c"
    break;

  case 95: /* verify: VERIFY rdtype '=' value string statusenq  */
#line 559 "testtool.y"
                {
			f_verify((yyvsp[-4].intval), &(yyvsp[-2].intval_s), &(yyvsp[-1].stringval_s), sw);
			free_intvalue(&(yyvsp[-2].intval_s));
			free_stringvalue(&(yyvsp[-1].stringval_s));
		}
#line 2393 "testtool_y.c"
    break;

  case 96: /* iauth: IAUTH ALGO '=' value rdtype '=' value CHALLENGE '=' string expval statusenq  */
#line 568 "testtool.y"
                {
			f_iauth(&(yyvsp[-8].intval_s), (yyvsp[-7].intval), &(yyvsp[-5].intval_s), &(yyvsp[-2].stringval_s), NULL, &command_exp_val, sw);
			free_intvalue(&(yyvsp[-8].intval_s));
			free_intvalue(&(yyvsp[-5].intval_s));
			free_stringvalue(&(yyvsp[-2].stringval_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2405 "testtool_y.c"
    break;

  case 97: /* iauth: IAUTH ALGO '=' value rdtype '=' value CHALLENGE '=' string value expval statusenq  */
#line 576 "testtool.y"
                {
			f_iauth(&(yyvsp[-9].intval_s), (yyvsp[-8].intval), &(yyvsp[-6].intval_s), &(yyvsp[-3].stringval_s), &(yyvsp[-2].intval_s), &command_exp_val, sw);
			free_intvalue(&(yyvsp[-9].intval_s));
			free_intvalue(&(yyvsp[-6].intval_s));
			free_stringvalue(&(yyvsp[-3].stringval_s));
			free_intvalue(&(yyvsp[-2].intval_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2418 "testtool_y.c"
    break;

  case 98: /* eauth: EAUTH ALGO '=' value rdtype '=' value string statusenq  */
#line 588 "testtool.y"
                {
			f_eauth(&(yyvsp[-5].intval_s), (yyvsp[-4].intval), &(yyvsp[-2].intval_s), &(yyvsp[-1].stringval_s), sw);
			free_intvalue(&(yyvsp[-5].intval_s));
			free_intvalue(&(yyvsp[-2].intval_s));
			free_stringvalue(&(yyvsp[-1].stringval_s));
		}
#line 2429 "testtool_y.c"
    break;

  case 99: /* eauth: EAUTH ALGO '=' value rdtype '=' value RESPONSE '=' string statusenq  */
#line 595 "testtool.y"
                {
			f_eauth(&(yyvsp[-7].intval_s), (yyvsp[-6].intval), &(yyvsp[-4].intval_s), &(yyvsp[-1].stringval_s), sw);
			free_intvalue(&(yyvsp[-7].intval_s));
			free_intvalue(&(yyvsp[-4].intval_s));
			free_stringvalue(&(yyvsp[-1].stringval_s));
		}
#line 2440 "testtool_y.c"
    break;

  case 100: /* mauth: MAUTH ALGO '=' value rdtype '=' value CHALLENGE '=' string string expval statusenq  */
#line 606 "testtool.y"
                {	
			f_mauth(&(yyvsp[-9].intval_s), (yyvsp[-8].intval), &(yyvsp[-6].intval_s), &(yyvsp[-3].stringval_s), &(yyvsp[-2].stringval_s), NULL, &command_exp_val, sw);
			free_intvalue(&(yyvsp[-9].intval_s));
			free_intvalue(&(yyvsp[-6].intval_s));
			free_stringvalue(&(yyvsp[-3].stringval_s));
			free_stringvalue(&(yyvsp[-2].stringval_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2453 "testtool_y.c"
    break;

  case 101: /* mauth: MAUTH ALGO '=' value rdtype '=' value CHALLENGE '=' string string value expval statusenq  */
#line 615 "testtool.y"
                {	
			f_mauth(&(yyvsp[-10].intval_s), (yyvsp[-9].intval), &(yyvsp[-7].intval_s), &(yyvsp[-4].stringval_s), &(yyvsp[-3].stringval_s), &(yyvsp[-2].intval_s), &command_exp_val, sw);
			free_intvalue(&(yyvsp[-10].intval_s));
			free_intvalue(&(yyvsp[-7].intval_s));
			free_stringvalue(&(yyvsp[-4].stringval_s));
			free_stringvalue(&(yyvsp[-3].stringval_s));
			free_intvalue(&(yyvsp[-2].intval_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2467 "testtool_y.c"
    break;

  case 102: /* mauth: MAUTH ALGO '=' value rdtype '=' value CHALLENGE '=' string RESPONSE '=' string expval statusenq  */
#line 625 "testtool.y"
                {	
			f_mauth(&(yyvsp[-11].intval_s), (yyvsp[-10].intval), &(yyvsp[-8].intval_s), &(yyvsp[-5].stringval_s), &(yyvsp[-2].stringval_s), NULL, &command_exp_val, sw);
			free_intvalue(&(yyvsp[-11].intval_s));
			free_intvalue(&(yyvsp[-8].intval_s));
			free_stringvalue(&(yyvsp[-5].stringval_s));
			free_stringvalue(&(yyvsp[-2].stringval_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2480 "testtool_y.c"
    break;

  case 103: /* mauth: MAUTH ALGO '=' value rdtype '=' value CHALLENGE '=' string RESPONSE '=' string value expval statusenq  */
#line 634 "testtool.y"
                {	
			f_mauth(&(yyvsp[-12].intval_s), (yyvsp[-11].intval), &(yyvsp[-9].intval_s), &(yyvsp[-6].stringval_s), &(yyvsp[-3].stringval_s), &(yyvsp[-2].intval_s), &command_exp_val, sw);
			free_intvalue(&(yyvsp[-12].intval_s));
			free_intvalue(&(yyvsp[-9].intval_s));
			free_stringvalue(&(yyvsp[-6].stringval_s));
			free_stringvalue(&(yyvsp[-3].stringval_s));
			free_intvalue(&(yyvsp[-2].intval_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2494 "testtool_y.c"
    break;

  case 104: /* mauth: MAUTH ALGO '=' value rdtype '=' value CHALLRESP '=' string expval statusenq  */
#line 644 "testtool.y"
                {
			f_mauth(&(yyvsp[-8].intval_s), (yyvsp[-7].intval), &(yyvsp[-5].intval_s), &(yyvsp[-2].stringval_s), NULL, NULL, &command_exp_val, sw);
			free_intvalue(&(yyvsp[-8].intval_s));
			free_intvalue(&(yyvsp[-5].intval_s));
			free_stringvalue(&(yyvsp[-2].stringval_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2506 "testtool_y.c"
    break;

  case 105: /* mauth: MAUTH ALGO '=' value rdtype '=' value CHALLRESP '=' string value expval statusenq  */
#line 652 "testtool.y"
                {
			f_mauth(&(yyvsp[-9].intval_s), (yyvsp[-8].intval), &(yyvsp[-6].intval_s), &(yyvsp[-3].stringval_s), NULL, &(yyvsp[-2].intval_s), &command_exp_val, sw);
			free_intvalue(&(yyvsp[-9].intval_s));
			free_intvalue(&(yyvsp[-6].intval_s));
			free_stringvalue(&(yyvsp[-3].stringval_s));
			free_intvalue(&(yyvsp[-2].intval_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2519 "testtool_y.c"
    break;

  case 106: /* getc: GETC value expval statusenq  */
#line 664 "testtool.y"
                {
			f_getc(NULL, &(yyvsp[-2].intval_s), &command_exp_val, sw);
			free_intvalue(&(yyvsp[-2].intval_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2529 "testtool_y.c"
    break;

  case 107: /* getc: GETC ALGO '=' value value expval statusenq  */
#line 671 "testtool.y"
                {
			f_getc(&(yyvsp[-3].intval_s), &(yyvsp[-2].intval_s), &command_exp_val, sw);
			free_intvalue(&(yyvsp[-3].intval_s));
			free_intvalue(&(yyvsp[-2].intval_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2540 "testtool_y.c"
    break;

  case 108: /* getr: GETR value expval statusenq  */
#line 682 "testtool.y"
                {
			f_getr(&(yyvsp[-2].intval_s), &command_exp_val, sw);
			free_intvalue(&(yyvsp[-2].intval_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2550 "testtool_y.c"
    break;

  case 109: /* mseopt: CDA  */
#line 690 "testtool.y"
                {
			(yyval.intval)=CDA;
		}
#line 2558 "testtool_y.c"
    break;

  case 110: /* mseopt: VEA  */
#line 694 "testtool.y"
                {
			(yyval.intval)=VEA;
		}
#line 2566 "testtool_y.c"
    break;

  case 111: /* mseopt: CDAVEA  */
#line 698 "testtool.y"
                {
			(yyval.intval)=CDAVEA;
		}
#line 2574 "testtool_y.c"
    break;

  case 112: /* mseset: MSESET mseopt value string statusenq  */
#line 704 "testtool.y"
                {
			f_mseset((yyvsp[-3].intval), &(yyvsp[-2].intval_s), &(yyvsp[-1].stringval_s), sw);
			free_intvalue(&(yyvsp[-2].intval_s));
			free_stringvalue(&(yyvsp[-1].stringval_s));
		}
#line 2584 "testtool_y.c"
    break;

  case 113: /* msestore: MSESTORE value statusenq  */
#line 713 "testtool.y"
                {
			f_command_value("MSEStore", &(yyvsp[-1].intval_s), sw);
			free_intvalue(&(yyvsp[-1].intval_s));
		}
#line 2593 "testtool_y.c"
    break;

  case 114: /* mserestore: MSERESTORE value statusenq  */
#line 721 "testtool.y"
                {
			f_command_value("MSERestore", &(yyvsp[-1].intval_s), sw);
			free_intvalue(&(yyvsp[-1].intval_s));
		}
#line 2602 "testtool_y.c"
    break;

  case 115: /* mseerase: MSEERASE value statusenq  */
#line 729 "testtool.y"
                {
			f_command_value("MSEErase", &(yyvsp[-1].intval_s), sw);
			free_intvalue(&(yyvsp[-1].intval_s));
		}
#line 2611 "testtool_y.c"
    break;

  case 116: /* psoop: CCC string  */
#line 737 "testtool.y"
                {
			psoop.op = CCC;
			strval_save(&(psoop.in_data), &(yyvsp[0].stringval_s));
			psoop.tag = NULL;
		}
#line 2621 "testtool_y.c"
    break;

  case 117: /* psoop: VCC string  */
#line 743 "testtool.y"
                {
			psoop.op = VCC;
			strval_save(&(psoop.in_data), &(yyvsp[0].stringval_s));
			psoop.tag = NULL;
		}
#line 2631 "testtool_y.c"
    break;

  case 118: /* psoop: HASH string  */
#line 749 "testtool.y"
                {
			psoop.op = HASH;
			strval_save(&(psoop.in_data), &(yyvsp[0].stringval_s));
			psoop.tag = NULL;
		}
#line 2641 "testtool_y.c"
    break;

  case 119: /* psoop: COMPUTE_DIG_SIG string  */
#line 755 "testtool.y"
                {
			psoop.op = COMPUTE_DIG_SIG;
			strval_save(&(psoop.in_data), &(yyvsp[0].stringval_s));
			psoop.tag = NULL;
		}
#line 2651 "testtool_y.c"
    break;

  case 120: /* psoop: VERIFY_DIG_SIG string  */
#line 761 "testtool.y"
                {
			psoop.op = VERIFY_DIG_SIG;
			strval_save(&(psoop.in_data), &(yyvsp[0].stringval_s));
			psoop.tag = NULL;
		}
#line 2661 "testtool_y.c"
    break;

  case 121: /* psoop: VERIFY_CERT string  */
#line 767 "testtool.y"
                {
			psoop.op = VERIFY_CERT;
			strval_save(&(psoop.in_data), &(yyvsp[0].stringval_s));
			psoop.tag = NULL;
		}
#line 2671 "testtool_y.c"
    break;

  case 122: /* psoop: ENCIPHER string value  */
#line 773 "testtool.y"
                {
			psoop.op = ENCIPHER;
			strval_save(&(psoop.in_data), &(yyvsp[-1].stringval_s));
			intval_save(&tag, &(yyvsp[0].intval_s));
			psoop.tag = &tag;
		}
#line 2682 "testtool_y.c"
    break;

  case 123: /* psoop: DECIPHER string value  */
#line 780 "testtool.y"
                {
			psoop.op = DECIPHER;
			strval_save(&(psoop.in_data), &(yyvsp[-1].stringval_s));
			intval_save(&tag, &(yyvsp[0].intval_s));
			psoop.tag = &tag;
		}
#line 2693 "testtool_y.c"
    break;

  case 124: /* pso: PSO psoop expval statusenq  */
#line 790 "testtool.y"
                {
			f_pso(&psoop, NULL, &command_exp_val, sw);
			free_expectedvalue(&command_exp_val);
			free_pso(&psoop);
		}
#line 2703 "testtool_y.c"
    break;

  case 125: /* pso: PSO psoop value expval statusenq  */
#line 796 "testtool.y"
                {
			f_pso(&psoop, &(yyvsp[-2].intval_s), &command_exp_val, sw);
			free_intvalue(&(yyvsp[-2].intval_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2713 "testtool_y.c"
    break;

  case 126: /* crdopt: X  */
#line 805 "testtool.y"
                {
			(yyval.intval)=X;
		}
#line 2721 "testtool_y.c"
    break;

  case 127: /* crdopt: C  */
#line 809 "testtool.y"
                {
			(yyval.intval)=C;
		}
#line 2729 "testtool_y.c"
    break;

  case 128: /* crd: CRD crdopt rdtype '=' value NEWDATA '=' string  */
#line 815 "testtool.y"
                {
			crd.crdopt=(yyvsp[-6].intval);
			crd.rdtype=(yyvsp[-5].intval);
			intval_save(&crd.rdvalue,&(yyvsp[-3].intval_s));
			strval_save(&crd.newdata,&(yyvsp[0].stringval_s));
			crd.olddata=NULL;
		}
#line 2741 "testtool_y.c"
    break;

  case 129: /* crd: crd OLDDATA '=' string  */
#line 823 "testtool.y"
                {
			strval_save(&olddata,&(yyvsp[0].stringval_s));
			crd.olddata=&olddata;
		}
#line 2750 "testtool_y.c"
    break;

  case 130: /* evr: EVR rdtype '=' value statusenq  */
#line 830 "testtool.y"
                {
			f_vr(EVR,(yyvsp[-3].intval),&(yyvsp[-1].intval_s),NULL, sw);
			free_intvalue(&(yyvsp[-1].intval_s));
		}
#line 2759 "testtool_y.c"
    break;

  case 131: /* evr: EVR rdtype '=' value DATA '=' string statusenq  */
#line 835 "testtool.y"
                {
			f_vr(EVR,(yyvsp[-6].intval),&(yyvsp[-4].intval_s),&(yyvsp[-1].stringval_s), sw);
			free_intvalue(&(yyvsp[-4].intval_s));
		}
#line 2768 "testtool_y.c"
    break;

  case 132: /* dvr: DVR rdtype '=' value statusenq  */
#line 843 "testtool.y"
                {
			f_vr(DVR,(yyvsp[-3].intval),&(yyvsp[-1].intval_s),NULL, sw);
			free_intvalue(&(yyvsp[-1].intval_s));
		}
#line 2777 "testtool_y.c"
    break;

  case 133: /* dvr: DVR rdtype '=' value DATA '=' string statusenq  */
#line 848 "testtool.y"
                {
			f_vr(DVR,(yyvsp[-6].intval),&(yyvsp[-4].intval_s),&(yyvsp[-1].stringval_s), sw);
			free_intvalue(&(yyvsp[-4].intval_s));
		}
#line 2786 "testtool_y.c"
    break;

  case 134: /* rrc: RRC rdtype '=' value  */
#line 856 "testtool.y"
                {
			rrcval.rdtype=(yyvsp[-2].intval);
			intval_save(&rrcval.rdval,&(yyvsp[0].intval_s));
			free_intvalue(&(yyvsp[0].intval_s));
			rrcval.rcode=NULL;
			rrcval.nrd=NULL;
		}
#line 2798 "testtool_y.c"
    break;

  case 135: /* rrc: rrc RCODE '=' value  */
#line 864 "testtool.y"
                {
			intval_save(&rcode,&(yyvsp[0].intval_s));
			rrcval.rcode=&rcode;
			free_intvalue(&(yyvsp[0].intval_s));
		}
#line 2808 "testtool_y.c"
    break;

  case 136: /* rrc: rrc NRD '=' string  */
#line 870 "testtool.y"
                {
			strval_save(&nrd,&(yyvsp[0].stringval_s));
			rrcval.nrd=&nrd;
		}
#line 2817 "testtool_y.c"
    break;

  case 137: /* file: DFNAME '=' string  */
#line 878 "testtool.y"
                {
			(yyval.int_string_val_s).reftype=DFNAME;
			strval_save(&(yyval.int_string_val_s).value.stringvalue, &(yyvsp[0].stringval_s));
		}
#line 2826 "testtool_y.c"
    break;

  case 138: /* file: CDF '=' value  */
#line 883 "testtool.y"
                {
			(yyval.int_string_val_s).reftype=CDF;
			intval_save(&(yyval.int_string_val_s).value.intvalue, &(yyvsp[0].intval_s));
		}
#line 2835 "testtool_y.c"
    break;

  case 139: /* file: CEF '=' value  */
#line 888 "testtool.y"
                {
			(yyval.int_string_val_s).reftype=CEF;
			intval_save(&(yyval.int_string_val_s).value.intvalue, &(yyvsp[0].intval_s));
		}
#line 2844 "testtool_y.c"
    break;

  case 140: /* file: PDF  */
#line 893 "testtool.y"
                {
			(yyval.int_string_val_s).reftype=PDF;
		}
#line 2852 "testtool_y.c"
    break;

  case 141: /* file: MF  */
#line 897 "testtool.y"
                {
			(yyval.int_string_val_s).reftype=MF;
		}
#line 2860 "testtool_y.c"
    break;

  case 142: /* file: MFPATH '=' string  */
#line 901 "testtool.y"
                {
			(yyval.int_string_val_s).reftype=MFPATH;
			strval_save(&(yyval.int_string_val_s).value.stringvalue, &(yyvsp[0].stringval_s));
		}
#line 2869 "testtool_y.c"
    break;

  case 143: /* file: CDFPATH '=' string  */
#line 907 "testtool.y"
                {
			(yyval.int_string_val_s).reftype=CDFPATH;
			strval_save(&(yyval.int_string_val_s).value.stringvalue, &(yyvsp[0].stringval_s));
		}
#line 2878 "testtool_y.c"
    break;

  case 144: /* finfo: FCP  */
#line 914 "testtool.y"
                {
			(yyval.intval)=FCP;
		}
#line 2886 "testtool_y.c"
    break;

  case 145: /* finfo: FCI  */
#line 918 "testtool.y"
                {
			(yyval.intval)=FCI;
		}
#line 2894 "testtool_y.c"
    break;

  case 146: /* finfo: FMD  */
#line 922 "testtool.y"
                {
			(yyval.intval)=FMD;
		}
#line 2902 "testtool_y.c"
    break;

  case 147: /* selectfile: SF file recordopt statusenq  */
#line 929 "testtool.y"
                {	
			f_file_cmds(SF, &(yyvsp[-2].int_string_val_s), (yyvsp[-1].intval), T_DEFAULT, NULL, NULL, sw);	/*f_file_cmds(cmd, file, recordopt, finfo, numbytes, exp_val)*/
			free_int_string(&(yyvsp[-2].int_string_val_s));
		}
#line 2911 "testtool_y.c"
    break;

  case 148: /* selectfile: SF file recordopt finfo expval statusenq  */
#line 934 "testtool.y"
                {
			f_file_cmds(SF, &(yyvsp[-4].int_string_val_s), (yyvsp[-3].intval), (yyvsp[-2].intval), NULL, &command_exp_val, sw);	/*f_file_cmds(cmd, file, recordopt, finfo, numbytes, exp_val)*/
			free_int_string(&(yyvsp[-4].int_string_val_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2921 "testtool_y.c"
    break;

  case 149: /* selectfile: SF file recordopt finfo value expval statusenq  */
#line 940 "testtool.y"
                {
			f_file_cmds(SF, &(yyvsp[-5].int_string_val_s), (yyvsp[-4].intval), (yyvsp[-3].intval), &(yyvsp[-2].intval_s), &command_exp_val, sw);	/*f_file_cmds(cmd, file, recordopt, finfo, numbytes, exp_val)*/
			free_intvalue(&(yyvsp[-2].intval_s));
			free_int_string(&(yyvsp[-5].int_string_val_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2932 "testtool_y.c"
    break;

  case 150: /* deletefile: DF file recordopt statusenq  */
#line 950 "testtool.y"
                {
			f_file_cmds(DF, &(yyvsp[-2].int_string_val_s), (yyvsp[-1].intval), T_DEFAULT, NULL, NULL, sw);
			free_int_string(&(yyvsp[-2].int_string_val_s));
		}
#line 2941 "testtool_y.c"
    break;

  case 151: /* daf: DAF file recordopt statusenq  */
#line 958 "testtool.y"
                {
			f_file_cmds(DAF, &(yyvsp[-2].int_string_val_s), (yyvsp[-1].intval), T_DEFAULT, NULL, NULL, sw);
			free_int_string(&(yyvsp[-2].int_string_val_s));
		}
#line 2950 "testtool_y.c"
    break;

  case 152: /* daf: DAF file recordopt finfo expval statusenq  */
#line 963 "testtool.y"
                {
			f_file_cmds(DAF, &(yyvsp[-4].int_string_val_s), (yyvsp[-3].intval), (yyvsp[-2].intval), NULL, &command_exp_val, sw);
			free_int_string(&(yyvsp[-4].int_string_val_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2960 "testtool_y.c"
    break;

  case 153: /* daf: DAF file recordopt finfo value expval statusenq  */
#line 969 "testtool.y"
                {
			f_file_cmds(DAF, &(yyvsp[-5].int_string_val_s), (yyvsp[-4].intval), (yyvsp[-3].intval), &(yyvsp[-2].intval_s), &command_exp_val, sw);
			free_intvalue(&(yyvsp[-2].intval_s));
			free_int_string(&(yyvsp[-5].int_string_val_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2971 "testtool_y.c"
    break;

  case 154: /* af: AF file recordopt statusenq  */
#line 979 "testtool.y"
                {
			f_file_cmds(AF, &(yyvsp[-2].int_string_val_s), (yyvsp[-1].intval), T_DEFAULT, NULL, NULL, sw);
			free_int_string(&(yyvsp[-2].int_string_val_s));
		}
#line 2980 "testtool_y.c"
    break;

  case 155: /* af: AF file recordopt finfo expval statusenq  */
#line 984 "testtool.y"
                {
			f_file_cmds(AF, &(yyvsp[-4].int_string_val_s), (yyvsp[-3].intval), (yyvsp[-2].intval), NULL, &command_exp_val, sw);
			free_int_string(&(yyvsp[-4].int_string_val_s));
			free_expectedvalue(&command_exp_val);
		}
#line 2990 "testtool_y.c"
    break;

  case 156: /* af: AF file recordopt finfo value expval statusenq  */
#line 990 "testtool.y"
                {
			f_file_cmds(AF, &(yyvsp[-5].int_string_val_s), (yyvsp[-4].intval), (yyvsp[-3].intval), &(yyvsp[-2].intval_s), &command_exp_val, sw);
			free_intvalue(&(yyvsp[-2].intval_s));
			free_int_string(&(yyvsp[-5].int_string_val_s));
			free_expectedvalue(&command_exp_val);
		}
#line 3001 "testtool_y.c"
    break;

  case 157: /* termdf: TERMDF file recordopt statusenq  */
#line 1000 "testtool.y"
                {
			f_file_cmds(TERMDF, &(yyvsp[-2].int_string_val_s), (yyvsp[-1].intval), T_DEFAULT, NULL, NULL, sw);
			free_int_string(&(yyvsp[-2].int_string_val_s));
		}
#line 3010 "testtool_y.c"
    break;

  case 158: /* termdf: TERMDF file recordopt finfo expval statusenq  */
#line 1005 "testtool.y"
                {
			f_file_cmds(TERMDF, &(yyvsp[-4].int_string_val_s), (yyvsp[-3].intval), (yyvsp[-2].intval), NULL, &command_exp_val, sw);
			free_int_string(&(yyvsp[-4].int_string_val_s));
			free_expectedvalue(&command_exp_val);
		}
#line 3020 "testtool_y.c"
    break;

  case 159: /* termdf: TERMDF file recordopt finfo value expval statusenq  */
#line 1011 "testtool.y"
                {
			f_file_cmds(TERMDF, &(yyvsp[-5].int_string_val_s), (yyvsp[-4].intval), (yyvsp[-3].intval), &(yyvsp[-2].intval_s), &command_exp_val, sw);
			free_intvalue(&(yyvsp[-2].intval_s));
			free_int_string(&(yyvsp[-5].int_string_val_s));
			free_expectedvalue(&command_exp_val);
		}
#line 3031 "testtool_y.c"
    break;

  case 160: /* termef: TERMEF file recordopt statusenq  */
#line 1021 "testtool.y"
                {
			f_file_cmds(TERMEF, &(yyvsp[-2].int_string_val_s), (yyvsp[-1].intval), T_DEFAULT, NULL, NULL, sw);
			free_int_string(&(yyvsp[-2].int_string_val_s));
		}
#line 3040 "testtool_y.c"
    break;

  case 161: /* termef: TERMEF file recordopt finfo expval statusenq  */
#line 1026 "testtool.y"
                {
			f_file_cmds(TERMEF, &(yyvsp[-4].int_string_val_s), (yyvsp[-3].intval), (yyvsp[-2].intval), NULL, &command_exp_val, sw);
			free_int_string(&(yyvsp[-4].int_string_val_s));
			free_expectedvalue(&command_exp_val);
		}
#line 3050 "testtool_y.c"
    break;

  case 162: /* termef: TERMEF file recordopt finfo value expval statusenq  */
#line 1032 "testtool.y"
                {
			f_file_cmds(TERMEF, &(yyvsp[-5].int_string_val_s), (yyvsp[-4].intval), (yyvsp[-3].intval), &(yyvsp[-2].intval_s), &command_exp_val, sw);
			free_intvalue(&(yyvsp[-2].intval_s));
			free_int_string(&(yyvsp[-5].int_string_val_s));
			free_expectedvalue(&command_exp_val);
		}
#line 3061 "testtool_y.c"
    break;

  case 163: /* cfprefix: CREATEFILE FILEID '=' value  */
#line 1042 "testtool.y"
                {	
			intval_save(&cf_fileid,&(yyvsp[0].intval_s));
            		(yyval.intval_s_ptr)=&cf_fileid;
		}
#line 3070 "testtool_y.c"
    break;

  case 164: /* createfile: cfprefix df  */
#line 1050 "testtool.y"
                {
			intval_save(&cf.fileid,(yyvsp[-1].intval_s_ptr));
			cf.filetype=DF;
			cf.file.df=&df;
			cf.lcsi=NULL;   
			cf.compact_attr=NULL;
			cf.expanded_attr=NULL;
		}
#line 3083 "testtool_y.c"
    break;

  case 165: /* createfile: cfprefix ef  */
#line 1059 "testtool.y"
                {
			intval_save(&cf.fileid,(yyvsp[-1].intval_s_ptr));
			cf.filetype=T_EF;
			cf.file.ef=&ef;
			cf.lcsi=NULL;
			cf.compact_attr=NULL;
			cf.expanded_attr=NULL;
		}
#line 3096 "testtool_y.c"
    break;

  case 166: /* createfile: createfile LCSI '=' value  */
#line 1068 "testtool.y"
                {
			intval_save(&lcsi,&(yyvsp[0].intval_s));
			cf.lcsi=&lcsi;
		}
#line 3105 "testtool_y.c"
    break;

  case 167: /* createfile: createfile COMPACT_ATTR '=' string  */
#line 1073 "testtool.y"
                {
			strval_save(&compact_attr,&(yyvsp[0].stringval_s));
			cf.compact_attr=&compact_attr;
		}
#line 3114 "testtool_y.c"
    break;

  case 168: /* createfile: createfile EXPANDED_ATTR '=' string  */
#line 1078 "testtool.y"
                {
			strval_save(&expanded_attr,&(yyvsp[0].stringval_s));
            		cf.expanded_attr=&expanded_attr;
		}
#line 3123 "testtool_y.c"
    break;

  case 169: /* df: DF  */
#line 1086 "testtool.y"
                {
	  		df.name=NULL;
        		df.se=NULL;
        		df.sefile=NULL;
	  	}
#line 3133 "testtool_y.c"
    break;

  case 170: /* df: df DFNAME '=' string  */
#line 1092 "testtool.y"
                {
			strval_save(&dfname,&(yyvsp[0].stringval_s));
			df.name=&dfname;
		}
#line 3142 "testtool_y.c"
    break;

  case 171: /* df: df SE '=' string  */
#line 1097 "testtool.y"
                {
			strval_save(&df_se,&(yyvsp[0].stringval_s));
		    	df.se=&df_se;
		}
#line 3151 "testtool_y.c"
    break;

  case 172: /* df: df SEFILE '=' value  */
#line 1102 "testtool.y"
                {
			intval_save(&df_sefile,&(yyvsp[0].intval_s));
		    	df.sefile=&df_sefile;
		}
#line 3160 "testtool_y.c"
    break;

  case 173: /* eftype: INTERNAL  */
#line 1110 "testtool.y"
                {
			(yyval.intval)=INTERNAL;
		}
#line 3168 "testtool_y.c"
    break;

  case 174: /* eftype: WORKING  */
#line 1114 "testtool.y"
                {
			(yyval.intval)=WORKING;
		}
#line 3176 "testtool_y.c"
    break;

  case 175: /* record: FIXEDLENGTH  */
#line 1122 "testtool.y"
                {
			(yyval.intval)=FIXEDLENGTH;
		}
#line 3184 "testtool_y.c"
    break;

  case 176: /* record: VARLENGTH  */
#line 1126 "testtool.y"
                {
			(yyval.intval)=VARLENGTH;
		}
#line 3192 "testtool_y.c"
    break;

  case 177: /* record: CYCLIC  */
#line 1130 "testtool.y"
                {
			(yyval.intval)=CYCLIC;
		}
#line 3200 "testtool_y.c"
    break;

  case 178: /* ef: eftype TRANSPARENT FILESIZE '=' value  */
#line 1137 "testtool.y"
                {
			ef.eftype=(yyvsp[-4].intval);
			ef.efstructure=TRANSPARENT;
			intval_save(&filesize,&(yyvsp[0].intval_s));
			ef.efinfo.filesize=&filesize;
			ef.sfi=NULL;
			ef.datacode=T_DEFAULT;
		}
#line 3213 "testtool_y.c"
    break;

  case 179: /* ef: eftype record MNR '=' value MRL '=' value  */
#line 1146 "testtool.y"
                {	
			ef.eftype=(yyvsp[-7].intval);
			ef.efstructure=(yyvsp[-6].intval);
			intval_save(&mnr,&(yyvsp[-3].intval_s));
			ef.efinfo.recinfo.mnr=&mnr;
			intval_save(&mrl,&(yyvsp[0].intval_s));
			ef.efinfo.recinfo.mrl=&mrl;
			ef.efinfo.recinfo.stlvflag=T_DEFAULT;
			ef.sfi=NULL;
			ef.datacode=T_DEFAULT;
		}
#line 3229 "testtool_y.c"
    break;

  case 180: /* ef: eftype record MNR '=' value MRL '=' value SIMPLETLV  */
#line 1158 "testtool.y"
                {
			ef.eftype=(yyvsp[-8].intval);
			ef.efstructure=(yyvsp[-7].intval);
			intval_save(&mnr,&(yyvsp[-4].intval_s));
			ef.efinfo.recinfo.mnr=&mnr;
			intval_save(&mrl,&(yyvsp[-1].intval_s));
			ef.efinfo.recinfo.mrl=&mrl;
			ef.efinfo.recinfo.stlvflag=SIMPLETLV;
			ef.sfi=NULL;
			ef.datacode=T_DEFAULT;
		}
#line 3245 "testtool_y.c"
    break;

  case 181: /* ef: ef SFI '=' value  */
#line 1170 "testtool.y"
                {
			intval_save(&sfi,&(yyvsp[0].intval_s));
			ef.sfi=&sfi;
		}
#line 3254 "testtool_y.c"
    break;

  case 182: /* ef: ef DATACODING '=' datacode  */
#line 1175 "testtool.y"
                {
			ef.datacode=(yyvsp[0].intval);
		}
#line 3262 "testtool_y.c"
    break;

  case 183: /* datacode: WRITE_OR  */
#line 1182 "testtool.y"
                {
			(yyval.intval)=WRITE_OR;
		}
#line 3270 "testtool_y.c"
    break;

  case 184: /* datacode: WRITE_AND  */
#line 1186 "testtool.y"
                {
			(yyval.intval)=WRITE_AND;
		}
#line 3278 "testtool_y.c"
    break;

  case 185: /* datacode: WRITE_ONCE  */
#line 1190 "testtool.y"
                {	
			(yyval.intval)=WRITE_ONCE;
		}
#line 3286 "testtool_y.c"
    break;

  case 186: /* apdu: CAPDU  */
#line 1197 "testtool.y"
                {
			apdu_val.cla.tag=T_NOTSET;
			apdu_val.ins.tag=T_NOTSET;
			apdu_val.p1.tag=T_NOTSET;
			apdu_val.p2.tag=T_NOTSET;
			apdu_val.lc.tag=T_NOTSET;
			apdu_val.le.tag=T_NOTSET;
			apdu_val.indata.tag=T_NOTSET;
		}
#line 3300 "testtool_y.c"
    break;

  case 187: /* apdu: apdu CLA '=' value  */
#line 1207 "testtool.y"
                {
			if(apdu_val.cla.tag!=T_NOTSET)
			{
				yyerror("Duplicate option specified in CAPDU");
				exit(1);
			}
			intval_save(&apdu_val.cla,&(yyvsp[0].intval_s));	
		}
#line 3313 "testtool_y.c"
    break;

  case 188: /* apdu: apdu INS '=' value  */
#line 1216 "testtool.y"
                {
			if(apdu_val.ins.tag!=T_NOTSET)
			{
				yyerror("Duplicate option specified in CAPDU");
				exit(1);
			}
			intval_save(&apdu_val.ins,&(yyvsp[0].intval_s));	
		}
#line 3326 "testtool_y.c"
    break;

  case 189: /* apdu: apdu P1 '=' value  */
#line 1225 "testtool.y"
                {
			if(apdu_val.p1.tag!=T_NOTSET)
			{
				yyerror("Duplicate option specified in CAPDU");
				exit(1);
			}
			intval_save(&apdu_val.p1,&(yyvsp[0].intval_s));	
		}
#line 3339 "testtool_y.c"
    break;

  case 190: /* apdu: apdu P2 '=' value  */
#line 1234 "testtool.y"
                {
			if(apdu_val.p2.tag!=T_NOTSET)
			{
				yyerror("Duplicate option specified in CAPDU");
				exit(1);
			}
			intval_save(&apdu_val.p2,&(yyvsp[0].intval_s));	
		}
#line 3352 "testtool_y.c"
    break;

  case 191: /* apdu: apdu Lc '=' value  */
#line 1243 "testtool.y"
                {
			if(apdu_val.lc.tag!=T_NOTSET)
			{
				yyerror("Duplicate option specified in CAPDU");
				exit(1);
			}
			intval_save(&apdu_val.lc,&(yyvsp[0].intval_s));	
		}
#line 3365 "testtool_y.c"
    break;

  case 192: /* apdu: apdu Le '=' value  */
#line 1252 "testtool.y"
                {
			if(apdu_val.le.tag!=T_NOTSET)
			{
				yyerror("Duplicate option specified in CAPDU");
				exit(1);
			}
			intval_save(&apdu_val.le,&(yyvsp[0].intval_s));	
		}
#line 3378 "testtool_y.c"
    break;

  case 193: /* apdu: apdu INDATA '=' string  */
#line 1261 "testtool.y"
                {
			if(apdu_val.indata.tag!=T_NOTSET)
			{
				yyerror("Duplicate option specified in CAPDU");
				exit(1);
			}
			strval_save(&apdu_val.indata,&(yyvsp[0].stringval_s));
		}
#line 3391 "testtool_y.c"
    break;

  case 194: /* reset: RESET  */
#line 1273 "testtool.y"
       {
       		f_reset();
       }
#line 3399 "testtool_y.c"
    break;

  case 195: /* smspec: SM taglist RESPONSE taglist statusenq  */
#line 1282 "testtool.y"
                {
			char *return_value = NULL;
			return_value = check_tags(0, (yyvsp[-3].tagList), 1);
			if (return_value != NULL) {
				yyerror(return_value);
				yyerror("Invalid SM CommandAPDU Taglist");
				exit(1);
			}
			return_value = check_tags(0, (yyvsp[-1].tagList), 0);
			if (return_value != NULL) {
				yyerror(return_value);
				yyerror("Invalid SM ResponseAPDU Taglist");
				exit(1);
			}
			if (((yyvsp[-3].tagList)->tags[0].tag_no == 0x00) && ((yyvsp[-1].tagList)->tags[0].tag_no != 0x00)) {
				// If the cmd taglist is SM_NULL but response
				// taglist is something else ==> Error.
				yyerror("SM Command and Response taglists are incompatible");
				exit(1);
			}
			if (((yyvsp[-3].tagList)->tags[0].tag_no == 0x00) && ((yyvsp[-1].tagList)->tags[0].tag_no == 0x00)) {
				// if the cmd taglist is SM_NULL & response taglist is also SM_NULL
				// then SM = NULL
				f_print_deleteSM();
			}
			else	{
				// print the MS tag list
				f_print_deleteSM();
				f_print_line_info();
				fprintf(yyout, "\tSM = new SMContext();\n");
				f_print_SMCommandTagList((yyvsp[-3].tagList));
				f_print_SMResponseTagList((yyvsp[-1].tagList));
			}
			f_print_sm_status(sw);
		}
#line 3439 "testtool_y.c"
    break;

  case 196: /* taglist: tag  */
#line 1321 "testtool.y"
                {
			struct taglist_s *new_taglist = (struct taglist_s *)malloc(sizeof(struct taglist_s));
			new_taglist->tags = (struct taglistItem_s *)malloc(sizeof(struct taglistItem_s));
			new_taglist->tags[0] = (yyvsp[0].tagListItemval_s);
			new_taglist->num_tags = 1;
			(yyval.tagList) = new_taglist;
		}
#line 3451 "testtool_y.c"
    break;

  case 197: /* taglist: taglist tag  */
#line 1329 "testtool.y"
                {
			struct taglistItem_s *t = (struct taglistItem_s *)malloc(sizeof(struct taglistItem_s)*((yyvsp[-1].tagList)->num_tags+1));
			int i;
			for(i=0;i<(yyvsp[-1].tagList)->num_tags;i++) {
				t[i] = (yyvsp[-1].tagList)->tags[i];
			}
			t[(yyvsp[-1].tagList)->num_tags] = (yyvsp[0].tagListItemval_s);
			free((yyvsp[-1].tagList)->tags);
			(yyvsp[-1].tagList)->tags = t;
			(yyvsp[-1].tagList)->num_tags += 1;
			(yyval.tagList) = (yyvsp[-1].tagList);
		}
#line 3468 "testtool_y.c"
    break;

  case 198: /* tag: SM_NULL  */
#line 1345 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0x00;
			setEmpty(&((yyval.tagListItemval_s).crypto.key));
			(yyval.tagListItemval_s).crypto.algo = NULL;
			setEmpty(&((yyval.tagListItemval_s).crypto.iv));
			(yyval.tagListItemval_s).sublist = NULL;
		}
#line 3480 "testtool_y.c"
    break;

  case 199: /* tag: CHINCLUDE  */
#line 1353 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0x0C;	//any non-SM tag can be specified here
			setEmpty(&((yyval.tagListItemval_s).crypto.key));
			(yyval.tagListItemval_s).crypto.algo = NULL;
			setEmpty(&((yyval.tagListItemval_s).crypto.iv));
			(yyval.tagListItemval_s).sublist = NULL;
		}
#line 3492 "testtool_y.c"
    break;

  case 200: /* tag: CDATA  */
#line 1361 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0x80;
			setEmpty(&((yyval.tagListItemval_s).crypto.key));
			(yyval.tagListItemval_s).crypto.algo = NULL;
			setEmpty(&((yyval.tagListItemval_s).crypto.iv));
			(yyval.tagListItemval_s).sublist = NULL;
		}
#line 3504 "testtool_y.c"
    break;

  case 201: /* tag: CDATA_AUTH  */
#line 1369 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0x81;
			setEmpty(&((yyval.tagListItemval_s).crypto.key));
			(yyval.tagListItemval_s).crypto.algo = NULL;
			setEmpty(&((yyval.tagListItemval_s).crypto.iv));
			(yyval.tagListItemval_s).sublist = NULL;
		}
#line 3516 "testtool_y.c"
    break;

  case 202: /* tag: PLAINDO '(' taglist ')'  */
#line 1377 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0xB0;
			setEmpty(&((yyval.tagListItemval_s).crypto.key));
			(yyval.tagListItemval_s).crypto.algo = NULL;
			setEmpty(&((yyval.tagListItemval_s).crypto.iv));
			(yyval.tagListItemval_s).sublist = (yyvsp[-1].tagList);
		}
#line 3528 "testtool_y.c"
    break;

  case 203: /* tag: PLAINDO_AUTH '(' taglist ')'  */
#line 1385 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0xB1;
			setEmpty(&((yyval.tagListItemval_s).crypto.key));
			(yyval.tagListItemval_s).crypto.algo = NULL;
			setEmpty(&((yyval.tagListItemval_s).crypto.iv));
			(yyval.tagListItemval_s).sublist = (yyvsp[-1].tagList);
		}
#line 3540 "testtool_y.c"
    break;

  case 204: /* tag: CRYPTODO '(' cryptospec taglist ')'  */
#line 1393 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0x82;
			(yyval.tagListItemval_s).crypto = (yyvsp[-2].cryptoSpecval_s);
			if ((yyvsp[-2].cryptoSpecval_s).algo == NULL) (yyval.tagListItemval_s).crypto.algo = "\"tdes-cbc\"";
			(yyval.tagListItemval_s).sublist = (yyvsp[-1].tagList);
		}
#line 3551 "testtool_y.c"
    break;

  case 205: /* tag: CRYPTODO_AUTH '(' cryptospec taglist ')'  */
#line 1400 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0x83;
			(yyval.tagListItemval_s).crypto = (yyvsp[-2].cryptoSpecval_s);
			if ((yyvsp[-2].cryptoSpecval_s).algo == NULL) (yyval.tagListItemval_s).crypto.algo = "\"tdes-cbc\"";
			(yyval.tagListItemval_s).sublist = (yyvsp[-1].tagList);
		}
#line 3562 "testtool_y.c"
    break;

  case 206: /* tag: ENCDATA '(' cryptospec ')'  */
#line 1407 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0x86;
			(yyval.tagListItemval_s).crypto = (yyvsp[-1].cryptoSpecval_s);
			if ((yyvsp[-1].cryptoSpecval_s).algo == NULL) (yyval.tagListItemval_s).crypto.algo = "\"tdes-cbc\"";
			(yyval.tagListItemval_s).sublist = NULL;
		}
#line 3573 "testtool_y.c"
    break;

  case 207: /* tag: ENCDATA_AUTH '(' cryptospec ')'  */
#line 1414 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0x87;
			(yyval.tagListItemval_s).crypto = (yyvsp[-1].cryptoSpecval_s);
			if ((yyvsp[-1].cryptoSpecval_s).algo == NULL) (yyval.tagListItemval_s).crypto.algo = "\"tdes-cbc\"";
			(yyval.tagListItemval_s).sublist = NULL;
		}
#line 3584 "testtool_y.c"
    break;

  case 208: /* tag: CH_AUTH  */
#line 1421 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0x89;
			setEmpty(&((yyval.tagListItemval_s).crypto.key));
			(yyval.tagListItemval_s).crypto.algo = NULL;
			setEmpty(&((yyval.tagListItemval_s).crypto.iv));
			(yyval.tagListItemval_s).sublist = NULL;
		}
#line 3596 "testtool_y.c"
    break;

  case 209: /* tag: LE  */
#line 1429 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0x96;
			setEmpty(&((yyval.tagListItemval_s).crypto.key));
			(yyval.tagListItemval_s).crypto.algo = NULL;
			setEmpty(&((yyval.tagListItemval_s).crypto.iv));
			(yyval.tagListItemval_s).sublist = NULL;
		}
#line 3608 "testtool_y.c"
    break;

  case 210: /* tag: LE_AUTH  */
#line 1437 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0x97;
			setEmpty(&((yyval.tagListItemval_s).crypto.key));
			(yyval.tagListItemval_s).crypto.algo = NULL;
			setEmpty(&((yyval.tagListItemval_s).crypto.iv));
			(yyval.tagListItemval_s).sublist = NULL;
		}
#line 3620 "testtool_y.c"
    break;

  case 211: /* tag: HASH '(' ALGO '=' STRING ')'  */
#line 1445 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0x90;
			setEmpty(&((yyval.tagListItemval_s).crypto.key));
			(yyval.tagListItemval_s).crypto.algo = strsave((yyvsp[-1].stringval));
			setEmpty(&((yyval.tagListItemval_s).crypto.iv));
			(yyval.tagListItemval_s).sublist = NULL;
		}
#line 3632 "testtool_y.c"
    break;

  case 212: /* tag: HASH_AUTH '(' ALGO '=' STRING ')'  */
#line 1453 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0x91;
			setEmpty(&((yyval.tagListItemval_s).crypto.key));
			(yyval.tagListItemval_s).crypto.algo = strsave((yyvsp[-1].stringval));
			setEmpty(&((yyval.tagListItemval_s).crypto.iv));
			(yyval.tagListItemval_s).sublist = NULL;
		}
#line 3644 "testtool_y.c"
    break;

  case 213: /* tag: CC '(' cryptospec ')'  */
#line 1461 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0x8E;
			(yyval.tagListItemval_s).crypto = (yyvsp[-1].cryptoSpecval_s);
			if ((yyvsp[-1].cryptoSpecval_s).algo == NULL) (yyval.tagListItemval_s).crypto.algo = "\"tdes-mac\"";
			(yyval.tagListItemval_s).sublist = NULL;
		}
#line 3655 "testtool_y.c"
    break;

  case 214: /* tag: DO '(' string ')'  */
#line 1468 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0xd0;
			strval_save(&((yyval.tagListItemval_s).crypto.key), &(yyvsp[-1].stringval_s)); // Overloaded as value of the DO.
			(yyval.tagListItemval_s).crypto.algo = NULL;
			setEmpty(&((yyval.tagListItemval_s).crypto.iv));
			(yyval.tagListItemval_s).sublist = NULL;
		}
#line 3667 "testtool_y.c"
    break;

  case 215: /* tag: STATUS  */
#line 1476 "testtool.y"
                {
			(yyval.tagListItemval_s).tag_no = 0x99;
			setEmpty(&((yyval.tagListItemval_s).crypto.key));
			(yyval.tagListItemval_s).crypto.algo = NULL;
			setEmpty(&((yyval.tagListItemval_s).crypto.iv));
			(yyval.tagListItemval_s).sublist = NULL;
		}
#line 3679 "testtool_y.c"
    break;

  case 216: /* cryptospec: cryptoitemlist  */
#line 1487 "testtool.y"
                {
			(yyval.cryptoSpecval_s) = (yyvsp[0].cryptoSpecval_s);
			if (isEmpty((yyvsp[0].cryptoSpecval_s).key)) {
				yyerror("Key not defined for crypto specs.");
				exit(1);
			}
		}
#line 3691 "testtool_y.c"
    break;

  case 217: /* cryptoitemlist: cryptoitem  */
#line 1498 "testtool.y"
                {
			(yyval.cryptoSpecval_s) = (yyvsp[0].cryptoSpecval_s);
		}
#line 3699 "testtool_y.c"
    break;

  case 218: /* cryptoitemlist: cryptoitem cryptoitemlist  */
#line 1502 "testtool.y"
                {
			(yyval.cryptoSpecval_s) = (yyvsp[0].cryptoSpecval_s);
			if (((yyvsp[0].cryptoSpecval_s).algo == NULL) && ((yyvsp[-1].cryptoSpecval_s).algo != NULL))
				(yyval.cryptoSpecval_s).algo = (yyvsp[-1].cryptoSpecval_s).algo;
			else if (isEmpty((yyvsp[0].cryptoSpecval_s).key) && (!isEmpty((yyvsp[-1].cryptoSpecval_s).key)))
				(yyval.cryptoSpecval_s).key = (yyvsp[-1].cryptoSpecval_s).key;
			else if (isEmpty((yyvsp[0].cryptoSpecval_s).iv) && (!isEmpty((yyvsp[-1].cryptoSpecval_s).iv)))
				(yyval.cryptoSpecval_s).iv = (yyvsp[-1].cryptoSpecval_s).iv;
			else {
				yyerror("Redefined Crypto item");
				exit(1);
			}
		}
#line 3717 "testtool_y.c"
    break;

  case 219: /* cryptoitem: KEYVAL '=' string  */
#line 1519 "testtool.y"
                {
			strval_save(&((yyval.cryptoSpecval_s).key), &(yyvsp[0].stringval_s));
			(yyval.cryptoSpecval_s).algo = NULL;
			setEmpty(&((yyval.cryptoSpecval_s).iv));
		}
#line 3727 "testtool_y.c"
    break;

  case 220: /* cryptoitem: IV '=' string  */
#line 1525 "testtool.y"
                {
			setEmpty(&((yyval.cryptoSpecval_s).key));
			(yyval.cryptoSpecval_s).algo = NULL;
			strval_save(&((yyval.cryptoSpecval_s).iv), &(yyvsp[0].stringval_s));
		}
#line 3737 "testtool_y.c"
    break;

  case 221: /* cryptoitem: ALGO '=' STRING  */
#line 1531 "testtool.y"
                {
			setEmpty(&((yyval.cryptoSpecval_s).key));
			(yyval.cryptoSpecval_s).algo = strsave((yyvsp[0].stringval));
			setEmpty(&((yyval.cryptoSpecval_s).iv));
		}
#line 3747 "testtool_y.c"
    break;


#line 3751 "testtool_y.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 1538 "testtool.y"


void free_intvalue(struct intvalue_s *s) {
	if(s==NULL)	return;
	if (s->tag != VALUE)	free(s->intvalue_u.stringvalue);
}

void free_stringvalue(struct stringvalue_s *s) {
	if(s==NULL)	return;
	if (s->stringvalue) free(s->stringvalue);
	if (s->length.tag == CVARIABLE)	free(s->length.intvalue_u.stringvalue);
}

void free_expectedvalue(struct expectedvalue_s *s) {
	struct stringvalue_s e;
	if(s==NULL) return;
	if(s->strval.stringvalue) free(s->strval.stringvalue);
	if (s->strval.length.tag == CVARIABLE)	free(s->strval.length.intvalue_u.stringvalue);

	e.tag = STRING;
	e.stringvalue=NULL;
	e.length.tag = VALUE;
	e.length.intvalue_u.intvalue = 0;
	s->is_equal=1;
	s->is_cstring=1;
	strval_save(&(s->strval),&e);
 }
 
void free_pso(struct pso_s *psoop)	{
	if(psoop == NULL)	return;
	free_stringvalue(&psoop->in_data);
	if(psoop->tag != NULL)	free_intvalue(psoop->tag);
}

void free_cf(struct cf_s *cf)	{
	if(cf==NULL)	return;
	free_intvalue(&cf->fileid);
	if(cf->filetype == DF)	free_df(cf->file.df);
	else	free_ef(cf->file.ef);
	
	if(cf->lcsi!=NULL)	free_intvalue(cf->lcsi);
	if(cf->compact_attr!=NULL)	free_stringvalue(cf->compact_attr);
	if(cf->expanded_attr!=NULL)	free_stringvalue(cf->expanded_attr);
}

void free_df(struct df_s *df)	{
	if(df==NULL)	return;
	if(df->name!=NULL)	free_stringvalue(df->name);
	if(df->se!=NULL)	free_stringvalue(df->se);
	if(df->sefile!=NULL)	free_intvalue(df->sefile);	
}

void free_ef(struct ef_s *ef)	{
	if(ef==NULL)	return;
	if(ef->efstructure==TRANSPARENT)	{
		free_intvalue(ef->efinfo.filesize);
	}	
	else	{
		free_intvalue(ef->efinfo.recinfo.mrl);
		free_intvalue(ef->efinfo.recinfo.mnr);
	}
	if(ef->sfi!=NULL)	free_intvalue(ef->sfi);	
}

void free_rrc(struct rrc_s *rrc)	{
	if(rrc==NULL)	return;
	free_intvalue(&rrc->rdval);
	free_intvalue(rrc->rcode);
	free_stringvalue(rrc->nrd);
}

void free_crd(struct crd_s *crd)	{
	if(crd==NULL)	return;
	free_intvalue(&crd->rdvalue);
	free_stringvalue(&crd->newdata);
	free_stringvalue(crd->olddata);
}

void free_int_string(struct int_string_s *file)	{
	if(file==NULL)	return;
	switch(file->reftype)	{
		case DFNAME:
		case MFPATH:
		case CDFPATH:
			free_stringvalue(&(file->value.stringvalue));
			break;
		case CDF:
		case CEF:
			free_intvalue(&(file->value.intvalue));
			break;
	}
}

void free_apdu(struct apdu_s *apdu_val)	{
	if(apdu_val->cla.tag!=T_NOTSET)	free_intvalue(&apdu_val->cla);
	if(apdu_val->ins.tag!=T_NOTSET)	free_intvalue(&apdu_val->ins);
	if(apdu_val->p1.tag!=T_NOTSET)	free_intvalue(&apdu_val->p1);
	if(apdu_val->p2.tag!=T_NOTSET)	free_intvalue(&apdu_val->p2);
	if(apdu_val->lc.tag!=T_NOTSET)	free_intvalue(&apdu_val->lc);
	if(apdu_val->le.tag!=T_NOTSET)	free_intvalue(&apdu_val->le);
	if(apdu_val->indata.tag!=T_NOTSET)	free_stringvalue(&apdu_val->indata);
}

// function to find the length of the string
int estringlen(sbyte *string)	{
  	ubyte4 llength = strlen(string);  // literal length of the string
	ubyte4 elength = 0;  // effective length - to be computed
	sbyte *p;
	ubyte4 i;

	if (llength < 2) return -1;
	if (string[0] != '"' || string[llength-1] != '"')
		return -1;

	for (p = string + 1; p < string + llength - 1; p++) {
		if (*p == '\\') {
			p++;
			if (*p == 'x') { // skip hexdigit chars
				p++;
				while (p < string + llength - 1 && isxdigit(*p)) p++;
				p--;
			} 
			else	{
				if (isdigit(*p)) { // skip at most 3 digits
					i = 1;
					p++;
					while (i++ < 3 && p < string + llength - 1 && isdigit(*p)) p++;
					p--;
				} // else nothing to be done
			}
		}
		elength++;
  	}
  	return elength;
}

void setEmpty(struct stringvalue_s *s) {
	s->tag = STRING;
	s->stringvalue = NULL;
	s->length.tag = VALUE;
	s->length.intvalue_u.intvalue = 0;
}

int isEmpty(struct stringvalue_s s) {
	return((s.tag == STRING) &&
	(s.stringvalue == NULL) &&
	(s.length.tag == VALUE) &&
	(s.length.intvalue_u.intvalue == 0));
}

char *strsave(char *s) {
	char *r = malloc(strlen(s)+9);
	if (r == NULL) {
		fprintf(errfile, "Out of memory, quitting\n");
		exit(1);
	}
	strcpy(r, s);
	return r;
 }

void intval_save(struct intvalue_s *dst,struct intvalue_s *src)	{
	memcpy(dst,src,sizeof(struct intvalue_s));
}

void strval_save(struct stringvalue_s *dst,struct stringvalue_s *src)	{
	memcpy(dst,src,sizeof(struct stringvalue_s));
}

char *check_tags(int level, struct taglist_s *list, int cmdresp) {
	int i;
	char *s;
	int AUTHCODE = 0;
	int CC_PRESENT = 0;	//indicates that an odd tag is present
	for(i = 0; i < list->num_tags; i++) {
		if (list->tags[i].tag_no & 0x01) CC_PRESENT = 1;
		switch(list->tags[i].tag_no){
			case 0x00:	//NULL tag
				if (list->num_tags != 1) return ("NULL must be standalone tag");
				if (level != 0) return ("NULL must be in outermost context"); // Can not have NULL in the inner tag list
				break;
			case 0x0C:	//CH to be included in authentication; setting tag to 0x0C(can be anything else)
				if (level != 0) return ("CHINCLUDE must be in outermost context"); // Can not have CHINCLUDE in the inner tag list
				if (i!=0) return("CHINCLUDE must be the first tag only");
				if (!cmdresp) return ("CHINCLUDE can be only in command APDU"); // Can occur only in cmdAPDU
				CC_PRESENT = 1;
				break;
			case 0x80:
			case 0x81:
			case 0x86:
			case 0x87:
			case 0xD0: // DO Tag
				break;
			case 0x82:
			case 0x83:
			case 0xB0:
			case 0xB1:
				if (s = check_tags(1, list->tags[i].sublist, cmdresp)) return s;
				break;
			case 0x89:
				if (!cmdresp) return ("CH_AUTH is possible only in Command APDU"); //only in cmdAPDU
				break;
			case 0x96:
			case 0x97:
				if (!cmdresp) return ("LE/LE_AUTH possible only in command APDU"); // Only in CMD-APDU
				break;
			case 0x90:
			case 0x91:
			case 0x8E:
				if (i != list->num_tags -1)
					return ("CC/HASH/HASH_AUTH must be the last tag");
				break;
			case 0x99:
				if (cmdresp) return ("STATUS is possible only in RespAPDU"); // Only in respAPDU
				break;
			default: return ("Unknown Tag");
		}
	}
	return 0;
}

char *script_file;

main(int argc,char **argv)	{
	char *char_cfile = "out.cpp";
	char *mode = "w";
	char isError=0;
	int par_count;
	header="header.h";
	yyout=stdout;
	yyin=stdin;
	errfile = stderr;
	lineno=0;
	par_count=1;
	if((argc>9)||(argc%2==0)) {
		isError = 1;
	}
	while((isError == 0) && (par_count<argc)) {	
		if(strcmp(argv[par_count],"-s")==0) {
			script_file = argv[par_count+1];
		} else if(strcmp(argv[par_count],"-c")==0) {
			char_cfile = argv[par_count+1];
		} else if(strcmp(argv[par_count],"-h")==0) {
			header=argv[par_count+1];
		} else if(strncmp(argv[par_count],"-e",2)==0) {
			if (argv[par_count][2] == 'a')
				mode = "a";
			errfile = fopen(argv[par_count+1], mode);
			if (errfile != NULL)
				fclose(stderr);
			else
				errfile = stderr;
		} else isError = 1;
		par_count+=2;
	}
	if (isError || (script_file == NULL)) {
		fprintf(errfile,"Usage Error:\n");
		fprintf(errfile,"  Usage: testtool [-e[a] errorfile] -s script_file_name [-c C++ filename] [-h header_filename]\n");
		exit(1);
	}
	yyin=fopen(script_file,"r");
	if(yyin==NULL) {
		fprintf(errfile,"Error Opening script file %s for reading.\n",script_file);
		exit(1);
	}
	if (char_cfile != NULL) yyout=fopen(char_cfile,"w+");
	if(yyout==NULL) {
		fprintf(errfile,"Error Opening Output file %s for writing.\n",char_cfile);
		exit(1);
	}
	global=fopen(header,"w");
	if (global==NULL)
	{
		fprintf(errfile,"Error Creating header file %s\n",header);
		exit(1);
	}
	lineno++;
	command[0]=0;
	print_code();
	fclose(global);
	exit(0);
}

#ifdef _YYERROR
int yyerror(char *c)
{
	fprintf(errfile,"(Line: %d) Error: '%s' near %s\n",lineno, c, yytext);
	exit(1);
}
#endif
