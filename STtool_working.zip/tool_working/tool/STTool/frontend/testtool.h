#ifndef TESTTOOL_H
#define TESTTOOL_H

#include "arch.h"
#define T_EF -3
#define T_DEFAULT 255
#define MAX_BUFFER 10000
#define MAX_CHALLENGE 32
#define T_NOTSET 0

struct intvalue_s	{
	ubyte4 tag;
	union {
		ubyte4 intvalue;
		sbyte *stringvalue;
	} intvalue_u;
};

struct stringvalue_s	{
	ubyte4 tag;
	struct intvalue_s length;
	sbyte *stringvalue;
};

struct int_string_s	{
	int reftype;
	union {
		struct intvalue_s intvalue;
		struct stringvalue_s stringvalue;
	} value;
};

struct df_s	{
	struct stringvalue_s *name;
	struct stringvalue_s *se;
	struct intvalue_s *sefile;
};

struct ef_s	{
	int eftype;
	int efstructure;
	union {
		struct intvalue_s *filesize;
		struct {
			struct intvalue_s *mnr;
			struct intvalue_s *mrl;
			ubyte4 stlvflag;
		} recinfo;
	} efinfo;
	struct intvalue_s *sfi;
	ubyte4 datacode;
};

struct rrc_s	{
	ubyte4 rdtype;
	struct intvalue_s rdval;
	struct intvalue_s *rcode;
	struct stringvalue_s *nrd;
};

struct cf_s	{
	struct intvalue_s fileid;
	ubyte4 filetype;
	union	{
		struct df_s *df;
		struct ef_s *ef;
	} file;
	struct intvalue_s *lcsi;
	struct stringvalue_s *compact_attr;
	struct stringvalue_s *expanded_attr;
};

struct pso_s	{
	ubyte4 op;
	struct stringvalue_s in_data;
	struct intvalue_s *tag;
};

struct crd_s	{
	ubyte4 crdopt;
	ubyte4 rdtype;
	struct intvalue_s rdvalue;
	struct stringvalue_s *olddata;
	struct stringvalue_s newdata;
};

struct apdu_s	{
	struct intvalue_s cla;
	struct intvalue_s ins;
	struct intvalue_s p1;
	struct intvalue_s p2;
	struct intvalue_s lc;
	struct intvalue_s le;
	struct stringvalue_s indata;
};

struct expectedvalue_s	{
	int is_equal;
	int is_cstring;
	struct stringvalue_s strval;
};

struct cryptospec_s	{
	struct stringvalue_s key;
	struct stringvalue_s iv;
	char *algo;
};

struct taglistItem_s	{
	ubyte tag_no;
	struct cryptospec_s crypto;
	struct taglist_s *sublist;
};

struct taglist_s	{
	ubyte num_tags;
	struct taglistItem_s  *tags;
};

void f_print_line_info(void);
void f_print_expected_length(struct intvalue_s *numbytes, struct expectedvalue_s *exp_val);
void f_print_check_expected_response(struct expectedvalue_s *exp_val);
void print_data(struct stringvalue_s *data);
void f_print_deleteSM();
void print_SMList(struct taglist_s *list);
void f_print_SMCommandTagList(struct taglist_s *list);
void f_print_SMResponseTagList(struct taglist_s *list);
void printrecordopt(ubyte4 recordopt);
void print_tag(ubyte4 tagtype, struct intvalue_s *tagvalue);
void print_qualifier(ubyte4 rdtype, struct intvalue_s *rdvalue);

void f_readbinary(struct intvalue_s *sfi, struct intvalue_s *offset, struct intvalue_s *numbytes, struct expectedvalue_s *exp_val, char *sw);
void f_writebinary(struct intvalue_s *sfi,struct intvalue_s *offset,struct stringvalue_s *string, char *sw);
void f_updatebinary(struct intvalue_s *sfi,struct intvalue_s *offset,struct stringvalue_s *string, char *sw);
void f_erasebinary(struct intvalue_s *sfi,struct intvalue_s *offset,struct intvalue_s *numbytes, char *sw);
void f_readrecord(struct intvalue_s *sfi,ubyte4 rtype,struct intvalue_s *rvalue,ubyte4 recordopt, struct intvalue_s *numbytes, struct expectedvalue_s *exp_val, char *sw);
void f_writerecord(struct intvalue_s *sfi,struct intvalue_s *rno,ubyte4 recordopt,struct stringvalue_s *record, char *sw);
void f_appendrecord(struct intvalue_s *sfi,struct stringvalue_s *record, char *sw);
void f_updaterecord(struct intvalue_s *sfi,struct intvalue_s *rno,ubyte4 recordopt,struct stringvalue_s *record, char *sw);
void f_getdata(ubyte4 tagtype,struct intvalue_s *tagvalue,struct intvalue_s *numbytes, struct expectedvalue_s *exp_val, char *sw);
void f_putdata(ubyte4 tagtype,struct intvalue_s *tagvalue,struct stringvalue_s *data, char *sw);
void f_getr(struct intvalue_s *numbytes, struct expectedvalue_s *exp_val, char* sw);
void f_verify(ubyte4 rdtype,struct intvalue_s *rdvalue, struct stringvalue_s *data, char *sw);
void f_iauth(struct intvalue_s *algo,ubyte4 rdtype,struct intvalue_s *rdvalue,struct stringvalue_s *challenge, struct intvalue_s *numbytes, struct expectedvalue_s *exp_val, char *sw);
void f_eauth(struct intvalue_s *algo,ubyte4 rdtype,struct intvalue_s *rdvalue, struct stringvalue_s *enc_challenge, char *sw);
void f_mauth(struct intvalue_s *algo,ubyte4 rdtype,struct intvalue_s *rdvalue, struct stringvalue_s *challenge, struct stringvalue_s *enc_challenge, struct intvalue_s *numbytes, struct expectedvalue_s *exp_val, char *sw);
void f_getc(struct intvalue_s *algo, struct intvalue_s *numbytes, struct expectedvalue_s *exp_val, char *sw);
void f_command_value(sbyte *cmd,struct intvalue_s *value, char *sw);
void f_mseset(ubyte4 mseopt,struct intvalue_s *value,struct stringvalue_s *CRTvalue, char *sw);
void f_pso(struct pso_s *psoop, struct intvalue_s *numbytes, struct expectedvalue_s *exp_val, char *sw);
void exchangeRefData(struct crd_s *crd);
void changeRefData(struct crd_s *crd);
void f_crd_call(struct crd_s *crd, char *sw);
void f_vr(ubyte4 cmd,ubyte4 rdtype,struct intvalue_s *rdvalue,struct stringvalue_s *data, char *sw);
void f_rrc(struct rrc_s *rrc, char *sw);
void f_file_cmds(ubyte4 cmd,struct int_string_s *file,ubyte4 recordopt, ubyte4 finfo, struct intvalue_s *numbytes, struct expectedvalue_s *exp_val, char *sw);
void printFCP_DF(struct df_s *df);
void printFCP_EF(struct ef_s *ef);
void f_createfile(struct cf_s *cf, char *sw);
void f_print_command_head(char *sw);
void f_print_command_tail();
void f_print_sm_status(char *sw);
void f_print_plain_status(char *sw);
void f_send_apdu(struct apdu_s *apdu_val, struct expectedvalue_s *exp_val, char *sw);
void print_header();
void print_code();
void f_reset(void);
void f_print_cryptospec(struct cryptospec_s *crypto);
void f_print_stringvalue(struct stringvalue_s *stringvalue);
void f_print_intvalue(struct intvalue_s *intvalue);
void f_print_hexvalue(struct intvalue_s *hexvalue);

#endif //TESTTOOL_H
