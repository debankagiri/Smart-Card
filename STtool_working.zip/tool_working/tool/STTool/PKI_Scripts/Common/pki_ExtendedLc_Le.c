<HEADER>
#include "isolib.h"

#define MAX_LENGTH 1500
int L=0;
// This functions reads the data from the file given as input.
BYTE* ReadFile(char *f, int *sz)	{
	FILE *fp = fopen(f, "rb");
	BYTE *fdata = NULL;
	if(fp==NULL) {
		T_log(f);
		T_log((char*)" could not be located. Quitting...\n");
		exit(0);
	}
	*sz = 0;
	fseek(fp, 0, SEEK_END);
	*sz = ftell(fp);
	fdata = (BYTE *) malloc(*sz);
	if(fdata == NULL)	return NULL;
	fseek(fp, 0, SEEK_SET);
	fread(fdata, 1, *sz, fp); 
	return(fdata);
}

// key preamble consists of key identifier, key type, and key specific information 
// key record should be of sufficient length to store the key record.
int make_key_record(BYTE* key_record, BYTE* key_preamble, int key_preamble_len, BYTE* key, int key_len)	{
	DO key_record_do(0xA0);
	key_record_do.appendValue(key_preamble_len, key_preamble);
	key_record_do.appendDO(0x04, key_len, key);
	key_record_do.getTotalBytes(key_record);
	return key_record_do.getTotalLength();
}

</HEADER>

<C>
BYTE encrypted_data1[20];
BYTE encrypted_data2[20];
BYTE ccc_data[20];
BYTE vcc_correct_data[30];
BYTE vcc_wrong_data[30];
BYTE derkey[16];
BYTE Kifd[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x01};
BYTE Kicc[256];

BYTE buffer1[MAX_LENGTH];
BYTE buffer2[MAX_LENGTH];
int buffer1_len;
int buffer2_len;

int i;
int k ;	
// reading keys from files.
int icc_private_key_len, icc_public_key_len, ifd_private_key_len, ifd_public_key_len, ifd_cert1_len, ifd_cert2_len, ifd_cert3_len, ifd_cert4_len, ifd_cert5_len, ifd_cert6_len;
int public_key_record_len, private_key_record_len, secret_key_record_len;

BYTE *icc_private_key = ReadFile((char*)"./pki_keys/2048/icc_private_key.der", &icc_private_key_len);
BYTE *icc_public_key  = ReadFile((char*)"./pki_keys/2048/icc_public_key.der", &icc_public_key_len);
BYTE *ifd_private_key = ReadFile((char*)"./pki_keys/2048/ifd_private_key.der", &ifd_private_key_len);
BYTE *ifd_public_key  = ReadFile((char*)"./pki_keys/2048/ifd_public_key.der", &ifd_public_key_len);

// reading certificates from files.
// Cert1: The subject public key algorithm is rsaEncryption and digital signature algorithm is sha1withRSAEncryption.
// Cert2: The subject public key algorithm is sha1withRSAEncryption and digital signature algorithm is sha1withRSAEncryption.
// Cert3: The subject public key algorithm is RSA-OAEP and digital signature algorithm is RSA-SSA-PSS.
// Cert4: The subject public key algorithm is RSA-SSA-PSS and digital signature algorithm is RSA-SSA-PSS.
BYTE *ifd_cert1  = ReadFile((char*)"./pki_keys/2048/ifd_self_signed_certificate.der", &ifd_cert1_len);
BYTE *ifd_cert2  = ReadFile((char*)"./pki_keys/2048/ifd_self_signed_certificate.der", &ifd_cert2_len);
BYTE *ifd_cert3  = ReadFile((char*)"./pki_keys/2048/ifd_self_signed_certificate.der", &ifd_cert3_len);
BYTE *ifd_cert4  = ReadFile((char*)"./pki_keys/2048/ifd_self_signed_certificate.der", &ifd_cert4_len);
</C>

#cleareep
#CAPDU CLA=0xA0 INS=0x11 P1=0x00 P2=0x00 Lc=0x00;

# Select MF and check if it exists. If it doesnot exist create one.
SF MF FIRST SW?=ANY;
<C>
if ((sw1<<8 | (sw2 & 0xFF)) != 0x9000) {
</C>
	CREATEFILE FILEID=0x3F00 DF; # should succeed in a blank card
	SF MF FIRST;
<C>
}
</C>

CAPDU CLA=0x00 INS=0xDA P1=0x02 P2=0xC0 Lc=0x0107 INDATA="ABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGH" SW?=ERROR;

CREATEFILE FILEID=0x3F04 INTERNAL TRANSPARENT FILESIZE=0x23 SFI=4;
WB SFI=4 0x00 
"ABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGHABCDEFGH" SW?=ERROR;

# Create application(6600) DF(6F00) under MF
CREATEFILE FILEID=0x6F00 DF DFNAME="\x66\x00" SEFILE=0x6F03;
# Create file EF2(sfi=2) to check that keys are not taken from EF2.
CREATEFILE FILEID=0x6F02 INTERNAL VARLENGTH MNR = 5 MRL = 24 SFI = 2 DATACODING = WRITE_ONCE;
WR RNO = 1 "\x81\xA3\xFF\xFF\xFF\xFF\xAF\x00\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01";	# valid key permits both CC, ENC, IAUTH & EAUTH(key id 81)
WR RNO = 2 "\x82\xA3\xFF\xFF\xFF\xFF\xAF\x00\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01";	# valid key permits both CC, ENC, IAUTH & EAUTH(key id 82)

# Create SE file for application DF.
CREATEFILE FILEID=0x6F03 INTERNAL VARLENGTH MNR=0x10 MRL=0x40 SFI = 3 DATACODING=WRITE_ONCE;
WR RNO = 1 "\x80\x01\x01\xB8\x09\x80\x01\x01\x83\x01\x81\x95\x01\xC0\xB4\x09\x80\x01\x01\x83\x01\x81\x95\x01\xC0";
# creating public key repository under the application DF.
CREATEFILE FILEID=0x6F04 INTERNAL TRANSPARENT FILESIZE=0x0400 SFI=4;
# Creating private key repository under the application DF.
CREATEFILE FILEID=0x6F05 INTERNAL TRANSPARENT FILESIZE=0x0800 SFI=5;
# creating secret key repository under the application DF.
CREATEFILE FILEID=0x6F06 INTERNAL TRANSPARENT FILESIZE=0x0400 SFI=6;

SF MFPATH = "\x6F\x00" FIRST;
# write public key(key id = 82, EAUTH counter = EE) and private key(key id = 83, ENC counter = B245, IAUTH counter = C245).
<C>
public_key_record_len = make_key_record(buffer1, (BYTE*)"\x80\x01\x82\x81\x01\x21\xA3\x03\x91\x01\xEE", 11, ifd_public_key, ifd_public_key_len);
fprintf(stderr, "length : %d", public_key_record_len);
</C>
WB SFI=4 0x00 buffer1(public_key_record_len);

<C>
int r = 0, t = 0;
BYTE adad[256] ={0};
for(int k = public_key_record_len  ; k > 0;)
{
	int of = 0;
	if(k >= 255)
	{
		r = 255;
	}
	else
	{
		r = k;
	}
	for(t = 0 ; t < r ; t++)
	{
		adad[t] = buffer1[of+t];
	}
</C>
	RB of r EXPVAL?=adad(r);
<C>
	of+=r;
	k=k-r;
}
</C>

SF MFPATH = "\x6F\x00" FIRST;
# write private key(key id = 83, ENC counter = B245, IAUTH counter = C245).
<C>
private_key_record_len = make_key_record(buffer2, (BYTE*)"\x80\x01\x83\x81\x01\x22\xA3\x08\x90\x02\xB2\x45\x90\x02\xC2\x45", 16, icc_private_key, icc_private_key_len);
</C>
WB SFI=5 0x00 buffer2(private_key_record_len);
<C>
//int r = 0;
for(int k = private_key_record_len  ; k > 0;)
{
	int of = 0;
	if(k >= 255)
	{
		r = 255;
	}
	else
	{
		r = k;
	}
</C>
	RB SFI=5 0x00 r EXPVAL?=buffer1(of);
<C>
	of+=r;
	k=k-r;
}
</C>
#RB SFI=5 0x00 private_key_record_len;

WB SFI=5 0x00 buffer2(1024);

WB SFI=5 0x00 buffer2(1017) SW?=OK;

<C>
//int r = 0;
for(int k = 1017  ; k > 0;)
{
	int of = 0;
	if(k >= 255)
	{
		r = 255;
	}
	else
	{
		r = k;
	}
</C>
	RB SFI=5 0x00 r EXPVAL?=buffer1(of);
<C>
	of+=r;
	k=k-r;
}
</C>
#RB SFI=5 0x00 1017 EXPVAL?=buffer2[1017];

EB 0x00;
################################################################################################ Break into 255 values as SM cannot be more than 255############################################
SF MF FIRST;
SF CDF=0x6F00 FIRST;
SF CEF=0x6F05 FIRST;
SM CDATA LE RESPONSE STATUS SW?=ANY;
#WB 0x00 buffer2[1017] ;
<C>
for(L =0;L<200;L++)
{
	buffer2[L]=L;
	
}
</C>
	WB  0x00  buffer2(L) ;
<C>
buffer2[L]=0,L=0;
for(L =200;L<400;L++)
{
	buffer2[L]=L;
	
}
</C>
	WB  0xff  buffer2(200) ;
<C>
buffer2[L]=0,L=0;
for(L =400;L<800;L++)
{
	buffer2[L]=L;
	
}
</C>
	WB  0x1fe  buffer2(200) ;
<C>
buffer2[L]=0,L=0;
for(L =800;L<1017;L++)
{
	buffer2[L]=L;
	
}
</C>
	WB  0x2fd  buffer2(200) ;
SM NULL RESPONSE NULL;


SF MF FIRST;
SF CDF=0x6F00 FIRST;
SF CEF=0x6F05 FIRST;
SM CH_AUTH CDATA LE RESPONSE STATUS SW?=ANY;
#WB SFI=5 0x00 buffer2[1011] ;
<C>
for(L =0;L<200;L++)
{
	buffer2[L]=L;
	
}
</C>
	WB  0x00  buffer2(L) ;
<C>
buffer2[L]=0,L=0;
for(L =200;L<400;L++)
{
	buffer2[L]=L;
	
}
</C>
	WB  0xff  buffer2(200) ;
<C>
buffer2[L]=0,L=0;
for(L =400;L<800;L++)
{
	buffer2[L]=L;
	
}
</C>
	WB  0x1fe  buffer2(200) ;
<C>
buffer2[L]=0,L=0;
for(L =800;L<1011;L++)
{
	buffer2[L]=L;
	
}
</C>
	WB  0x2fd   buffer2(200) ;	
SM NULL RESPONSE NULL;
	
SF MF FIRST;
SF CDF=0x6F00 FIRST;
SF CEF=0x6F05 FIRST;
SM CDATA LE RESPONSE CDATA STATUS;
#WB SFI=5 0x00 buffer2[1008];
<C>
for(L =0;L<200;L++)
{
	buffer2[L]=L;
	
}
</C>
	WB  0x00  buffer2(L) ;
<C>
buffer2[L]=0,L=0;
for(L =200;L<400;L++)
{
	buffer2[L]=L;
	
}
</C>
	WB  0xff  buffer2(200) ;
<C>
buffer2[L]=0,L=0;
for(L =400;L<800;L++)
{
	buffer2[L]=L;
	
}
</C>
	WB  0x1fe  buffer2(200) ;
<C>
buffer2[L]=0,L=0;
for(L =800;L<1008;L++)
{
	buffer2[L]=L;
	
}
</C>
	WB  0x2fd   buffer2(200) ;	
SM NULL RESPONSE NULL;
	